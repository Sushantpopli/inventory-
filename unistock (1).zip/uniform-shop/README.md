# UniStock — Uniform Shop Software

Billing and stock software for our school uniform shop.
Backend: Django + Django REST Framework. Frontend: React (Vite).

## Run it on your computer

You need **Python 3.11+** and **Node.js 20+**.

### 1. Backend (Django)

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate      Mac/Linux: source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_shop            # 9 schools + item types
python manage.py seed_shop --demo     # optional: 4 sample products to play with
python manage.py create_owner --name "Papa" --pin 1234   # first person who can log in
python manage.py createsuperuser      # optional: login for the Django admin panel
python manage.py runserver
```

- API: http://127.0.0.1:8000/api/catalog/
- Admin panel: http://127.0.0.1:8000/admin/

### 2. Frontend (React)

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173. The frontend sends `/api` calls to Django automatically.

### 3. Run the tests

```bash
cd backend
python manage.py test
```

## Logging in

Everyone logs in by tapping their name and typing a 4–6 digit PIN.
- **Owner**: everything — reports & profit, prices, settings, staff, cancelling old bills.
- **Counter staff**: billing, returns, stock in (prices stay as set), labels, low-stock list,
  cancelling today's bills.
The owner adds counter staff from the **Staff** screen. A logged-in counter stays logged in,
so billing keeps working without internet.

## Owner's phone

Log in as the owner on a phone and the **Today** screen opens: today's sale, cash/UPI,
comparison with yesterday and last week, low stock, latest bills (refreshes every minute).
In Chrome on the phone, "Add to Home screen" installs it like an app.
For the phone to work away from the shop, the server must be reachable on the internet
(a small cloud server with HTTPS) — see "Going live" in PROJECT_NOTES.md.

## Running the counter (offline billing)

The offline features (app opens with no internet) only work in the built version:

```bash
cd frontend
npm run build
npm run preview        # http://localhost:4173, sends /api to Django on port 8000
```

- Open the app once **with internet** so it downloads all items.
- After that, billing keeps working when the internet goes. Bills wait on the computer and
  are sent automatically when it comes back (see the status at the top left).
- **Print without the print dialog:** set the receipt printer as the default printer and start
  Chrome with `--kiosk-printing`, then tick "Print bill automatically" in Settings.
- Keyboard: **F8** saves the bill, **Enter** starts a new bill, **Esc** clears the scan box.

## Folder layout

```
backend/
  config/            Django settings and URLs
  catalog/           Module 1: schools, items, products, sizes, barcodes, Excel import
  labels/            Module 2: barcode label print list + PDF labels
  billing/           Module 3: shop settings, bills, offline sync, cancel
  stock/             Module 4: stock in, stock count (correction), stock history
  reports/           Module 6: sales summary, most sold, low-stock order list, Excel; owner Today
  accounts/          Module 7: staff, PIN login, owner / counter permissions
    models.py        database tables
    services.py      business rules (price ladder, barcodes, stock movements)
    importer.py      Excel import + template
    views.py         API endpoints
    tests/           automated tests
frontend/
  src/
    api.js           all calls to the backend
    i18n.jsx         English / Hindi text
    offline/         local database + sync (billing works without internet)
    pages/           Login, Today, Bill, Bills, Reports, Low stock, Products, Stock In, Labels, Schools, Import, Staff, Settings
    components/      Product form (price ladder), size table, icons
    index.css        the whole look: colours, fonts, spacing (tokens at the top)
```

## Using PostgreSQL instead of SQLite

Set an environment variable before running Django:

```bash
DATABASE_URL=postgres://user:password@localhost:5432/uniformshop
```
