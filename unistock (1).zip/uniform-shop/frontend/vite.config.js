import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'

// During development, /api calls go to Django on port 8000
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: { '/api': 'http://127.0.0.1:8000' },
  },
  // `npm run build && npm run preview` = test the real offline version on port 4173
  preview: {
    proxy: { '/api': 'http://127.0.0.1:8000' },
  },
})
