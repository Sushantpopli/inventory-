import { useCallback, useEffect, useRef, useState } from 'react'
import { api, openPdf } from '../api.js'
import Icon from '../components/Icon.jsx'
import { useLang } from '../i18n.jsx'

function savedLayout() {
  try { return localStorage.getItem('labelLayout') || 'roll_50x25' } catch { return 'roll_50x25' }
}

export default function LabelsPage() {
  const { t } = useLang()
  const [items, setItems] = useState(null)
  const [layouts, setLayouts] = useState([])
  const [layout, setLayout] = useState(savedLayout)
  const [testing, setTesting] = useState(false)
  const [skip, setSkip] = useState(0)
  const [confirming, setConfirming] = useState(false)
  const [error, setError] = useState('')

  const load = useCallback(() => {
    api.labelQueue().then(setItems).catch((e) => setError(e.message))
  }, [])
  useEffect(() => {
    load()
    api.labelLayouts().then(setLayouts).catch(() => {})
  }, [load])

  const chooseLayout = (k) => {
    setLayout(k)
    try { localStorage.setItem('labelLayout', k) } catch { /* ignore */ }
  }
  const setCopies = async (it, val) => {
    const n = parseInt(val, 10)
    if (!n || n < 1 || n === it.copies) return
    await api.setLabelCopies(it.id, n).catch((e) => setError(e.message))
    load()
  }
  const remove = async (it) => {
    await api.removeLabel(it.id).catch((e) => setError(e.message))
    load()
  }
  const clear = async () => {
    await api.clearLabels().catch((e) => setError(e.message))
    setConfirming(false)
    load()
  }

  const total = (items || []).reduce((a, i) => a + i.copies, 0)
  const isSheet = layouts.find((l) => l.key === layout)?.sheet
  const pdfUrl = api.labelsPdfUrl({ layout, skip: isSheet ? skip : '' })

  return (
    <div className="grid-main">
      <section className="panel">
        <div className="row spread">
          <h2>{t('toPrint')}</h2>
          <span className="muted">{t('totalLabels')}: <b>{total}</b></span>
        </div>
        {error && <div className="note bad" role="alert">{error}</div>}
        {items === null && <p className="muted">{t('loading')}</p>}
        {items?.length === 0 && <div className="muted">{t('emptyQueue')}</div>}
        {items?.length > 0 && (
          <div className="scroll">
            <table>
              <thead><tr><th>{t('product')}</th><th>{t('size')}</th><th className="num">{t('price')}</th><th>{t('barcode')}</th><th className="num">{t('copies')}</th><th></th></tr></thead>
              <tbody>
                {items.map((it) => (
                  <tr key={it.id}>
                    <td>{it.product_name}</td>
                    <td><b>{it.size}</b></td>
                    <td className="num">₹{Number(it.price)}</td>
                    <td className="mono">{it.barcode}</td>
                    <td className="num">
                      <input className="cell" type="number" min="1" style={{ width: 72 }} defaultValue={it.copies} key={it.copies}
                        aria-label={`${t('copies')} ${it.size}`} onBlur={(e) => setCopies(it, e.target.value)} />
                    </td>
                    <td className="num"><button type="button" className="xbtn" title={t('remove')} aria-label={`${t('remove')} ${it.size}`} onClick={() => remove(it)}><Icon name="x" /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <section className="panel">
          <label className="field">{t('labelSize')}
            <select id="lbl-layout" value={layout} onChange={(e) => chooseLayout(e.target.value)}>
              {layouts.map((l) => <option key={l.key} value={l.key}>{l.name}</option>)}
            </select>
          </label>
          {isSheet && (
            <label className="field">{t('skip')}
              <input type="number" id="lbl-skip" min="0" max="64" value={skip} onChange={(e) => setSkip(Math.max(0, +e.target.value || 0))} />
            </label>
          )}
          {total > 0
            ? <button type="button" className="btn go big" id="open-pdf" onClick={() => openPdf(pdfUrl).catch((e) => setError(e.message))}>{t('openPdf')} ({total})</button>
            : <button type="button" className="btn go big" disabled>{t('openPdf')}</button>}
          <p className="small muted" style={{ margin: 0 }}>{t('printHelp')}</p>
          {total > 0 && (confirming
            ? <div className="row"><button type="button" className="btn" style={{ background: 'var(--bad)', color: '#fff' }} onClick={clear}>{t('confirmClear')}</button>
                <button type="button" className="btn ghost" onClick={() => setConfirming(false)}>{t('cancel')}</button></div>
            : <button type="button" className="btn ghost" onClick={() => setConfirming(true)}>{t('clearList')}</button>)}
        </section>
        {testing ? <ScanTest /> : <button type="button" className="linkbtn small" style={{ alignSelf: 'center' }} onClick={() => setTesting(true)}>{t('scanTest')} →</button>}
      </div>
    </div>
  )
}

/** Scanner types the code + Enter. Shows what the code belongs to. */
function ScanTest() {
  const { t } = useLang()
  const [code, setCode] = useState('')
  const [hit, setHit] = useState(null)
  const ref = useRef(null)

  const look = async (e) => {
    e.preventDefault()
    const c = code.trim()
    if (!c) return
    try {
      const v = await api.lookupBarcode(c)
      setHit({ ok: true, text: `${v.product_name} · ${t('size')} ${v.size} · ₹${Number(v.price)} · ${t('stock')} ${v.stock}` })
    } catch {
      setHit({ ok: false, text: `${c}: ${t('notFound')}` })
    }
    setCode('')
    ref.current?.focus()
  }

  return (
    <form className="panel" onSubmit={look}>
      <h2>{t('scanTest')}</h2>
      <p className="small muted" style={{ margin: 0 }}>{t('scanTestHelp')}</p>
      <input ref={ref} type="text" id="scan-test" autoComplete="off" placeholder={t('scanPh')} value={code} onChange={(e) => setCode(e.target.value)} />
      {hit && <div className={`note ${hit.ok ? 'ok' : 'bad'}`} role="status">{hit.text}</div>}
    </form>
  )
}
