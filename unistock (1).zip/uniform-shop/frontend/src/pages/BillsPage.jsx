import { useLiveQuery } from 'dexie-react-hooks'
import { useState } from 'react'
import { api } from '../api.js'
import Icon from '../components/Icon.jsx'
import Receipt, { printReceipt } from '../components/Receipt.jsx'
import { useLang } from '../i18n.jsx'
import { db, getMeta } from '../offline/db.js'
import { syncNow } from '../offline/sync.js'

const money = (n) => '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 })

export default function BillsPage() {
  const { t } = useLang()
  const bills = useLiveQuery(() => db.bills.orderBy('number').reverse().limit(200).toArray(), [], [])
  const outbox = useLiveQuery(() => db.outbox.toArray(), [], [])
  const settings = useLiveQuery(() => getMeta('settings', {}), [], {})
  const [open, setOpen] = useState(null)
  const [findNo, setFindNo] = useState('')
  const [err, setErr] = useState('')
  const [day, setDay] = useState('today')

  // day filter + typed search (bill number, customer name or phone)
  const startOf = (offset) => { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() + offset); return d }
  const ranges = { today: [startOf(0), null], yesterday: [startOf(-1), startOf(0)], last7: [startOf(-6), null], all: [null, null] }
  const words = findNo.trim().toLowerCase()
  const shown = bills.filter((b) => {
    const [from, to] = ranges[day]
    const at = new Date(b.created_at)
    if (from && at < from) return false
    if (to && at >= to) return false
    if (!words) return true
    return String(b.number) === words || `${b.customer_name || ''} ${b.customer_phone || ''}`.toLowerCase().includes(words)
  })

  const problem = Object.fromEntries(outbox.filter((b) => b.sync_error).map((b) => [b.id, b.sync_error]))
  const statusOf = (b) => {
    if (b.status === 'cancelled') return ['out', t('cancelled')]
    if (problem[b.id]) return ['out', t('problem')]
    return b.synced ? ['ok', t('sent')] : ['low', t('notSent')]
  }

  const find = async (e) => {
    e.preventDefault()
    setErr('')
    const local = bills.find((b) => String(b.number) === findNo.trim())
    if (local) return setOpen(local)
    try {
      const r = await api.findBill(findNo.trim())
      if (!r.results.length) return setErr(`#${findNo}: —`)
      const b = r.results[0]
      setOpen({ ...b, lines: b.lines.map((l) => ({ ...l, price: Number(l.price) })), synced: true, fromServer: true })
    } catch (e2) {
      setErr(`${t('needsNet')}: ${e2.message}`)
    }
  }

  return (
    <div className="grid-main">
      <section className="panel">
        <form className="toolbar" onSubmit={find} style={{ gridTemplateColumns: 'minmax(160px, 220px) 1fr auto' }}>
          <select id="bills-day" value={day} onChange={(e) => setDay(e.target.value)} aria-label={t('period')} style={{ fontWeight: 700 }}>
            {['today', 'yesterday', 'last7'].map((k) => <option key={k} value={k}>{t(k)}</option>)}
            <option value="all">{t('allBills')}</option>
          </select>
          <div className="scan"><span className="ic"><Icon name="search" /></span>
            <input type="text" id="find-no" autoComplete="off" placeholder={t('billSearchPh')} value={findNo} onChange={(e) => setFindNo(e.target.value)} />
          </div>
          <button type="submit" className="btn ghost">{t('find')}</button>
        </form>
        {err && <div className="note bad">{err}</div>}
        {shown.length === 0 && <div className="empty">{bills.length === 0 ? t('noBillsYet') : t('noBillsHere')}</div>}
        <div className="scroll" hidden={shown.length === 0}>
          <table>
            <thead><tr><th>{t('billNo')}</th><th>&nbsp;</th><th className="num">{t('total')}</th><th>{t('cash')} / {t('upi')}</th><th>&nbsp;</th></tr></thead>
            <tbody>
              {shown.map((b) => {
                const [k, label] = statusOf(b)
                return (
                  <tr key={b.id} className={`clickrow ${open?.id === b.id ? 'sel' : ''}`} onClick={() => setOpen(b)}>
                    <td><b>#{b.number}</b></td>
                    <td className="small muted">{new Date(b.created_at).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}</td>
                    <td className="num"><b>{b.total < 0 ? '−' : ''}{money(Math.abs(b.total))}</b></td>
                    <td className="small">{b.cash_amount && b.upi_amount ? t('split') : b.upi_amount ? t('upi') : t('cash')}</td>
                    <td><span className={`pill ${k}`}>{label}</span>{b.lines.some((l) => l.qty < 0) && <span className="pill low" style={{ marginLeft: 4 }}>{t('returnTag')}</span>}</td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      </section>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        {!open && <div className="panel empty" style={{ border: 0 }}>{t('tapBill')}</div>}
        {open && <BillDetail key={open.id} bill={open} settings={settings} problem={problem[open.id]}
          onChanged={(b) => setOpen(b)} />}
      </div>
    </div>
  )
}

function BillDetail({ bill, settings, problem, onChanged }) {
  const { t } = useLang()
  const [asking, setAsking] = useState(false)
  const [reason, setReason] = useState('')
  const [err, setErr] = useState('')

  const cancel = async () => {
    setErr('')
    try {
      await syncNow() // make sure the bill has reached the server first
      const r = await api.cancelBill(bill.id, reason)
      await db.bills.update(bill.id, { status: 'cancelled' })
      await syncNow() // pull the corrected stock
      onChanged({ ...bill, status: r.status })
      setAsking(false)
    } catch (e) {
      setErr(e.message.startsWith('Cannot reach') ? `${t('cancelNeedsNet')} ${e.message}` : e.message)
    }
  }

  return (
    <section className="panel">
      {problem && <div className="note bad">{t('problem')}: {problem}</div>}
      <div style={{ display: 'flex', justifyContent: 'center' }}><Receipt bill={bill} settings={settings} /></div>
      <div className="row">
        <button type="button" className="btn" onClick={printReceipt}>{t('reprint')}</button>
        {bill.status !== 'cancelled' && !asking && (
          <button type="button" className="btn ghost" onClick={() => setAsking(true)}>{t('cancelBill')}</button>
        )}
      </div>
      {asking && (
        <>
          <label className="field">{t('cancelReason')}
            <input type="text" id="cancel-reason" value={reason} onChange={(e) => setReason(e.target.value)} />
          </label>
          <div className="row">
            <button type="button" className="btn" style={{ background: 'var(--bad)', color: '#fff' }} disabled={!reason.trim()} onClick={cancel}>{t('confirmCancel')}</button>
            <button type="button" className="btn ghost" onClick={() => setAsking(false)}>{t('cancel')}</button>
          </div>
          <p className="small muted" style={{ margin: 0 }}>{t('cancelNeedsNet')}</p>
        </>
      )}
      {err && <div className="note bad">{err}</div>}
    </section>
  )
}
