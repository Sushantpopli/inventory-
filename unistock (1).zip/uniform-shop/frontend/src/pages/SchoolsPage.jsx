import { useEffect, useState } from 'react'
import { api } from '../api.js'
import { useLang } from '../i18n.jsx'

export default function SchoolsPage() {
  const { t } = useLang()
  const [schools, setSchools] = useState(null)
  const [name, setName] = useState('')
  const [short, setShort] = useState('')
  const [msg, setMsg] = useState(null)

  const load = () => api.schools().then((d) => setSchools(d.results)).catch((e) => setMsg({ k: 'bad', text: e.message }))
  useEffect(() => { load() }, [])

  const add = async (e) => {
    e.preventDefault()
    if (!name.trim() || !short.trim()) return
    try {
      await api.addSchool({ name: name.trim(), short_name: short.trim().toUpperCase() })
      setMsg({ k: 'ok', text: `${t('saved')}: ${name.trim()}` })
      setName(''); setShort('')
      load()
    } catch (err) {
      setMsg({ k: 'bad', text: err.message })
    }
  }

  const toggle = async (s) => {
    await api.updateSchool(s.id, { active: !s.active }).catch((e) => setMsg({ k: 'bad', text: e.message }))
    load()
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <form className="panel" onSubmit={add}>
        <h2>{t('addSchool')}</h2>
        <div className="grid2">
          <label className="field">{t('schoolName')}
            <input type="text" id="s-name" value={name} onChange={(e) => setName(e.target.value)} />
          </label>
          <label className="field">{t('shortName')}
            <input type="text" id="s-short" maxLength={20} value={short} onChange={(e) => setShort(e.target.value)} />
          </label>
        </div>
        <div><button type="submit" className="btn">{t('addSchool')}</button></div>
        {msg && <div className={`note ${msg.k}`} role="status">{msg.text}</div>}
      </form>

      <section className="panel">
        <h2>{t('schools')} {schools && <span className="muted">({schools.length})</span>}</h2>
        <div className="scroll">
          <table>
            <thead><tr><th>{t('schoolName')}</th><th>{t('shortName')}</th><th className="num">{t('products')}</th><th></th></tr></thead>
            <tbody>
              {schools?.map((s) => (
                <tr key={s.id} style={{ opacity: s.active ? 1 : 0.5 }}>
                  <td><b>{s.name}</b></td>
                  <td className="mono">{s.short_name}</td>
                  <td className="num">{s.product_count}</td>
                  <td className="num"><button type="button" className="linkbtn" onClick={() => toggle(s)}>{s.active ? t('makeInactive') : t('makeActive')}</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  )
}
