import { useState } from 'react'
import { api, download } from '../api.js'
import { useLang } from '../i18n.jsx'

/** Step 1: check the file (nothing saved). Step 2: import. */
export default function ImportPage() {
  const { t } = useLang()
  const [file, setFile] = useState(null)
  const [createSchools, setCreateSchools] = useState(false)
  const [result, setResult] = useState(null)
  const [checkedOk, setCheckedOk] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const run = async (dryRun) => {
    if (!file) return
    setBusy(true); setError('')
    try {
      const r = await api.importExcel(file, dryRun, createSchools)
      setResult(r)
      setCheckedOk(dryRun && r.ok)
    } catch (e) {
      if (e.data?.errors) { setResult(e.data); setCheckedOk(false) } else setError(e.message)
    } finally {
      setBusy(false)
    }
  }

  const reset = (f) => { setFile(f); setResult(null); setCheckedOk(false) }

  return (
    <section className="panel">
      <h2>{t('import')}</h2>
      <p style={{ margin: 0, maxWidth: '65ch' }}>{t('importIntro')}</p>
      <div><button type="button" className="btn ghost" onClick={() => download(api.templateUrl, 'catalog_import_template.xlsx').catch((e) => setError(e.message))}>{t('getTemplate')}</button></div>

      <label className="field">{t('chooseFile')}
        <input type="file" id="imp-file" accept=".xlsx" onChange={(e) => reset(e.target.files[0] || null)} />
      </label>
      <label className="row" style={{ fontWeight: 600 }}>
        <input type="checkbox" id="imp-create" checked={createSchools} onChange={(e) => { setCreateSchools(e.target.checked); setCheckedOk(false) }} style={{ width: 20, height: 20 }} />
        {t('createSchools')}
      </label>

      <div className="row">
        <button type="button" className="btn" disabled={!file || busy} onClick={() => run(true)}>{busy ? t('checking') : t('check')}</button>
        <button type="button" className="btn go" disabled={!checkedOk || busy} onClick={() => run(false)}>{t('importNow')}</button>
      </div>

      {error && <div className="note bad" role="alert">{error}</div>}

      {result && (
        <>
          {result.ok
            ? <div className="note ok" role="status">{result.dry_run ? t('checkOk') : t('imported')}</div>
            : <div className="note bad" role="alert">{t('fixErrors')}</div>}
          {result.ok && (
            <div className="scroll"><table><tbody>
              <tr><td>{t('rowsRead')}</td><td className="num"><b>{result.rows_read}</b></td></tr>
              <tr><td>{t('newProducts')}</td><td className="num"><b>{result.products_new}</b></td></tr>
              <tr><td>{t('existingProducts')}</td><td className="num">{result.products_existing}</td></tr>
              <tr><td>{t('newSizes')}</td><td className="num"><b>{result.sizes_new}</b></td></tr>
              <tr><td>{t('skipped')}</td><td className="num">{result.sizes_skipped}</td></tr>
              <tr><td>{t('openUnits')}</td><td className="num">{result.units_opening}</td></tr>
              {result.categories_new?.length > 0 && <tr><td>{t('newItems')}</td><td className="num">{result.categories_new.join(', ')}</td></tr>}
            </tbody></table></div>
          )}
          {!result.ok && (
            <div className="scroll"><table>
              <thead><tr><th>{t('row')}</th><th>&nbsp;</th></tr></thead>
              <tbody>{result.errors.map((e, i) => <tr key={i}><td className="num" style={{ width: 70 }}>{e.row || '—'}</td><td>{e.message}</td></tr>)}</tbody>
            </table></div>
          )}
        </>
      )}
    </section>
  )
}
