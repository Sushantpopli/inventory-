import { useLiveQuery } from 'dexie-react-hooks'
import { useEffect, useState } from 'react'
import { api } from '../api.js'
import { isOwner } from '../auth.js'
import { prefs } from '../components/Receipt.jsx'
import { toast } from '../components/Toast.jsx'
import { useLang } from '../i18n.jsx'
import { db, getMeta } from '../offline/db.js'
import { syncNow, useSync } from '../offline/sync.js'

export default function SettingsPage() {
  const { t } = useLang()
  const sync = useSync()
  const [form, setForm] = useState(null)
  const [msg, setMsg] = useState(null)
  const [device, setDevice] = useState(prefs())
  const count = useLiveQuery(() => db.variants.count(), [], 0)
  const deviceName = useLiveQuery(() => getMeta('device', ''), [], '')
  const lastSync = useLiveQuery(() => getMeta('lastSync', null), [], null)

  useEffect(() => {
    api.shopSettings().then(setForm).catch(() => getMeta('settings', {}).then((s) => setForm({ ...s, offline: true })))
  }, [])

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value })
  const save = async (e) => {
    e.preventDefault()
    try {
      const { firm_name, phone, address, bill_footer, return_days, allow_discount, first_bill_number } = form
      setForm(await api.saveShopSettings({ firm_name, phone, address, bill_footer, return_days, allow_discount, first_bill_number }))
      await syncNow()
      setMsg(null); toast(t('saved'))
    } catch (err) {
      setMsg({ k: 'bad', text: err.message })
    }
  }
  const setPref = (k, v) => {
    try { localStorage.setItem(k, v) } catch { /* ignore */ }
    setDevice(prefs())
  }

  return (
    <div className="stack">
      <form className="panel" onSubmit={save}>
        {form?.offline && <div className="note warn">{t('needsNet')}</div>}
        {!isOwner() && <div className="note warn">{t('ownerOnly')}</div>}
        {form && (
          <>
            <div className="sect">
              <div><h2>{t('shopShort')}</h2><p className="help">{t('sectShopHelp')}</p></div>
              <div className="grid2">
                <label className="field">{t('firmName')}<input type="text" id="st-firm" value={form.firm_name || ''} onChange={set('firm_name')} /></label>
                <label className="field">{t('custPhone')}<input type="text" id="st-phone" value={form.phone || ''} onChange={set('phone')} /></label>
                <label className="field" style={{ gridColumn: '1 / -1' }}>{t('address')}<input type="text" id="st-address" value={form.address || ''} onChange={set('address')} /></label>
              </div>
            </div>
            <div className="sect">
              <div><h2>{t('sectBill')}</h2><p className="help">{t('sectBillHelp')}</p></div>
              <div className="grid2">
                <label className="field">{t('returnDays')}
                  <select id="st-days" value={String(form.return_days ?? 7)} onChange={set('return_days')}>
                    {[0, 3, 7, 10, 15, 30].map((d) => <option key={d} value={d}>{d === 0 ? t('noReturns') : `${d} ${t('daysWord')}`}</option>)}
                  </select>
                </label>
                <label className="field">{t('firstBillNo')}<input type="number" id="st-first" min="1" value={form.first_bill_number ?? 1} onChange={set('first_bill_number')} /></label>
                <label className="field" style={{ gridColumn: '1 / -1' }}>{t('footer')}<span className="help">{t('footerHelp')}</span>
                  <input type="text" id="st-footer" value={form.bill_footer || ''} onChange={set('bill_footer')} />
                </label>
                <label className="row" style={{ fontWeight: 700 }}>
                  <input type="checkbox" id="st-disc" checked={!!form.allow_discount} onChange={set('allow_discount')} style={{ width: 20, height: 20 }} />{t('allowDiscount')}
                </label>
              </div>
            </div>
            {isOwner() && <div className="row" style={{ justifyContent: 'flex-end' }}><button type="submit" className="btn" disabled={form.offline}>{t('saveSettings')}</button></div>}
          </>
        )}
        {msg && msg.k === 'bad' && <div className="note bad">{msg.text}</div>}
      </form>

      <section className="panel">
        <div className="sect">
          <div><h2>{t('thisComputer')}</h2><p className="help">{t('sectPcHelp')}</p></div>
          <div className="grid2">
            <label className="field">{t('paperWidth')}
              <select id="dev-paper" value={device.paper} onChange={(e) => setPref('paperWidth', e.target.value)}>
                <option value="80">80 mm</option><option value="58">58 mm</option>
              </select>
            </label>
            <label className="row" style={{ fontWeight: 700, gridColumn: '1 / -1', flexWrap: 'nowrap' }}>
              <input type="checkbox" id="dev-auto" checked={device.autoPrint} onChange={(e) => setPref('autoPrint', e.target.checked ? '1' : '0')} style={{ width: 20, height: 20 }} />{t('autoPrint')}
            </label>
            <dl className="facts" style={{ gridColumn: '1 / -1' }}>
              <div><dt>{t('itemsOnCounter')}</dt><dd>{count}</dd></div>
              <div><dt>{t('lastSync')}</dt><dd>{lastSync ? new Date(lastSync).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—'}</dd></div>
              <div><dt>{t('waiting')}</dt><dd>{sync.pending}</dd></div>
              <div><dt>{t('device')}</dt><dd className="mono">{deviceName}</dd></div>
            </dl>
            <div className="row" style={{ gridColumn: '1 / -1' }}>
              <button type="button" className="btn ghost" onClick={() => syncNow().then(() => toast(t('synced')))}>{t('syncNow')}</button>
              <button type="button" className="linkbtn small" onClick={() => syncNow({ full: true }).then(() => toast(t('synced')))}>{t('redownload')}</button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
