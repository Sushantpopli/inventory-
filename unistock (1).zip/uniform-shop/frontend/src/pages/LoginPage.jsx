import { useEffect, useState } from 'react'
import { api } from '../api.js'
import { setAuth } from '../auth.js'
import Icon from '../components/Icon.jsx'
import { useLang } from '../i18n.jsx'
import { syncNow } from '../offline/sync.js'

/** Tap your name, type your PIN on big buttons. No usernames to remember. */
export default function LoginPage() {
  const { t, lang, setLang } = useLang()
  const [people, setPeople] = useState(null)
  const [who, setWho] = useState(null)
  const [pin, setPin] = useState('')
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    api.people().then(setPeople).catch(() => { setPeople([]); setError(t('loginNeedsNet')) })
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const submit = async (code = pin) => {
    if (code.length < 4 || busy) return
    setBusy(true); setError('')
    try {
      const r = await api.login(who.id, code)
      setAuth({ token: r.token, user: r.user })
      syncNow({ full: true }) // download items for this counter right away
    } catch (e) {
      setError(e.message.includes('Wrong') ? t('wrongPin') : e.message)
      setPin('')
    } finally {
      setBusy(false)
    }
  }
  const press = (d) => {
    setError('')
    setPin((p) => (p.length < 6 ? p + d : p))
  }

  useEffect(() => {
    if (!who) return
    const onKey = (e) => {
      if (/^\d$/.test(e.key)) press(e.key)
      else if (e.key === 'Backspace') setPin((p) => p.slice(0, -1))
      else if (e.key === 'Enter') submit()
      else if (e.key === 'Escape') { setWho(null); setPin('') }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  })

  return (
    <div className="login">
      <div className="loginbox">
        <div className="loginlogo">
          <span className="crest"><Icon name="bag" /></span>
          <b>UniStock</b><span>{t('appTag')}</span>
        </div>

        {!who ? (
          <>
            <h2>{t('whoAreYou')}</h2>
            {people === null && <p className="muted" style={{ textAlign: 'center' }}>{t('loading')}</p>}
            {people?.length === 0 && !error && <div className="note warn">{t('noPeople')}</div>}
            <div className="people">
              {people?.map((p) => (
                <button key={p.id} type="button" className="person" onClick={() => setWho(p)}>
                  <span className="avatar">{p.name.trim().charAt(0).toUpperCase()}</span>
                  <b>{p.name}</b><span>{p.role === 'owner' ? t('owner') : t('counterRole')}</span>
                </button>
              ))}
            </div>
            {error && <div className="note bad">{error}</div>}
          </>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 18, alignItems: 'center' }}>
            <h1>{who.name}</h1>
            <p className="muted" style={{ margin: '-10px 0 0' }}>{t('enterPin')}</p>
            <div className="pindots" aria-label={`${pin.length} digits`}>
              {[0, 1, 2, 3, 4, 5].map((i) => <span key={i} className={i < pin.length ? 'on' : ''} />)}
            </div>
            {error && <div className="note bad" role="alert">{error}</div>}
            <div className="pinpad">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
                <button key={d} type="button" onClick={() => press(d)}>{d}</button>
              ))}
              <button type="button" className="muted-key" aria-label={t('back')} onClick={() => setPin((p) => p.slice(0, -1))}>⌫</button>
              <button type="button" onClick={() => press('0')}>0</button>
              <button type="button" className="ok-key" disabled={pin.length < 4 || busy} onClick={() => submit()}>OK</button>
            </div>
            <button type="button" className="linkbtn" onClick={() => { setWho(null); setPin(''); setError('') }}>← {t('back')}</button>
          </div>
        )}

        <div className="langtoggle" role="group" aria-label="Language" style={{ alignSelf: 'center' }}>
          <button type="button" aria-pressed={lang === 'en'} onClick={() => setLang('en')}>English</button>
          <button type="button" aria-pressed={lang === 'hi'} onClick={() => setLang('hi')}>हिंदी</button>
        </div>
        <div className="loginfoot"><Icon name="lock" />{t('protectedAccess')}</div>
      </div>
    </div>
  )
}
