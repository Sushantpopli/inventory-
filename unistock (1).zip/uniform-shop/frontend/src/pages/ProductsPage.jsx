import { useCallback, useEffect, useState } from 'react'
import { api } from '../api.js'
import { isOwner } from '../auth.js'
import Icon from '../components/Icon.jsx'
import ProductForm from '../components/ProductForm.jsx'
import SearchSelect from '../components/SearchSelect.jsx'
import VariantTable from '../components/VariantTable.jsx'
import { catName, useLang } from '../i18n.jsx'

export default function ProductsPage() {
  const { t, lang } = useLang()
  const [schools, setSchools] = useState([])
  const [categories, setCategories] = useState([])
  const [school, setSchool] = useState('') // '' = all, 'common', or id
  const [q, setQ] = useState('')
  const [products, setProducts] = useState(null)
  const [open, setOpen] = useState(null)
  const [adding, setAdding] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    Promise.all([api.schools(), api.categories()])
      .then(([s, c]) => { setSchools(s.results); setCategories(c) })
      .catch((e) => setError(e.message))
  }, [])

  const load = useCallback(() => {
    api.products({ school, q })
      .then((d) => { setProducts(d.results); setError('') })
      .catch((e) => setError(e.message))
  }, [school, q])
  useEffect(() => { load() }, [load])

  const catById = Object.fromEntries(categories.map((c) => [c.id, c]))
  const totalStock = (p) => p.variants.reduce((a, v) => a + v.stock, 0)
  const priceRange = (p) => {
    const ps = p.variants.map((v) => Number(v.price))
    if (!ps.length) return ''
    const lo = Math.min(...ps), hi = Math.max(...ps)
    return lo === hi ? `₹${lo}` : `₹${lo} – ₹${hi}`
  }
  const lowCount = (p) => p.variants.filter((v) => v.stock <= v.low_stock_level).length

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14, minWidth: 0 }}>
        {adding ? (
          <ProductForm categories={categories} schools={schools} defaultSchoolId={school}
            onCancel={() => setAdding(false)}
            onSaved={(p) => { setAdding(false); setOpen(p.id); load() }} />
        ) : (
          <div className="toolbar">
            <SearchSelect id="prod-school" value={school} onChange={setSchool} placeholder={t('allSchools')} searchPh={t('searchSchool')}
              options={[{ value: '', label: t('allSchools') }, { value: 'common', label: t('common') },
                ...schools.filter((s) => s.active).map((s) => ({ value: s.id, label: s.name }))]} />
            <div className="scan" style={{ flex: 1 }}><span className="ic"><Icon name="search" /></span>
              <input type="search" id="prod-q" placeholder={t('search')} value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
            {isOwner() && <button type="button" className="btn" onClick={() => setAdding(true)}>+ {t('addProduct')}</button>}
          </div>
        )}

        {error && <div className="note bad" role="alert">{error}</div>}
        {products === null && !error && <p className="muted">{t('loading')}</p>}
        {products?.length === 0 && <div className="panel muted">{t('noProducts')}</div>}

        <div className="plist">
          {products?.map((p) => (
            <article key={p.id} className="pcard">
              <button type="button" className="head" aria-expanded={open === p.id} onClick={() => setOpen(open === p.id ? null : p.id)}>
                <span className="title">
                  <b>{catName(catById[p.category], lang) || p.category_name}</b>
                  {p.name && <span> · {p.name}</span>}
                  <span className="tag">{p.school_names.length ? p.school_names.join(', ') : t('common')}</span>
                  <span className="tag">{t(p.season === 'all' ? 'allSeason' : p.season)}</span>
                  <span className="tag">{t(p.gender)}</span>
                </span>
                <span className="small muted">
                  {p.variants.length} {t(p.variants.length === 1 ? 'sizeOne' : 'sizesCount')} · {priceRange(p)} · {totalStock(p)} {t('units')}
                  {lowCount(p) > 0 && <span className="pill low" style={{ marginLeft: 8 }}>{lowCount(p)} {t('lowStock')}</span>}
                </span>
              </button>
              {open === p.id && <VariantTable product={p} onChanged={load} />}
            </article>
          ))}
        </div>
    </div>
  )
}
