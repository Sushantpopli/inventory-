import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api.js'
import { isOwner } from '../auth.js'
import { catName, useLang } from '../i18n.jsx'
import { syncNow, useSync } from '../offline/sync.js'
import Icon from '../components/Icon.jsx'

const money = (n) => '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 })

// one row per size: { variant, item, size, stock, qty, cost, price, oldPrice }
function lineFrom(v, item) {
  return {
    variant: v.id, item, size: v.size, stock: v.stock, qty: '',
    cost: v.cost_price == null ? '' : String(Number(v.cost_price)),
    price: String(Number(v.price)), oldPrice: Number(v.price),
  }
}

export default function StockInPage() {
  const { t } = useLang()
  const sync = useSync()
  const [note, setNote] = useState('')
  const [lines, setLines] = useState([])
  const [addLabels, setAddLabels] = useState(true)
  const [how, setHowState] = useState(() => { try { return localStorage.getItem('stockMode') || 'scanner' } catch { return 'scanner' } })
  const setHow = (h) => { setHowState(h); try { localStorage.setItem('stockMode', h) } catch { /* ignore */ } }
  const [msg, setMsg] = useState(null)
  const [saving, setSaving] = useState(false)
  const [entries, setEntries] = useState([])
  const loadEntries = () => api.stockEntries().then((d) => setEntries(d.results)).catch(() => {})
  useEffect(() => { loadEntries() }, [])

  const addVariant = (v, item, plusOne) => {
    setLines((ls) => {
      const i = ls.findIndex((l) => l.variant === v.id)
      if (i >= 0) return plusOne ? ls.map((l, j) => (j === i ? { ...l, qty: String((+l.qty || 0) + 1) } : l)) : ls
      const l = lineFrom(v, item)
      if (plusOne) l.qty = '1'
      return [...ls, l]
    })
  }
  const setLine = (i, k, val) => setLines((ls) => ls.map((l, j) => (j === i ? { ...l, [k]: val } : l)))

  const filled = lines.filter((l) => +l.qty > 0)
  const pieces = filled.reduce((a, l) => a + +l.qty, 0)
  const cost = filled.filter((l) => l.cost !== '').reduce((a, l) => a + +l.qty * +l.cost, 0)
  const priceChanged = filled.some((l) => l.price !== '' && +l.price !== l.oldPrice)

  const save = async () => {
    setMsg(null)
    setSaving(true)
    try {
      const e = await api.saveStockIn({
        note: note.trim(), add_labels: addLabels,
        lines: filled.map((l) => ({
          variant: l.variant, qty: +l.qty,
          cost_price: l.cost === '' ? null : l.cost,
          price: l.price === '' ? null : l.price,
        })),
      })
      setMsg({ k: 'ok', text: `${t('stockIn')} #${e.number} ${t('stockSaved')}: ${e.total_qty} ${t('units')}.` + (addLabels ? ` ${e.total_qty} ${t('labelsAdded')}.` : ''), labels: addLabels })
      setLines([])
      setNote('')
      loadEntries()
      syncNow() // counter picks up the new stock and prices
    } catch (err) {
      setMsg({ k: 'bad', text: err.message })
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className={entries.length ? 'grid-main' : ''}>
      <section className="panel">
        <div className="modes" role="group">
          <button type="button" id="si-mode-scanner" aria-pressed={how === 'scanner'} onClick={() => setHow('scanner')}><Icon name="scan" />{t('scannerMode')}</button>
          <button type="button" id="si-mode-manual" aria-pressed={how === 'manual'} onClick={() => setHow('manual')}><Icon name="hand" />{t('manualMode')}</button>
        </div>
        {!sync.online && <div className="note warn">{t('stockInNeedsNet')}</div>}

        {how === 'scanner' ? <ScanBox onAdd={addVariant} /> : <ProductPicker onPick={(p) => p.variants.forEach((v) => addVariant(v, p.display_name, false))} />}

        {lines.length === 0 ? (
          <div className="empty">{t('emptyStockIn')}</div>
        ) : (
          <div className="scroll">
            <table>
              <thead><tr>
                <th>{t('product')}</th><th>{t('size')}</th><th className="num">{t('nowInStock')}</th>
                <th className="num">{t('qtyIn')}</th><th className="num">{t('costEach')}</th><th className="num">{t('sellPrice')}</th><th></th>
              </tr></thead>
              <tbody>
                {lines.map((l, i) => {
                  const changed = l.price !== '' && +l.price !== l.oldPrice
                  return (
                    <tr key={l.variant} style={{ opacity: +l.qty > 0 ? 1 : 0.65 }}>
                      <td>{l.item}</td>
                      <td><b>{l.size}</b></td>
                      <td className="num">{l.stock}</td>
                      <td className="num"><input className="cell qtyin" type="number" min="0" value={l.qty} aria-label={`${t('qtyIn')} ${l.size}`} onChange={(e) => setLine(i, 'qty', e.target.value)} /></td>
                      <td className="num"><input className="cell" disabled={!isOwner()} type="number" min="0" value={l.cost} aria-label={`${t('costEach')} ${l.size}`} onChange={(e) => setLine(i, 'cost', e.target.value)} /></td>
                      <td className="num">
                        <input className="cell" disabled={!isOwner()} type="number" min="0" value={l.price} aria-label={`${t('sellPrice')} ${l.size}`} onChange={(e) => setLine(i, 'price', e.target.value)}
                          style={changed ? { borderColor: 'var(--warn)' } : undefined} />
                        {changed && <div className="small" style={{ color: 'var(--warn)' }}>{t('newPrice')} {money(l.oldPrice)}</div>}
                      </td>
                      <td className="num"><button type="button" className="linkbtn" onClick={() => setLines((ls) => ls.filter((_, j) => j !== i))}>{t('remove')}</button></td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}

        {priceChanged && <div className="note warn">{t('priceChangeNote')}</div>}
        <div className="grid2">
          <label className="field" style={{ maxWidth: 420 }}>{t('fromWhere')}
            <select id="si-from" value={[t('ownFactory'), t('manufacturer'), ''].includes(note) ? note : '__other'} onChange={(e) => setNote(e.target.value === '__other' ? ' ' : e.target.value)}>
              <option value="">—</option>
              <option value={t('ownFactory')}>{t('ownFactory')}</option>
              <option value={t('manufacturer')}>{t('manufacturer')}</option>
              <option value="__other">{t('otherSource')}</option>
            </select>
          </label>
          {![t('ownFactory'), t('manufacturer'), ''].includes(note) && (
            <label className="field">{t('fromName')}
              <input type="text" id="si-note" value={note.trim()} placeholder={t('fromPh')} onChange={(e) => setNote(e.target.value || ' ')} />
            </label>
          )}
        </div>
        <div className="row spread">
          <span>{t('pieces')}: <b>{pieces}</b>{cost > 0 && <> · {t('totalCost')}: <b>{money(cost)}</b></>}</span>
          <label className="row" style={{ fontWeight: 600 }}>
            <input type="checkbox" id="si-labels" checked={addLabels} onChange={(e) => setAddLabels(e.target.checked)} style={{ width: 20, height: 20 }} />
            {t('addLabelsToo')}
          </label>
        </div>
        <button type="button" className="btn go big" id="si-save" disabled={!pieces || saving || !sync.online} onClick={save}>{t('saveStockIn')}</button>
        {msg && (
          <div className={`note ${msg.k}`} role="status">
            {msg.text} {msg.labels && msg.k === 'ok' && <Link to="/labels">{t('goLabels')} →</Link>}
          </div>
        )}
      </section>

      {entries.length > 0 && <RecentEntries entries={entries} onChanged={() => { loadEntries(); syncNow() }} />}
    </div>
  )
}

/** Scan = +1 piece. Typed words + Enter = search; one match is added, several are listed. */
function ScanBox({ onAdd }) {
  const { t } = useLang()
  const [q, setQ] = useState('')
  const [found, setFound] = useState(null)
  const [err, setErr] = useState('')
  const ref = useRef(null)

  const go = async (e) => {
    e.preventDefault()
    const code = q.trim()
    if (!code) return
    setQ(''); setErr(''); setFound(null)
    try {
      const v = await api.lookupBarcode(code).catch(() => null)
      if (v) return onAdd(v, v.product_name, true)
      const r = await api.searchVariants(code)
      if (r.results.length === 1) return onAdd(r.results[0], r.results[0].product_name, true)
      if (!r.results.length) setErr(`"${code}": ${t('noResults')}`)
      else setFound(r.results)
    } finally {
      ref.current?.focus()
    }
  }

  return (
    <form onSubmit={go} className="field">
      <div className="scan big">
        <span className="ic"><Icon name="scan" /></span>
        <input ref={ref} type="text" id="si-scan" autoComplete="off" value={q} placeholder={t('scanOrSearch')} onChange={(e) => setQ(e.target.value)} />
      </div>
      {err && <div className="note bad">{err}</div>}
      {found && (
        <div className="results">
          {found.map((v) => (
            <button key={v.id} type="button" className="res" onClick={() => { onAdd(v, v.product_name, true); setFound(null) }}>
              <span><b>{v.product_name}</b> · {t('size')} {v.size}</span><em>{money(v.price)} · {v.stock}</em>
            </button>
          ))}
        </div>
      )}
    </form>
  )
}

/** School → product → all its sizes go into the list (quantities typed after). */
function ProductPicker({ onPick }) {
  const { t, lang } = useLang()
  const [schools, setSchools] = useState([])
  const [school, setSchool] = useState('')
  const [products, setProducts] = useState([])
  useEffect(() => { api.schools({ active: 1 }).then((d) => setSchools(d.results.filter((s) => s.active))).catch(() => {}) }, [])
  useEffect(() => {
    if (!school) { setProducts([]); return }
    api.products({ school }).then((d) => setProducts(d.results)).catch(() => setProducts([]))
  }, [school])

  return (
    <div className="field">{t('orPick')}
      <div className="row">
        <select id="si-school" value={school} onChange={(e) => setSchool(e.target.value)} aria-label={t('pickSchool')}>
          <option value="">{t('pickSchool')}…</option>
          <option value="common">{t('common')}</option>
          {schools.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
        </select>
      </div>
      {products.length > 0 && (
        <div className="chips">
          {products.map((p) => (
            <button key={p.id} type="button" className="chip" onClick={() => onPick(p)}>
              + {catName({ name: p.category_name }, lang)}{p.name ? ` · ${p.name}` : ''} <span className="muted small">({t(p.season === 'all' ? 'allSeason' : p.season)}, {t(p.gender)})</span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

function RecentEntries({ entries, onChanged }) {
  const { t } = useLang()
  const [open, setOpen] = useState(null)
  const [reason, setReason] = useState('')
  const [asking, setAsking] = useState(false)
  const [err, setErr] = useState('')

  const cancel = async (e) => {
    setErr('')
    try {
      await api.cancelStockIn(e.id, reason)
      setAsking(false); setReason('')
      onChanged()
    } catch (x) {
      setErr(x.message)
    }
  }

  return (
    <section className="panel">
      <h2>{t('recentEntries')}</h2>
      {entries.length === 0 && <p className="muted">—</p>}
      {entries.map((e) => (
        <div key={e.id} className="pcard">
          <button type="button" className="head" aria-expanded={open === e.id} onClick={() => { setOpen(open === e.id ? null : e.id); setAsking(false) }}>
            <span><b>#{e.number}</b> · {new Date(e.created_at).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
              {e.note && <span className="muted"> · {e.note}</span>}</span>
            <span>{e.status === 'cancelled' ? <span className="pill out">{t('entryCancelled')}</span> : <b>{e.total_qty} {t('pieces')}</b>}</span>
          </button>
          {open === e.id && (
            <div className="body">
              <table><tbody>
                {e.lines.map((l, i) => (
                  <tr key={i}><td className="small">{l.item}</td><td><b>{l.size}</b></td><td className="num">+{l.qty}</td>
                    <td className="num small">{money(l.price)}{l.price_changed && <span className="muted"> ({money(l.old_price)})</span>}</td></tr>
                ))}
              </tbody></table>
              {e.status !== 'cancelled' && isOwner() && (asking ? (
                <>
                  <input type="text" id="si-cancel-reason" placeholder={t('cancelReason')} value={reason} onChange={(x) => setReason(x.target.value)} />
                  <div className="row">
                    <button type="button" className="btn danger" disabled={!reason.trim()} onClick={() => cancel(e)}>{t('cancelEntry')}</button>
                    <button type="button" className="btn ghost" onClick={() => setAsking(false)}>{t('cancel')}</button>
                  </div>
                </>
              ) : <div><button type="button" className="linkbtn" onClick={() => setAsking(true)}>{t('cancelEntry')}</button></div>)}
              {err && <div className="note bad">{err}</div>}
            </div>
          )}
        </div>
      ))}
    </section>
  )
}
