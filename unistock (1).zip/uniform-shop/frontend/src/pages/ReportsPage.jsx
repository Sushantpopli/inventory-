import { useEffect, useState } from 'react'
import { api, download } from '../api.js'
import { useLang } from '../i18n.jsx'

const money = (n) => '₹' + Math.round(Number(n)).toLocaleString('en-IN')
const fmt = (x) => new Date(x + 'T00:00').toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })
const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`

function presets() {
  const t = new Date()
  const d = (offset) => { const x = new Date(t); x.setDate(x.getDate() + offset); return x }
  const first = new Date(t.getFullYear(), t.getMonth(), 1)
  const lastMonthEnd = new Date(t.getFullYear(), t.getMonth(), 0)
  const lastMonthStart = new Date(lastMonthEnd.getFullYear(), lastMonthEnd.getMonth(), 1)
  return {
    today: [iso(t), iso(t)],
    yesterday: [iso(d(-1)), iso(d(-1))],
    last7: [iso(d(-6)), iso(t)],
    thisMonth: [iso(first), iso(t)],
    lastMonth: [iso(lastMonthStart), iso(lastMonthEnd)],
  }
}

export default function ReportsPage() {
  const { t } = useLang()
  const P = presets()
  const [preset, setPreset] = useState('today')
  const [range, setRange] = useState(P.today)
  const [data, setData] = useState(null)
  const [by, setBy] = useState('size')
  const [top, setTop] = useState([])
  const [error, setError] = useState('')

  useEffect(() => {
    setError('')
    api.reportSummary(...range).then(setData).catch((e) => { setData(null); setError(`${t('reportsNeedNet')} ${e.message}`) })
  }, [range]) // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    api.reportTop(...range, by).then((d) => setTop(d.rows)).catch(() => setTop([]))
  }, [range, by])

  const choose = (k) => { setPreset(k); setRange(P[k]) }
  const ly = data?.last_year

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <section className="panel compact">
        <div className="row spread">
          <div className="row">
            <select id="rep-period" value={preset} onChange={(e) => { const k = e.target.value; if (k === 'custom') setPreset('custom'); else choose(k) }} aria-label={t('period')} style={{ minWidth: 200, fontWeight: 700 }}>
              {['today', 'yesterday', 'last7', 'thisMonth', 'lastMonth'].map((k) => <option key={k} value={k}>{t(k)}</option>)}
              <option value="custom">{t('customDates')}</option>
            </select>
            {preset === 'custom' && <>
              <label className="row small">{t('fromDate')}<input type="date" id="rep-from" value={range[0]} onChange={(e) => setRange([e.target.value, range[1]])} /></label>
              <label className="row small">{t('toDate')}<input type="date" id="rep-to" value={range[1]} onChange={(e) => setRange([range[0], e.target.value])} /></label>
            </>}
            {preset !== 'custom' && <span className="small muted">{fmt(range[0])}{range[0] !== range[1] && ` – ${fmt(range[1])}`}</span>}
          </div>
          <button type="button" className="btn ghost" onClick={() => download(api.salesXlsxUrl(...range), `sales_${range[0]}_${range[1]}.xlsx`).catch((e) => setError(e.message))}>{t('downloadExcel')}</button>
        </div>
        {error && <div className="note bad">{error}</div>}
      </section>

      {data && (
        <>
          <div className="tiles three">
            <Tile main label={t('net')} value={money(data.net)}
              sub={[`${t('cash')} ${money(data.cash)}`, `${t('upi')} ${money(data.upi)}`, Number(data.credit_used) > 0 && `${t('creditNote')} ${money(data.credit_used)}`].filter(Boolean).join('  ·  ')} />
            <Tile label={t('bills')} value={data.bills} sub={[`${data.pieces_sold} ${t('units')}`, Number(data.returns) > 0 && `${t('returnsV')} ${money(data.returns)}`, Number(data.discount) > 0 && `${t('discount')} ${money(data.discount)}`].filter(Boolean).join('  ·  ')} />
            <Tile label={t('profit')} value={data.profit == null ? '—' : money(data.profit)}
              sub={data.pieces_without_cost ? `${data.pieces_without_cost} ${t('noCostNote')}` : null} />
          </div>
          {ly && <p className="small muted" style={{ margin: 0 }}>{t('lastYear')}: {t('net')} {money(ly.net)} · {ly.bills} {t('bills').toLowerCase()}</p>}

          {data.days.length > 1 && (
            <section className="panel">
              <h2>{t('dayWise')}</h2>
              <DayChart days={data.days} />
            </section>
          )}

            <section className="panel" id="top-sold">
              <div className="row spread"><h2>{t('topSold')}</h2>
              <div className="seg">
                {[['size', 'bySize'], ['product', 'byProduct'], ['school', 'bySchool'], ['category', 'byCategory']].map(([k, label]) => (
                  <button key={k} type="button" aria-pressed={by === k} onClick={() => setBy(k)}>{t(label)}</button>
                ))}
              </div></div>
              {top.length === 0 ? <p className="muted">{t('noSales')}</p> : (
                <div className="scroll"><table>
                  <thead><tr><th>{t('product')}</th>{by === 'size' && <th>{t('size')}</th>}<th className="num">{t('piecesNet')}</th><th className="num">{t('amount')}</th></tr></thead>
                  <tbody>{top.map((r, i) => (
                    <tr key={i}><td>{r.name}</td>{by === 'size' && <td><b>{r.size}</b></td>}<td className="num"><b>{r.qty}</b></td><td className="num">{money(r.amount)}</td></tr>
                  ))}</tbody>
                </table></div>
              )}
            </section>
        </>
      )}
    </div>
  )
}

function Tile({ label, value, sub, main }) {
  return (
    <div className={`tile ${main ? 'main' : ''}`}>
      <span>{label}</span>
      <b>{value}</b>
      {sub && <small>{sub}</small>}
    </div>
  )
}

/** One series (net sale per day): thin bars from a zero baseline, value on hover. */
function DayChart({ days }) {
  const { t } = useLang()
  const [hover, setHover] = useState(null)
  const W = 1000, H = 240, padL = 52, padB = 26, padT = 12
  const vals = days.map((d) => Number(d.net))
  const max = Math.max(...vals, 0), min = Math.min(...vals, 0)
  const span = max - min || 1
  const step = niceStep(span)
  const top = Math.ceil(max / step) * step, bottom = Math.floor(min / step) * step
  const y = (v) => padT + (top - v) / ((top - bottom) || 1) * (H - padT - padB)
  const slot = (W - padL) / days.length
  const bw = Math.max(Math.min(slot * 0.6, 36), 3)
  const ticks = []
  for (let v = bottom; v <= top + 1e-9; v += step) ticks.push(v)
  const labelEvery = Math.ceil(days.length / 8)
  const h = hover != null ? days[hover] : null

  return (
    <div style={{ position: 'relative' }}>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" role="img" aria-label={t('dayWise')} onMouseLeave={() => setHover(null)}>
        {ticks.map((v) => (
          <g key={v}>
            <line x1={padL} x2={W} y1={y(v)} y2={y(v)} stroke="var(--line)" strokeWidth={v === 0 ? 1.5 : 1} />
            <text x={padL - 6} y={y(v) + 4} textAnchor="end" fontSize="11" fill="var(--muted)">{short(v)}</text>
          </g>
        ))}
        {days.map((d, i) => {
          const v = Number(d.net)
          const x = padL + i * slot + (slot - bw) / 2
          const y0 = y(0), y1 = y(v)
          return (
            <g key={d.day} onMouseEnter={() => setHover(i)}>
              <rect x={padL + i * slot} y={padT} width={slot} height={H - padT - padB} fill="transparent" />
              {v !== 0 && <rect x={x} y={Math.min(y0, y1)} width={bw} height={Math.max(Math.abs(y1 - y0), 1)} rx={Math.min(4, bw / 2)}
                fill={v < 0 ? 'var(--accent)' : 'var(--primary)'} opacity={hover == null || hover === i ? 1 : 0.55} />}
              {i % labelEvery === 0 && <text x={padL + i * slot + slot / 2} y={H - 8} textAnchor="middle" fontSize="11" fill="var(--muted)">{d.day.slice(8)}/{d.day.slice(5, 7)}</text>}
            </g>
          )
        })}
      </svg>
      {h && (
        <div className="charttip" style={{ left: `${Math.min(Math.max(((padL + hover * slot + slot / 2) / W) * 100, 10), 90)}%` }}>
          <b>{new Date(h.day).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}</b>
          <span>{money(h.net)} · {h.bills} {t('bills').toLowerCase()}</span>
          <span className="small">{t('cash')} {money(h.cash)} · {t('upi')} {money(h.upi)}</span>
        </div>
      )}
    </div>
  )
}

function niceStep(span) {
  const raw = span / 4
  const p = Math.pow(10, Math.floor(Math.log10(raw)))
  return [1, 2, 2.5, 5, 10].map((m) => m * p).find((s) => s >= raw)
}
const short = (v) => (Math.abs(v) >= 100000 ? `${(v / 100000).toFixed(1)}L` : Math.abs(v) >= 1000 ? `${(v / 1000).toFixed(v % 1000 ? 1 : 0)}k` : String(v))
