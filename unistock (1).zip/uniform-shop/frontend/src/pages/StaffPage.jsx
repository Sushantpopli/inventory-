import { useEffect, useState } from 'react'
import { api } from '../api.js'
import { useLang } from '../i18n.jsx'

/** Owner only: who can use the software, their role and PIN. */
export default function StaffPage() {
  const { t } = useLang()
  const [rows, setRows] = useState([])
  const [form, setForm] = useState({ display_name: '', role: 'counter', pin: '' })
  const [pinFor, setPinFor] = useState(null)
  const [newPin, setNewPin] = useState('')
  const [msg, setMsg] = useState(null)

  const load = () => api.staff().then(setRows).catch((e) => setMsg({ k: 'bad', text: e.message }))
  useEffect(() => { load() }, [])
  const run = async (fn, ok) => {
    try { await fn(); setMsg({ k: 'ok', text: ok }); load() } catch (e) { setMsg({ k: 'bad', text: e.message }) }
  }

  const add = (e) => {
    e.preventDefault()
    run(async () => {
      await api.addStaff(form)
      setForm({ display_name: '', role: 'counter', pin: '' })
    }, `${t('saved')}: ${form.display_name}`)
  }

  return (
    <div className="grid-main">
      <section className="panel">
        <h2>{t('staff')}</h2>
        <p className="small muted" style={{ margin: 0 }}>{t('staffHelp')}</p>
        {msg && <div className={`note ${msg.k}`} role="status">{msg.text}</div>}
        <div className="scroll"><table>
          <thead><tr><th>{t('personName')}</th><th>{t('role')}</th><th></th></tr></thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} style={{ opacity: r.active ? 1 : 0.5 }}>
                <td><b>{r.display_name}</b>{!r.active && <span className="pill out" style={{ marginLeft: 6 }}>{t('inactiveStaff')}</span>}</td>
                <td>
                  <select value={r.role} aria-label={`${t('role')} ${r.display_name}`}
                    onChange={(e) => run(() => api.updateStaff(r.id, { role: e.target.value }), t('saved'))}>
                    <option value="counter">{t('counterRole')}</option>
                    <option value="owner">{t('owner')}</option>
                  </select>
                </td>
                <td className="num small" style={{ whiteSpace: 'nowrap' }}>
                  {pinFor === r.id ? (
                    <span className="row" style={{ justifyContent: 'flex-end' }}>
                      <input className="cell" type="password" inputMode="numeric" maxLength={6} placeholder={t('newPin')} value={newPin}
                        onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))} aria-label={t('newPin')} />
                      <button type="button" className="btn" onClick={() => run(async () => { await api.updateStaff(r.id, { pin: newPin }); setPinFor(null); setNewPin('') }, t('saved'))}>{t('saveShort')}</button>
                    </span>
                  ) : (
                    <>
                      <button type="button" className="linkbtn" onClick={() => { setPinFor(r.id); setNewPin('') }}>{t('setPin')}</button>{' · '}
                      <button type="button" className="linkbtn" onClick={() => run(() => api.updateStaff(r.id, { active: !r.active }), t('saved'))}>{r.active ? t('disable') : t('enable')}</button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table></div>
      </section>

      <form className="panel" onSubmit={add}>
        <h2>{t('addPerson')}</h2>
        <label className="field">{t('personName')}<input type="text" id="sf-name" value={form.display_name} onChange={(e) => setForm({ ...form, display_name: e.target.value })} /></label>
        <div className="field">{t('role')}
          <div className="seg">
            {[['counter', t('counterRole')], ['owner', t('owner')]].map(([k, label]) => (
              <button key={k} type="button" aria-pressed={form.role === k} onClick={() => setForm({ ...form, role: k })}>{label}</button>
            ))}
          </div>
        </div>
        <label className="field">{t('pin')}<input type="password" id="sf-pin" inputMode="numeric" maxLength={6} value={form.pin} onChange={(e) => setForm({ ...form, pin: e.target.value.replace(/\D/g, '') })} /></label>
        <button type="submit" className="btn" disabled={!form.display_name.trim() || form.pin.length < 4}>{t('addPerson')}</button>
      </form>
    </div>
  )
}
