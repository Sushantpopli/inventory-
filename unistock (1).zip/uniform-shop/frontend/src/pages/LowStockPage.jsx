import { useEffect, useState } from 'react'
import { api, download } from '../api.js'
import SearchSelect from '../components/SearchSelect.jsx'
import { useLang } from '../i18n.jsx'

/** Sizes at or below their warning level, grouped by product, ready to send to the factory. */
export default function LowStockPage() {
  const { t } = useLang()
  const [schools, setSchools] = useState([])
  const [school, setSchool] = useState('')
  const [groups, setGroups] = useState(null)
  const [error, setError] = useState('')
  const [msg, setMsg] = useState(null)

  useEffect(() => { api.schools().then((d) => setSchools(d.results.filter((s) => s.active))).catch(() => {}) }, [])
  useEffect(() => {
    setGroups(null)
    api.lowStock(school).then((d) => { setGroups(d.groups); setError('') }).catch((e) => setError(`${t('reportsNeedNet')} ${e.message}`))
  }, [school]) // eslint-disable-line react-hooks/exhaustive-deps

  const text = groups ? [
    `${t('orderList')} — ${new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}`,
    ...groups.map((g) => `${g.product}: ${g.sizes.map((s) => `${s.size} × ${s.suggest}`).join(', ')}`),
  ].join('\n') : ''

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text)
      setMsg({ k: 'ok', text: t('copied') })
    } catch {
      setMsg({ k: 'warn', text: t('copyFail') })
      const el = document.getElementById('order-text')
      el?.focus(); el?.select()
    }
  }

  return (
    <div className="grid-main">
      <section className="panel">
        <div className="row spread">
          <h2>{t('lowStockTab')}</h2>
          <div style={{ width: 280, maxWidth: '100%' }}>
            <SearchSelect id="low-school" value={school} onChange={setSchool} placeholder={t('allSchools')} searchPh={t('searchSchool')}
              options={[{ value: '', label: t('allSchools') }, { value: 'common', label: t('common') }, ...schools.map((x) => ({ value: x.id, label: x.name }))]} />
          </div>
        </div>
        <p className="small muted" style={{ margin: 0 }}>{t('lowHelp')}</p>
        {error && <div className="note bad">{error}</div>}
        {groups === null && !error && <p className="muted">{t('loading')}</p>}
        {groups?.length === 0 && <div className="note ok">{t('noLowStock')}</div>}
        {groups?.length > 0 && <div className="lowlegend small muted"><span className="szchip"><b>{t('size')}</b><span>{t('nowInStock')}</span><em>→ {t('suggest')}</em></span></div>}
        <div className="lowlist">
          {groups?.map((g, i) => (
            <div key={i} className="pcard lowrow">
              <b>{g.product}</b>
              <div className="szchips">
                {g.sizes.map((s) => (
                  <span key={s.variant} className={`szchip ${s.stock <= 0 ? 'out' : 'low'}`} title={`${t('soldLast30')}: ${s.sold_recently}`}>
                    <b>{s.size}</b><span>{s.stock}</span><em>→ {s.suggest}</em>
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {groups?.length > 0 && (
        <section className="panel">
          <h2>{t('orderList')}</h2>
          <button type="button" className="btn go" onClick={copy}>{t('copyOrder')}</button>
          <button type="button" className="btn ghost" onClick={() => download(api.lowStockXlsxUrl(school), 'low_stock.xlsx').catch((e) => setMsg({ k: 'bad', text: e.message }))}>{t('downloadExcel')}</button>
          {msg && <div className={`note ${msg.k}`} role="status">{msg.text}</div>}
          <textarea id="order-text" readOnly value={text} rows={Math.min(14, text.split('\n').length + 1)}
            style={{ width: '100%', font: 'inherit', fontSize: '.9rem', border: '2px solid var(--line)', borderRadius: 8, padding: 8, background: 'var(--surface)', color: 'var(--ink)' }} />
        </section>
      )}
    </div>
  )
}
