import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api.js'
import { useLang } from '../i18n.jsx'

const money = (n) => '₹' + Math.round(Number(n)).toLocaleString('en-IN')
const REFRESH_MS = 60000

/** The owner's phone screen: today's sale, low stock and the latest bills. Refreshes every minute. */
export default function TodayPage() {
  const { t } = useLang()
  const [d, setD] = useState(null)
  const [error, setError] = useState('')
  const [at, setAt] = useState(null)
  const [open, setOpen] = useState(null)

  const load = () => api.today()
    .then((x) => { setD(x); setAt(new Date()); setError('') })
    .catch((e) => setError(`${t('reportsNeedNet')} ${e.message}`))
  useEffect(() => {
    load()
    const id = setInterval(load, REFRESH_MS)
    return () => clearInterval(id)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  const vs = (now, then) => {
    const diff = Number(now) - Number(then)
    if (!Number(then)) return null
    return <span className={diff >= 0 ? 'up' : 'down'}>{diff >= 0 ? '▲' : '▼'} {money(Math.abs(diff))}</span>
  }

  return (
    <div className="today">
      {error && <div className="note bad">{error}</div>}
      {d && (
        <>
          <section className="hero">
            <span>{t('net')} · {new Date(d.date).toLocaleDateString('en-IN', { weekday: 'short', day: '2-digit', month: 'short' })}</span>
            <b>{money(d.today.net)}</b>
            <div className="split">
              <span>{t('cash')} <b>{money(d.today.cash)}</b></span>
              <span>{t('upi')} <b>{money(d.today.upi)}</b></span>
              <span>{d.today.bills} {t('bills').toLowerCase()} · {d.today.pieces_sold} {t('units')}</span>
            </div>
          </section>

          <section className="panel compact">
            <div className="row spread"><span>{t('yesterdayWas')}</span><span><b>{money(d.yesterday_net)}</b> {vs(d.today.net, d.yesterday_net)}</span></div>
            <div className="row spread"><span>{t('lastWeekWas')}</span><span><b>{money(d.last_week_net)}</b> {vs(d.today.net, d.last_week_net)}</span></div>
            {Number(d.today.returns) > 0 && <div className="row spread"><span>{t('returnsV')}</span><b>{money(d.today.returns)}</b></div>}
          </section>

          <section className={`panel compact ${d.low_count ? 'warnbox' : ''}`}>
            <div className="row spread">
              <b>{d.low_count ? `${d.low_count} ${t('lowItems')}` : t('noLowStock')}</b>
              {d.low_count > 0 && <Link to="/low-stock">{t('seeAll')} →</Link>}
            </div>
            {d.low_top.map((x, i) => (
              <div key={i} className="row spread small"><span>{x.product} · <b>{x.size}</b></span><span className={`pill ${x.stock <= 0 ? 'out' : 'low'}`}>{x.stock}</span></div>
            ))}
          </section>

          <section className="panel compact">
            <b>{t('recentBills')}</b>
            {d.recent.map((b) => (
              <div key={b.id}>
                <button type="button" className="billrow" aria-expanded={open === b.id} onClick={() => setOpen(open === b.id ? null : b.id)}>
                  <span>#{b.number} <span className="muted small">{new Date(b.at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</span>
                    {b.has_return && <span className="pill low" style={{ marginLeft: 6 }}>{t('returnTag')}</span>}
                    {b.status === 'cancelled' && <span className="pill out" style={{ marginLeft: 6 }}>{t('cancelled')}</span>}</span>
                  <span><b>{Number(b.total) < 0 ? '−' : ''}{money(Math.abs(b.total))}</b> <span className="muted small">{b.items} {t('units')}</span></span>
                </button>
                {open === b.id && (
                  <div className="small" style={{ padding: '0 4px 8px' }}>
                    {b.lines.map((l, i) => <div key={i} className="row spread"><span>{l.qty < 0 ? `${t('returnTag')} ` : ''}{l.description} {l.size} × {Math.abs(l.qty)}</span><span>{money(l.amount)}</span></div>)}
                  </div>
                )}
              </div>
            ))}
          </section>

          <div className="row spread small muted">
            <span>{t('updated')} {at?.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</span>
            <button type="button" className="btn ghost" onClick={load}>{t('refresh')}</button>
          </div>
        </>
      )}
    </div>
  )
}
