import { useLiveQuery } from 'dexie-react-hooks'
import { useEffect, useMemo, useRef, useState } from 'react'
import Receipt, { prefs, printReceipt } from '../components/Receipt.jsx'
import Icon from '../components/Icon.jsx'
import ReturnFinder from '../components/ReturnFinder.jsx'
import SearchSelect from '../components/SearchSelect.jsx'
import { toast } from '../components/Toast.jsx'
import { api } from '../api.js'
import { useLang } from '../i18n.jsx'
import { db, getMeta } from '../offline/db.js'
import { round2, saveBillLocally, useSync } from '../offline/sync.js'

const money = (n) => '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 })
const COMMON = '__common__'

function describe(v) {
  return [v.schools.length ? v.schools.slice(0, 3).join(', ') + (v.schools.length > 3 ? ` +${v.schools.length - 3}` : '') : '',
    v.category, v.detail].filter(Boolean).join(' ')
}

function matches(v, words) {
  // size and barcode must match exactly ("30" should not match size 300 or barcode 10030)
  const hay = `${v.schools.join(' ')} ${v.category} ${v.category_hi} ${v.detail} ${v.schools.length ? '' : 'common'}`.toLowerCase()
  return words.every((w) => v.size.toLowerCase() === w || v.barcode === w || hay.includes(w))
}

const readHow = () => { try { return localStorage.getItem('billMode') || 'scanner' } catch { return 'scanner' } }

/** kind="return" = the Return / Exchange screen: same counter, with the return finder open. */
export default function BillingPage({ kind = 'sale' }) {
  const { t, lang } = useLang()
  const variants = useLiveQuery(() => db.variants.toArray(), [], null)
  const settings = useLiveQuery(() => getMeta('settings', {}), [], {})
  const nextNo = useLiveQuery(() => getMeta('nextBillNumber', 1), [], 1)

  const [q, setQ] = useState('')
  const [school, setSchool] = useState('')
  const [productId, setProductId] = useState('')
  // line: {key, id (variant), description, size, price, qty, stock}; returns have qty < 0 + returned_from
  const [cart, setCart] = useState([])
  const [retOpen, setRetOpen] = useState(kind === 'return')
  const [how, setHowState] = useState(readHow) // 'scanner' | 'manual'
  const setHow = (h) => { setHowState(h); try { localStorage.setItem('billMode', h) } catch { /* ignore */ } focusScan() }
  const [override, setOverride] = useState('')
  const [refundMode, setRefundMode] = useState('cash')
  const [credit, setCredit] = useState(null) // {code, balance} of a credit note being used
  const [creditCode, setCreditCode] = useState('')
  const { online } = useSync()
  const [msg, setMsg] = useState(null)
  const [mode, setMode] = useState('cash')
  const [received, setReceived] = useState('')
  const [cashPart, setCashPart] = useState('')
  const [discount, setDiscount] = useState('')
  const [showCust, setShowCust] = useState(false)
  const [cust, setCust] = useState({ name: '', phone: '' })
  const [done, setDone] = useState(null) // saved bill shown as receipt
  const [saving, setSaving] = useState(false)
  const scanRef = useRef(null)

  const focusScan = () => setTimeout(() => scanRef.current?.focus(), 0)
  useEffect(() => { focusScan() }, [])

  // schools that have items, plus Common
  const schools = useMemo(() => {
    const set = new Set()
    variants?.forEach((v) => v.schools.forEach((s) => set.add(s)))
    return [...set].sort()
  }, [variants])

  // the dropdown lists every school; the chips beside it are the last few used (then A–Z)
  const schoolOptions = useMemo(() => [{ value: COMMON, label: t('common') }, ...schools.map((x) => ({ value: x, label: x }))], [schools, t])
  const [recent, setRecent] = useState(() => { try { return JSON.parse(localStorage.getItem('recentSchools') || '[]') } catch { return [] } })
  const quickSchools = useMemo(() => {
    const known = new Set([COMMON, ...schools])
    const list = recent.filter((x) => known.has(x))
    for (const x of [COMMON, ...schools]) { if (list.length >= 6) break; if (!list.includes(x)) list.push(x) }
    return list
  }, [recent, schools])
  const pickSchool = (x) => {
    setSchool(x); setProductId('')
    const next = [x, ...recent.filter((r) => r !== x)].slice(0, 6)
    setRecent(next)
    try { localStorage.setItem('recentSchools', JSON.stringify(next)) } catch { /* ignore */ }
  }

  const products = useMemo(() => {
    if (!variants || !school) return []
    const map = new Map()
    for (const v of variants) {
      const ok = school === COMMON ? v.schools.length === 0 : v.schools.includes(school)
      if (!ok) continue
      if (!map.has(v.product)) map.set(v.product, { id: v.product, v, sizes: [] })
      map.get(v.product).sizes.push(v)
    }
    return [...map.values()].map((p) => ({ ...p, sizes: p.sizes.sort((a, b) => a.sort_order - b.sort_order) }))
  }, [variants, school])
  const product = products.find((p) => p.id === productId)

  const results = useMemo(() => {
    const words = q.trim().toLowerCase().split(/\s+/).filter(Boolean)
    if (!words.length || !variants) return null
    return variants.filter((v) => matches(v, words)).slice(0, 12)
  }, [q, variants])

  const add = (v, { clear = true } = {}) => {
    setCart((c) => {
      const i = c.findIndex((l) => l.key === v.id)
      if (i >= 0) return c.map((l, j) => (j === i ? { ...l, qty: l.qty + 1 } : l))
      return [...c, { key: v.id, id: v.id, description: describe(v), size: v.size, price: v.price, qty: 1, stock: v.stock }]
    })
    const inCart = (cart.find((l) => l.key === v.id)?.qty || 0) + 1
    setMsg(v.stock - inCart < 0 ? { k: 'warn', text: `${describe(v)} ${v.size}: ${t('stockZeroWarn')}` } : null)
    if (clear) setQ('')
    focusScan()
  }

  const onScanKey = async (e) => {
    if (e.key === 'Escape') { setQ(''); return }
    if (e.key !== 'Enter') return
    // Read the box itself and clear it at once: a fast scanner may start the next
    // code before this lookup finishes, and those keystrokes must not be wiped out.
    const code = e.currentTarget.value.trim()
    if (!code) return
    setQ('')
    const hit = await db.variants.where('barcode').equals(code).first()
    if (hit) return add(hit, { clear: false })
    const words = code.toLowerCase().split(/\s+/)
    const found = (variants || []).filter((v) => matches(v, words))
    if (found.length === 1) return add(found[0], { clear: false })
    setQ((cur) => cur || code) // several or no matches: put the words back so the list shows
    if (!found.length) setMsg({ k: 'bad', text: `"${code}": ${t('noResults')}` })
  }

  const changeQty = (key, d) => setCart((c) => c.map((l) => (l.key === key ? { ...l, qty: l.qty + d } : l)).filter((l) => l.qty > 0))
  const removeLine = (key) => setCart((c) => c.filter((l) => l.key !== key))

  // returned lines already on this bill, so the finder can't add the same pieces twice
  const inCartReturns = Object.fromEntries(cart.filter((l) => l.isReturn).map((l) => [l.returned_from, -l.qty]))
  const addReturns = (lines, why) => {
    setCart((c) => {
      let next = [...c]
      for (const r of lines) {
        const i = next.findIndex((l) => l.key === r.key)
        next = i >= 0 ? next.map((l, j) => (j === i ? { ...l, qty: l.qty + r.qty } : l)) : [...next, r]
      }
      return next
    })
    if (why) setOverride(why)
    setMsg(null); toast(t('returnAdded'))
  }

  const subtotal = round2(cart.reduce((a, l) => a + l.price * l.qty, 0))
  const newItems = round2(cart.filter((l) => l.qty > 0).reduce((a, l) => a + l.price * l.qty, 0))
  const hasReturn = cart.some((l) => l.isReturn)
  const disc = settings?.allow_discount ? Math.min(Math.max(+discount || 0, 0), newItems) : 0
  const total = round2(subtotal - disc)
  const creditUse = credit && total > 0 ? round2(Math.min(credit.balance, total)) : 0
  const due = round2(total - creditUse) // what the customer still pays (when total > 0)
  const cashAmt = due <= 0 ? 0 : mode === 'cash' ? due : mode === 'upi' ? 0 : Math.min(Math.max(+cashPart || 0, 0), due)
  const upiAmt = due <= 0 ? 0 : round2(due - cashAmt)
  const changeDue = mode === 'cash' && received !== '' && due > 0 ? round2(+received - due) : null

  const applyCredit = async () => {
    setMsg(null)
    try {
      const n = await api.creditNote(creditCode)
      if (n.cancelled || Number(n.balance) <= 0) throw new Error(`${n.code}: ${t('creditEmpty')}`)
      setCredit({ code: n.code, balance: Number(n.balance) })
    } catch (e) {
      setMsg({ k: 'bad', text: online ? e.message : t('creditNeedsNet') })
    }
  }

  const reset = () => {
    setCart([]); setMsg(null); setMode('cash'); setReceived(''); setCashPart(''); setDiscount('')
    setCust({ name: '', phone: '' }); setShowCust(false); setDone(null); setRetOpen(kind === 'return'); setOverride('')
    setRefundMode('cash'); setCredit(null); setCreditCode(''); focusScan()
  }

  const save = async () => {
    if (!cart.length || saving) return
    setSaving(true)
    try {
      const back = total < 0 ? -total : 0 // money the shop gives back
      const bill = await saveBillLocally({
        lines: cart, discount: disc,
        cash: back ? (refundMode === 'cash' ? -back : 0) : cashAmt,
        upi: back ? (refundMode === 'upi' ? -back : 0) : upiAmt,
        credit_issued: back && refundMode === 'credit' ? back : 0,
        credit_used: creditUse, credit_note_code: creditUse ? credit.code : '',
        return_override: hasReturn ? override : '',
        customer_name: cust.name.trim(), customer_phone: cust.phone.trim(),
      })
      setDone(bill)
      if (prefs().autoPrint) setTimeout(printReceipt, 150)
    } catch (e) {
      setMsg({ k: 'bad', text: e.message })
    } finally {
      setSaving(false)
    }
  }

  // Keyboard: F8 = save, Enter on the receipt = new bill
  useEffect(() => {
    const onKey = (e) => {
      if (done && (e.key === 'Enter' || e.key === 'Escape')) { e.preventDefault(); reset() }
      else if (!done && e.key === 'F8') { e.preventDefault(); save() }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  })

  if (variants === null) return <p className="muted">{t('loading')}</p>

  return (
    <div className="billgrid">
      <section className="panel">
        {retOpen && (
          <ReturnFinder returnDays={settings?.return_days ?? 7} inCart={inCartReturns}
            onAdd={addReturns} onClose={() => { setRetOpen(false); focusScan() }} step={kind === 'return'} />
        )}
        {kind === 'return' && <p className="sub"><span className="stepno">2</span>{t('step2New')}</p>}
        <div className="modes" role="group">
          <button type="button" id="mode-scanner" aria-pressed={how === 'scanner'} onClick={() => setHow('scanner')}><Icon name="scan" />{t('scannerMode')}</button>
          <button type="button" id="mode-manual" aria-pressed={how === 'manual'} onClick={() => setHow('manual')}><Icon name="hand" />{t('manualMode')}</button>
        </div>
        <div className={`scan ${how === 'scanner' ? 'big' : ''}`}>
            <span className="ic"><Icon name="scan" /></span>
            <input ref={scanRef} id="scan" type="text" autoComplete="off" placeholder={t('scanOrType')} value={q}
              onChange={(e) => setQ(e.target.value)} onKeyDown={onScanKey} />
        </div>

        {results ? (
          <div className="results">
            <p className="sub">{t('results')}</p>
            {results.length === 0 && <div className="note bad">{t('noResults')}</div>}
            {results.map((v) => (
              <button key={v.id} type="button" className="res" onClick={() => add(v)}>
                <span><b>{describe(v)}</b> · {t('size')} {v.size}</span>
                <em>{money(v.price)} · {v.stock > 0 ? `${v.stock} ${t('left')}` : t('outOfStock')}</em>
              </button>
            ))}
          </div>
        ) : how === 'scanner' ? (
          !retOpen && <div className="scanready"><Icon name="scan" /><b>{t('readyToScan')}</b><span className="small">{t('readyHint')}</span></div>
        ) : (
          <>
            <div className="pickrow">
              <SearchSelect id="school-select" options={schoolOptions} value={school} onChange={pickSchool}
                placeholder={t('chooseSchool')} searchPh={t('searchSchool')} />
              <div className="chips">
                {quickSchools.map((s) => (
                  <button key={s} type="button" className="chip" aria-pressed={school === s} onClick={() => pickSchool(s)}>{s === COMMON ? t('common') : s}</button>
                ))}
              </div>
            </div>
            {school && (
              <>
                <p className="sub">{t('pickItem')}</p>
                <div className="products">
                  {products.map((p) => (
                    <button key={p.id} type="button" className="prod" aria-pressed={productId === p.id} onClick={() => setProductId(p.id)}>
                      <b>{(lang === 'hi' && p.v.category_hi) || p.v.category}</b>
                      <small>{[p.v.detail, t(p.v.season === 'all' ? 'allSeason' : p.v.season), t(p.v.gender)].filter(Boolean).join(' · ')}</small>
                    </button>
                  ))}
                </div>
              </>
            )}
            {product && (
              <>
                <p className="sub">{t('pickSize')}</p>
                <div className="sizes">
                  {product.sizes.map((v) => (
                    <button key={v.id} type="button" className={`size ${v.stock <= 0 ? 'out' : v.stock <= v.low_stock_level ? 'low' : ''}`} onClick={() => add(v)}>
                      <b>{v.size}</b>
                      <span className="pr">{money(v.price)}</span>
                      <span className="st">{v.stock > 0 ? `${v.stock} ${t('left')}` : t('outOfStock')}</span>
                    </button>
                  ))}
                </div>
              </>
            )}
          </>
        )}
      </section>

      <section className="panel cartpanel">
        <div className="row spread">
          <div><h2>{t('currentBill')}</h2><span className="small muted">{t('billNo')} {nextNo}</span></div>
          <div className="row" style={{ gap: 14 }}>
            {!retOpen && <button type="button" className="linkbtn small" id="open-return" onClick={() => setRetOpen(true)}>↩ {t('addReturnLink')}</button>}
            {cart.length > 0 && <button type="button" className="linkbtn small" onClick={reset}>{t('clearBill')}</button>}
          </div>
        </div>
        {msg && <div className={`note ${msg.k}`} role="status">{msg.text}</div>}
        <div className="lines">
          {cart.length === 0 && <div className="empty">{t('emptyBill')}</div>}
          {cart.map((l) => (
            <div key={l.key} className={`line ${l.isReturn ? 'ret' : ''}`}>
              <div className="nm">
                <b>{l.isReturn && <span className="pill out" style={{ marginRight: 6 }}>{t('returnTag')}</span>}{l.description}</b>
                <span>{t('size')} {l.size} · {money(l.price)}{l.isReturn && ` · ${t('billNo')} ${l.fromBill}`} · <button type="button" className="x" onClick={() => removeLine(l.key)}>{t('remove')}</button></span>
              </div>
              {l.isReturn ? <div className="qty"><span>{l.qty}</span></div> : (
                <div className="qty">
                  <button type="button" aria-label="-" onClick={() => changeQty(l.key, -1)}>−</button>
                  <span>{l.qty}</span>
                  <button type="button" aria-label="+" onClick={() => changeQty(l.key, 1)}>+</button>
                </div>
              )}
              <div className="amt">{l.qty < 0 ? '−' : ''}{money(Math.abs(l.price * l.qty))}</div>
            </div>
          ))}
        </div>

        {showCust && settings?.allow_discount && newItems > 0 && (
          <div className="row spread">
            <span className="muted">{t('subtotal')} {money(subtotal)}</span>
            <label className="row">{t('discount')} ₹
              <input className="cell" type="number" min="0" id="discount" value={discount} onChange={(e) => setDiscount(e.target.value)} />
            </label>
          </div>
        )}
        <div className={`total ${total < 0 ? 'back' : ''}`}><span>{total < 0 ? t('giveBack') : t('grandTotal')}</span><b>{money(Math.abs(total))}</b></div>

        {cart.length > 0 && total === 0 && <div className="note ok">{t('evenSwap')}</div>}

        {total < 0 && (
          <div className="field">{t('giveBackHow')}
            <div className="pay">
              {[['cash', t('cash')], ['upi', t('upi')], ['credit', t('creditNote')]].map(([m, label]) => (
                <button key={m} type="button" aria-pressed={refundMode === m} onClick={() => setRefundMode(m)}>{label}</button>
              ))}
            </div>
            {refundMode === 'credit' && <span className="help">{t('creditHelp')}</span>}
          </div>
        )}

        {total > 0 && (
          <>
            {credit ? (
              <div className="row spread note ok">
                <span>{t('creditNote')} {credit.code}: −{money(creditUse)} <span className="small">({t('balance')} {money(credit.balance)})</span></span>
                <button type="button" className="linkbtn" onClick={() => setCredit(null)}>{t('remove')}</button>
              </div>
            ) : showCust && (
              <div className="row">
                <input type="text" id="credit-code" placeholder={t('creditPh')} value={creditCode} onChange={(e) => setCreditCode(e.target.value)} style={{ flex: 1, minWidth: 0 }} />
                <button type="button" className="btn ghost" disabled={!creditCode.trim()} onClick={applyCredit}>{t('useCredit')}</button>
              </div>
            )}
            {due > 0 && (
              <>
                {creditUse > 0 && <div className="row spread"><b>{t('toPay')}</b><b>{money(due)}</b></div>}
                <div className="pay">
                  {['cash', 'upi', 'split'].map((m) => (
                    <button key={m} type="button" aria-pressed={mode === m} onClick={() => setMode(m)}>{t(m)}</button>
                  ))}
                </div>
                {mode === 'cash' && (
                  <div className="row spread">
                    <label className="row">{t('received')}<input className="cell" type="number" min="0" id="received" value={received} onChange={(e) => setReceived(e.target.value)} /></label>
                    {changeDue !== null && changeDue >= 0 && <b className="change">{t('change')}: {money(changeDue)}</b>}
                  </div>
                )}
                {mode === 'split' && (
                  <div className="row spread">
                    <label className="row">{t('cashPart')}<input className="cell" type="number" min="0" id="cashpart" value={cashPart} onChange={(e) => setCashPart(e.target.value)} /></label>
                    <b>{t('upiPart')}: {money(upiAmt)}</b>
                  </div>
                )}
              </>
            )}
          </>
        )}

        {showCust && (
          <div className="grid2">
            <label className="field">{t('custName')}<input type="text" id="cust-name" value={cust.name} onChange={(e) => setCust({ ...cust, name: e.target.value })} /></label>
            <label className="field">{t('custPhone')}<input type="text" id="cust-phone" inputMode="tel" value={cust.phone} onChange={(e) => setCust({ ...cust, phone: e.target.value })} /></label>
          </div>
        )}
        {cart.length > 0 && (
          <div><button type="button" className="linkbtn small" id="more-options" onClick={() => setShowCust(!showCust)}>{showCust ? t('fewerOptions') : `+ ${t('moreOptions')}`}</button></div>
        )}

        <button type="button" className="btn go big" id="save-bill" disabled={!cart.length || saving} onClick={save}>{t('saveBill')} <span style={{ opacity: .6, fontWeight: 500 }}>F8</span></button>
      </section>

      {done && (
        <div className="overlay" role="dialog" aria-label={t('billSaved')}>
          <div className="receiptwrap">
            <Receipt bill={done} settings={settings} />
            <div className="acts">
              <button type="button" className="btn" onClick={printReceipt}>{t('printBill')}</button>
              <button type="button" className="btn go" autoFocus onClick={reset}>{t('newBill')} (Enter)</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
