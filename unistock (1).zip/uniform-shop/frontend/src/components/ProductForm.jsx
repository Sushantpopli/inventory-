import { useMemo, useState } from 'react'
import { api } from '../api.js'
import { catName, useLang } from '../i18n.jsx'

// Order sizes like the backend does: numbers, then 40-32 style, then S/M/L, then Free
const LETTERS = ['XXS', 'XS', 'S', 'M', 'L', 'XL', 'XXL', 'XXXL']
export function sizeKey(s) {
  const u = s.trim().toUpperCase()
  const m = u.match(/^(\d+)-(\d+)$/)
  if (m) return +m[1] * 1000 + +m[2]
  if (/^\d+$/.test(u)) return +u * 1000
  if (LETTERS.includes(u)) return 900000 + LETTERS.indexOf(u)
  return 999000
}
const cleanSize = (s) => {
  const v = s.trim().replace(/\s*-\s*/g, '-')
  if (v.toLowerCase() === 'free') return 'Free'
  return /^[a-z]+$/i.test(v) ? v.toUpperCase() : v
}

/**
 * Create a product with the price ladder.
 * Pick item → sizes are suggested → set first price + step → check the table → save.
 */
export default function ProductForm({ categories, schools, defaultSchoolId, onSaved, onCancel }) {
  const { t, lang } = useLang()
  const [categoryId, setCategoryId] = useState('')
  const [schoolIds, setSchoolIds] = useState(defaultSchoolId && defaultSchoolId !== 'common' ? [defaultSchoolId] : [])
  const [season, setSeason] = useState('summer')
  const [gender, setGender] = useState('boy')
  const [name, setName] = useState('')
  const [offered, setOffered] = useState([]) // sizes shown as chips
  const [chosen, setChosen] = useState([]) // sizes switched on
  const [extra, setExtra] = useState('')
  const [startPrice, setStartPrice] = useState('')
  const [step, setStep] = useState('10')
  const [costStart, setCostStart] = useState('')
  const [costStep, setCostStep] = useState('0')
  const [low, setLow] = useState('3')
  const [opening, setOpening] = useState({})
  const [error, setError] = useState('')
  const [saving, setSaving] = useState(false)

  const pickCategory = (id) => {
    setCategoryId(id)
    const c = categories.find((x) => x.id === id)
    const sizes = (c?.default_sizes || '').split(',').map((s) => s.trim()).filter(Boolean)
    setOffered(sizes)
    setChosen(sizes)
    if (sizes.length === 1) setStep('0')
  }
  const toggleSize = (s) => setChosen((c) => (c.includes(s) ? c.filter((x) => x !== s) : [...c, s]))
  const addExtra = () => {
    const s = cleanSize(extra)
    if (!s) return
    if (!offered.includes(s)) setOffered((o) => [...o, s])
    if (!chosen.includes(s)) setChosen((c) => [...c, s])
    setExtra('')
  }
  const toggleSchool = (id) => setSchoolIds((ids) => (ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id]))

  const sizes = useMemo(() => [...chosen].sort((a, b) => sizeKey(a) - sizeKey(b)), [chosen])
  const rows = sizes.map((s, i) => ({
    size: s,
    price: startPrice === '' ? null : +startPrice + i * (+step || 0),
    cost: costStart === '' ? null : +costStart + i * (+costStep || 0),
  }))

  const save = async () => {
    setError('')
    if (!categoryId) return setError(t('needCat'))
    if (!sizes.length) return setError(t('needSize'))
    if (startPrice === '') return setError(t('needPrice'))
    setSaving(true)
    try {
      const p = await api.createProduct({
        category: categoryId, school_ids: schoolIds, season, gender, name, sizes,
        start_price: startPrice, step: step || 0,
        cost_start: costStart === '' ? null : costStart, cost_step: costStep || 0,
        low_stock_level: low === '' ? undefined : +low,
        opening_stock: sizes.map((s) => +(opening[s] || 0)),
      })
      onSaved(p)
    } catch (e) {
      setError(e.message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <section className="panel" aria-label={t('addProduct')}>
      <div className="row spread">
        <h2>{t('addProduct')}</h2>
        <button type="button" className="btn ghost" onClick={onCancel}>{t('cancel')}</button>
      </div>

      <div className="field">{t('item')}
        <div className="chips">
          {categories.map((c) => (
            <button key={c.id} type="button" className="chip" aria-pressed={categoryId === c.id} onClick={() => pickCategory(c.id)}>
              {catName(c, lang)}
            </button>
          ))}
        </div>
      </div>

      <div className="field">{t('forSchools')}
        <span className="help">{t('commonHint')}</span>
        <div className="chips">
          {schools.filter((s) => s.active).map((s) => (
            <button key={s.id} type="button" className="chip" aria-pressed={schoolIds.includes(s.id)} onClick={() => toggleSchool(s.id)} title={s.name}>
              {s.short_name}
            </button>
          ))}
        </div>
      </div>

      <div className="grid2">
        <div className="field">{t('season')}
          <div className="seg">
            {['summer', 'winter', 'all'].map((s) => (
              <button key={s} type="button" aria-pressed={season === s} onClick={() => setSeason(s)}>{t(s === 'all' ? 'allSeason' : s)}</button>
            ))}
          </div>
        </div>
        <div className="field">{t('gender')}
          <div className="seg">
            {['boy', 'girl', 'unisex'].map((g) => (
              <button key={g} type="button" aria-pressed={gender === g} onClick={() => setGender(g)}>{t(g)}</button>
            ))}
          </div>
        </div>
        <label className="field">{t('detail')}
          <input type="text" id="pf-name" value={name} placeholder={t('detailPh')} onChange={(e) => setName(e.target.value)} />
        </label>
      </div>

      {categoryId && (
        <div className="field">{t('sizes')}
          <div className="chips">
            {[...offered].sort((a, b) => sizeKey(a) - sizeKey(b)).map((s) => (
              <button key={s} type="button" className="chip size" aria-pressed={chosen.includes(s)} onClick={() => toggleSize(s)}>{s}</button>
            ))}
          </div>
          <div className="row">
            <input type="text" id="pf-extra" value={extra} placeholder={t('addSizePh')} onChange={(e) => setExtra(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addExtra())} style={{ width: 160 }} />
            <button type="button" className="btn ghost" onClick={addExtra}>{t('addSize')}</button>
          </div>
        </div>
      )}

      <div className="grid2">
        <label className="field">{t('firstPrice')}
          <input type="number" id="pf-price" min="0" value={startPrice} onChange={(e) => setStartPrice(e.target.value)} />
        </label>
        <label className="field">{t('step')}
          <input type="number" id="pf-step" min="0" value={step} onChange={(e) => setStep(e.target.value)} />
        </label>
        <label className="field">{t('firstCost')}
          <input type="number" id="pf-cost" min="0" value={costStart} onChange={(e) => setCostStart(e.target.value)} />
        </label>
        <label className="field">{t('costStep')}
          <input type="number" id="pf-coststep" min="0" value={costStep} onChange={(e) => setCostStep(e.target.value)} />
        </label>
        <label className="field">{t('lowLevel')}
          <input type="number" id="pf-low" min="0" value={low} onChange={(e) => setLow(e.target.value)} />
        </label>
      </div>

      {rows.length > 0 && (
        <div className="field">{t('preview')}
          <div className="scroll">
            <table>
              <thead><tr><th>{t('size')}</th><th className="num">{t('price')}</th><th className="num">{t('cost')}</th><th className="num">{t('openStock')}</th></tr></thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.size}>
                    <td><b>{r.size}</b></td>
                    <td className="num">{r.price == null ? '—' : '₹' + r.price}</td>
                    <td className="num muted">{r.cost == null ? '—' : '₹' + r.cost}</td>
                    <td className="num">
                      <input className="cell" type="number" min="0" aria-label={`${t('openStock')} ${r.size}`} value={opening[r.size] ?? ''}
                        onChange={(e) => setOpening((o) => ({ ...o, [r.size]: e.target.value }))} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {error && <div className="note bad" role="alert">{error}</div>}
      <div className="row">
        <button type="button" className="btn go big" onClick={save} disabled={saving}>{saving ? t('saving') : t('save')}</button>
      </div>
    </section>
  )
}
