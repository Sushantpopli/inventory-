import { useState } from 'react'
import { useLang } from '../i18n.jsx'
import { db } from '../offline/db.js'
import { billsWithItem, loadBill } from '../offline/returns.js'
import { useSync } from '../offline/sync.js'

const money = (n) => '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 })

/**
 * Find what the customer bought (by bill number, or by scanning the item),
 * choose how many pieces come back, and put them on the current bill as minus lines.
 * Then the counter adds the new items (exchange) or just gives the money back.
 */
export default function ReturnFinder({ returnDays, inCart, onAdd, onClose, step }) {
  const { t } = useLang()
  const { online } = useSync()
  const [billNo, setBillNo] = useState('')
  const [scan, setScan] = useState('')
  const [bills, setBills] = useState(null)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)

  const run = async (fn) => {
    setErr(''); setBusy(true)
    try { await fn() } catch (e) { setErr(e.message) } finally { setBusy(false) }
  }
  const byNumber = (e) => {
    e.preventDefault()
    run(async () => {
      const b = await loadBill(billNo, online)
      if (!b) { setBills([]); setErr(`${t('billNo')} ${billNo}: ${t('billNotFound')}${online ? '' : ' ' + t('olderNeedsNet')}`); return }
      setBills([b])
    })
  }
  const byItem = (e) => {
    e.preventDefault()
    const code = scan.trim()
    setScan('')
    run(async () => {
      const v = await db.variants.where('barcode').equals(code).first()
      if (!v) { setErr(`"${code}": ${t('noResults')}`); return }
      const list = await billsWithItem(v.id, returnDays, online)
      if (!list.length) setErr(t('noBillWithItem'))
      setBills(list)
    })
  }

  return (
    <div className="retbox">
      <div className="row spread">
        <h2>{step && <span className="stepno">1</span>}{t('returnTitle')}</h2>
        <button type="button" className="btn ghost" onClick={onClose}>{t('done')}</button>
      </div>
      <div className="grid2">
        <form className="field" onSubmit={byNumber}>{t('byBillNo')}
          <div className="row">
            <input type="text" id="ret-billno" inputMode="numeric" autoFocus value={billNo} onChange={(e) => setBillNo(e.target.value)} style={{ flex: 1 }} />
            <button type="submit" className="btn" disabled={busy}>{t('find')}</button>
          </div>
        </form>
        <form className="field" onSubmit={byItem}>{t('byItem')}
          <input type="text" id="ret-scan" autoComplete="off" placeholder={t('scanPh')} value={scan} onChange={(e) => setScan(e.target.value)} />
        </form>
      </div>
      {err && <div className="note bad" role="alert">{err}</div>}
      {bills?.map((b) => <BillToReturn key={b.id} bill={b} returnDays={returnDays} inCart={inCart} onAdd={onAdd} />)}
    </div>
  )
}

function BillToReturn({ bill, returnDays, inCart, onAdd }) {
  const { t } = useLang()
  const [pick, setPick] = useState({}) // line client_id -> qty
  const [override, setOverride] = useState('')
  const [asking, setAsking] = useState(false)
  const late = bill.age > returnDays
  const blocked = late && !override.trim()

  const left = (l) => l.returnable - (inCart[l.client_id] || 0)
  const set = (l, n) => setPick((p) => ({ ...p, [l.client_id]: Math.max(0, Math.min(n, left(l))) }))
  const chosen = bill.sold.filter((l) => pick[l.client_id] > 0)

  const add = () => {
    onAdd(chosen.map((l) => ({
      key: 'ret:' + l.client_id, id: l.variant, returned_from: l.client_id, isReturn: true,
      description: l.description, size: l.size, price: l.refund, qty: -pick[l.client_id],
      fromBill: bill.number,
    })), late ? `${t('lateReturn')} (${bill.age}d): ${override.trim()}` : '')
    setPick({})
  }

  return (
    <div className="pcard" style={{ padding: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div className="row spread">
        <b>{t('billNo')} {bill.number}</b>
        <span className="small muted">{new Date(bill.created_at).toLocaleDateString('en-IN')} · {bill.age} {t('daysAgo')} · {money(bill.total)}</span>
      </div>
      {late && (
        <div className="note bad">
          {t('overDays').replace('{d}', returnDays)}
          {!asking && <> <button type="button" className="linkbtn" onClick={() => setAsking(true)}>{t('allowAnyway')}</button></>}
          {asking && <input type="text" id="ret-override" placeholder={t('allowReason')} value={override} onChange={(e) => setOverride(e.target.value)} style={{ width: '100%', marginTop: 6 }} />}
        </div>
      )}
      <table>
        <thead><tr><th>{t('product')}</th><th>{t('size')}</th><th className="num">{t('refundEach')}</th><th className="num">{t('canReturn')}</th><th className="num">{t('returning')}</th></tr></thead>
        <tbody>
          {bill.sold.map((l) => (
            <tr key={l.client_id} style={{ opacity: left(l) > 0 ? 1 : 0.5 }}>
              <td>{l.description}</td>
              <td><b>{l.size}</b></td>
              <td className="num">{money(l.refund)}</td>
              <td className="num">{left(l)} / {l.qty}</td>
              <td className="num">
                <div className="qty" style={{ justifyContent: 'flex-end' }}>
                  <button type="button" aria-label="-" onClick={() => set(l, (pick[l.client_id] || 0) - 1)}>−</button>
                  <span>{pick[l.client_id] || 0}</span>
                  <button type="button" aria-label={`+ ${l.size}`} disabled={left(l) <= (pick[l.client_id] || 0) || blocked} onClick={() => set(l, (pick[l.client_id] || 0) + 1)}>+</button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <button type="button" className="btn" disabled={!chosen.length || blocked} onClick={add}>{t('addReturn')}</button>
    </div>
  )
}
