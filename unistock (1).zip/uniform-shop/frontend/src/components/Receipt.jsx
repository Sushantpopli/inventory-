// The printed bill. Same component for the preview, the print and reprints.
const money = (n) => Number(n).toLocaleString('en-IN', { maximumFractionDigits: 2 })

export function prefs() {
  try {
    return {
      autoPrint: localStorage.getItem('autoPrint') === '1',
      paper: localStorage.getItem('paperWidth') || '80',
    }
  } catch {
    return { autoPrint: false, paper: '80' }
  }
}

/**
 * Print only the receipt, sized for the thermal paper.
 * Copies the receipt on screen into a separate print area, so the page behind it
 * doesn't add blank pages.
 */
export function printReceipt() {
  const src = document.querySelector('.overlay .receipt-print') || document.querySelector('.receipt-print')
  if (!src) return
  const { paper } = prefs()
  let root = document.getElementById('print-root')
  if (!root) {
    root = document.createElement('div')
    root.id = 'print-root'
    document.body.appendChild(root)
  }
  root.innerHTML = `<style>@page { size: ${paper}mm auto; margin: 0; } #print-root .receipt { width: ${paper}mm; }</style>` + src.outerHTML
  window.print()
}

export default function Receipt({ bill, settings }) {
  const s = settings || {}
  const d = new Date(bill.created_at)
  const cash = Number(bill.cash_amount), upi = Number(bill.upi_amount)
  const paid = cash > 0 && upi > 0 ? `Cash ${money(cash)} + UPI ${money(upi)}`
    : upi > 0 ? 'UPI' : cash > 0 ? 'Cash' : Number(bill.credit_used) > 0 ? 'Credit note' : '-'
  return (
    <div className="receipt receipt-print">
      <div className="c">
        <b className="firm">{s.firm_name || 'Your Shop Name'}</b>
        {s.address && <div>{s.address}</div>}
        {s.phone && <div>Ph: {s.phone}</div>}
      </div>
      <hr />
      <div className="rrow"><span>Bill #{bill.number}</span><span>{d.toLocaleDateString('en-IN')} {d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</span></div>
      {bill.customer_name && <div>Customer: {bill.customer_name}</div>}
      {bill.status === 'cancelled' && <div className="c"><b>*** CANCELLED ***</b></div>}
      <hr />
      <table>
        <thead><tr><th>Item</th><th className="num">Price</th><th className="num">Qty</th><th className="num">Amt</th></tr></thead>
        <tbody>
          {bill.lines.map((l, i) => (
            <tr key={i}>
              <td>{l.qty < 0 ? 'RETURN ' : ''}{l.description} {l.size}</td>
              <td className="num">{money(l.price)}</td>
              <td className="num">{l.qty}</td>
              <td className="num">{money(l.price * l.qty)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <hr />
      {Number(bill.discount) > 0 && (
        <>
          <div className="rrow"><span>Subtotal</span><span>{money(bill.subtotal)}</span></div>
          <div className="rrow"><span>Discount</span><span>-{money(bill.discount)}</span></div>
        </>
      )}
      {Number(bill.total) < 0
        ? <div className="rrow tot"><span>GIVEN BACK</span><span>Rs {money(-bill.total)}</span></div>
        : <div className="rrow tot"><span>TOTAL</span><span>Rs {money(bill.total)}</span></div>}
      {Number(bill.credit_used) > 0 && <div className="rrow"><span>Credit note {bill.credit_note_used_code}</span><span>-{money(bill.credit_used)}</span></div>}
      {Number(bill.total) > 0 && <div>Paid: {paid}</div>}
      {Number(bill.total) < 0 && Number(bill.credit_issued) === 0 && <div>Refund: {bill.upi_amount ? 'UPI' : 'Cash'}</div>}
      {Number(bill.credit_issued) > 0 && (
        <div className="c" style={{ border: '1px dashed #000', padding: '4px', marginTop: '4px' }}>
          <b>CREDIT NOTE {bill.credit_note_code}</b><br />Rs {money(bill.credit_issued)}<br />Show this bill to use it on any item
        </div>
      )}
      <div>Items: {bill.lines.reduce((a, l) => a + Math.abs(l.qty), 0)}</div>
      <hr />
      <div className="c">{s.footer_text || ''}</div>
    </div>
  )
}
