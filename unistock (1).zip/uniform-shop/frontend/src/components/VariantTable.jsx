import { Fragment, useEffect, useState } from 'react'
import { api } from '../api.js'
import { isOwner } from '../auth.js'
import { useLang } from '../i18n.jsx'

function statusOf(v) {
  if (v.stock <= 0) return 'out'
  if (v.stock <= v.low_stock_level) return 'low'
  return 'ok'
}

/** Sizes of one product. Price, cost and alert level save when you leave the box. */
export default function VariantTable({ product, onChanged }) {
  const { t } = useLang()
  const owner = isOwner()
  const [msg, setMsg] = useState(null)
  const [adding, setAdding] = useState(false)
  const [nv, setNv] = useState({ size: '', price: '', cost: '', stock: '' })
  const [panel, setPanel] = useState(null) // { id, kind: 'count' | 'history' }
  const toggle = (id, kind) => setPanel((p) => (p?.id === id && p.kind === kind ? null : { id, kind }))

  const saveField = async (v, field, raw) => {
    const value = raw === '' ? (field === 'cost_price' ? null : undefined) : raw
    if (value === undefined || String(value) === String(v[field] ?? '')) return
    try {
      await api.updateVariant(v.id, { [field]: value })
      setMsg({ k: 'ok', text: `${t('saved')}: ${v.size}` })
      onChanged()
    } catch (e) {
      setMsg({ k: 'bad', text: e.message })
    }
  }

  const queue = async (fn) => {
    try {
      const r = await fn()
      setMsg({ k: 'ok', text: `${r?.added ?? 1} ${t('addedLabels')}` })
    } catch (e) {
      setMsg({ k: 'bad', text: e.message })
    }
  }

  const addSize = async () => {
    if (!nv.size.trim() || nv.price === '') return
    try {
      await api.addSizes(product.id, {
        sizes: [nv.size.trim()], prices: [nv.price],
        cost_prices: [nv.cost === '' ? null : nv.cost], opening_stock: [+(nv.stock || 0)],
      })
      setNv({ size: '', price: '', cost: '', stock: '' })
      setMsg({ k: 'ok', text: t('saved') })
      onChanged()
    } catch (e) {
      setMsg({ k: 'bad', text: e.message })
    }
  }

  return (
    <div className="body">
      <div className="scroll">
        <table>
          <thead>
            <tr>
              <th>{t('size')}</th><th className="num">{t('price')} ₹</th><th className="num">{t('cost')} ₹</th>
              <th className="num">{t('low')}</th><th className="num">{t('stock')}</th><th>{t('barcode')}</th><th></th>
            </tr>
          </thead>
          <tbody>
            {product.variants.map((v) => (
              <Fragment key={v.id}>
              <tr>
                <td><b>{v.size}</b></td>
                <td className="num"><input className="cell" type="number" min="0" defaultValue={Number(v.price)} disabled={!owner} aria-label={`${t('price')} ${v.size}`}
                  onBlur={(e) => saveField(v, 'price', e.target.value)} /></td>
                <td className="num"><input className="cell" type="number" min="0" defaultValue={v.cost_price == null ? '' : Number(v.cost_price)} disabled={!owner} aria-label={`${t('cost')} ${v.size}`}
                  onBlur={(e) => saveField(v, 'cost_price', e.target.value)} /></td>
                <td className="num"><input className="cell" type="number" min="0" defaultValue={v.low_stock_level} disabled={!owner} aria-label={`${t('low')} ${v.size}`} style={{ width: 64 }}
                  onBlur={(e) => saveField(v, 'low_stock_level', e.target.value)} /></td>
                <td className="num"><span className={`pill ${statusOf(v)}`}>{v.stock} {t('units')}</span></td>
                <td className="mono">{v.barcode}</td>
                <td className="small" style={{ whiteSpace: 'nowrap' }}>
                  <button type="button" className="linkbtn" onClick={() => queue(() => api.queueLabel(v.id, 1))}>{t('addLabel')}</button>{' · '}
                  {owner && <><button type="button" className="linkbtn" onClick={() => toggle(v.id, 'count')}>{t('count')}</button>{' · '}</>}
                  <button type="button" className="linkbtn" onClick={() => toggle(v.id, 'history')}>{t('history')}</button>
                </td>
              </tr>
              {panel?.id === v.id && (
                <tr><td colSpan={7} style={{ background: 'var(--soft)' }}>
                  {panel.kind === 'count'
                    ? <CountForm v={v} onDone={(text) => { setPanel(null); setMsg({ k: 'ok', text }); onChanged() }} />
                    : <History v={v} />}
                </td></tr>
              )}
              </Fragment>
            ))}
          </tbody>
        </table>
      </div>
      <p className="small muted" style={{ margin: 0 }}>{t('stockNote')}</p>
      <div className="row">
        <button type="button" className="btn" onClick={() => queue(() => api.queueProduct(product.id, 'stock'))}>{t('labelsByStock')}</button>
        <button type="button" className="btn ghost" onClick={() => queue(() => api.queueProduct(product.id, 1))}>{t('labelsOne')}</button>
      </div>
      {msg && <div className={`note ${msg.k}`} role="status">{msg.text}</div>}
      {adding ? (
        <div className="row">
          <input type="text" placeholder={t('size')} value={nv.size} onChange={(e) => setNv({ ...nv, size: e.target.value })} style={{ width: 110 }} aria-label={t('size')} />
          <input type="number" placeholder={t('price')} value={nv.price} onChange={(e) => setNv({ ...nv, price: e.target.value })} style={{ width: 110 }} aria-label={t('price')} />
          <input type="number" placeholder={t('cost')} value={nv.cost} onChange={(e) => setNv({ ...nv, cost: e.target.value })} style={{ width: 110 }} aria-label={t('cost')} />
          <input type="number" placeholder={t('openStock')} value={nv.stock} onChange={(e) => setNv({ ...nv, stock: e.target.value })} style={{ width: 140 }} aria-label={t('openStock')} />
          <button type="button" className="btn" onClick={addSize}>{t('addSize')}</button>
          <button type="button" className="btn ghost" onClick={() => setAdding(false)}>{t('done')}</button>
        </div>
      ) : (
        owner && <div><button type="button" className="linkbtn" onClick={() => setAdding(true)}>+ {t('addSizes')}</button></div>
      )}
    </div>
  )
}

/** Counted the shelf? Enter the real number; the difference is saved as an adjustment. */
function CountForm({ v, onDone }) {
  const { t } = useLang()
  const [counted, setCounted] = useState('')
  const [reason, setReason] = useState('')
  const [err, setErr] = useState('')
  const save = async (e) => {
    e.preventDefault()
    if (counted === '') return
    try {
      const r = await api.correctStock(v.id, +counted, reason)
      onDone(r.changed_by ? `${t('stockCorrected')}: ${v.size} → ${r.stock} (${r.changed_by > 0 ? '+' : ''}${r.changed_by})` : t('noChange'))
    } catch (x) {
      setErr(x.message)
    }
  }
  return (
    <form className="row" onSubmit={save}>
      <label className="row">{t('countedQty')} ({v.size})
        <input className="cell" type="number" min="0" autoFocus value={counted} onChange={(e) => setCounted(e.target.value)} aria-label={t('countedQty')} />
      </label>
      <input type="text" placeholder={t('countReason')} value={reason} onChange={(e) => setReason(e.target.value)} aria-label={t('countReason')} />
      <button type="submit" className="btn">{t('saveCount')}</button>
      {err && <span className="note bad">{err}</span>}
    </form>
  )
}

/** Every stock change for one size: opening, stock in, sales, cancels, counts. */
function History({ v }) {
  const { t } = useLang()
  const [data, setData] = useState(null)
  useEffect(() => {
    api.stockHistory(v.id).then(setData).catch(() => setData({ movements: [] }))
  }, [v.id, v.stock])
  if (data === null) return <span className="muted">{t('loading')}</span>
  return (
    <table>
      <thead><tr><th>{t('when')}</th><th>{t('what')}</th><th className="num">{t('chg')}</th><th></th></tr></thead>
      <tbody>
        {data.movements.map((m, i) => (
          <tr key={i}>
            <td className="small">{new Date(m.at).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}</td>
            <td>{m.kind_label}{m.reference && <span className="muted small"> · {m.reference}</span>}</td>
            <td className="num"><b style={{ color: m.qty > 0 ? 'var(--ok)' : 'var(--bad)' }}>{m.qty > 0 ? '+' : ''}{m.qty}</b></td>
            <td className="small muted">{m.note}</td>
          </tr>
        ))}
      </tbody>
    </table>
  )
}
