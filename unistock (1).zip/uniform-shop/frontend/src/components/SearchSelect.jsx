import { useEffect, useRef, useState } from 'react'
import Icon from './Icon.jsx'

/**
 * A dropdown with a search box on top — for long lists like 200 schools.
 * Type a few letters, press Enter to pick the first match. Esc closes.
 */
export default function SearchSelect({ id, options, value, onChange, placeholder, searchPh }) {
  const [open, setOpen] = useState(false)
  const [q, setQ] = useState('')
  const ref = useRef(null)

  useEffect(() => {
    if (!open) return undefined
    const close = (e) => { if (!ref.current?.contains(e.target)) setOpen(false) }
    document.addEventListener('mousedown', close)
    return () => document.removeEventListener('mousedown', close)
  }, [open])

  const cur = options.find((o) => o.value === value)
  const words = q.trim().toLowerCase()
  const list = options.filter((o) => o.label.toLowerCase().includes(words))
  const pick = (v) => { onChange(v); setOpen(false); setQ('') }

  return (
    <div className="ssel" ref={ref}>
      <button type="button" id={id} className="ssel-btn" aria-haspopup="listbox" aria-expanded={open} onClick={() => setOpen(!open)}>
        <span className={cur ? '' : 'ph'}>{cur ? cur.label : placeholder}</span>
        <Icon name="chev" />
      </button>
      {open && (
        <div className="ssel-pop">
          <div className="ssel-search"><Icon name="search" />
            <input autoFocus type="search" placeholder={searchPh} value={q} onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') { e.preventDefault(); if (list[0]) pick(list[0].value) }
                if (e.key === 'Escape') setOpen(false)
              }} />
          </div>
          <div className="ssel-list" role="listbox">
            {list.map((o) => (
              <button type="button" role="option" key={o.value} aria-selected={o.value === value} onClick={() => pick(o.value)}>
                <span>{o.label}</span>{o.hint && <small>{o.hint}</small>}
              </button>
            ))}
            {!list.length && <div className="ssel-none">—</div>}
          </div>
        </div>
      )}
    </div>
  )
}
