import { useEffect, useState } from 'react'

// Small messages in the corner that go away by themselves ("Bill saved ✓").
let listeners = []
let nextId = 1
export function toast(text, kind = 'ok') {
  const t = { id: nextId++, text, kind }
  listeners.forEach((l) => l(t))
}

export default function Toasts() {
  const [items, setItems] = useState([])
  useEffect(() => {
    const add = (t) => {
      setItems((xs) => [...xs.slice(-2), t])
      setTimeout(() => setItems((xs) => xs.filter((x) => x.id !== t.id)), t.kind === 'bad' ? 6000 : 3500)
    }
    listeners.push(add)
    return () => { listeners = listeners.filter((l) => l !== add) }
  }, [])
  return (
    <div className="toasts" role="status" aria-live="polite">
      {items.map((t) => <div key={t.id} className={`toast ${t.kind}`}>{t.kind === 'ok' ? '✓' : '!'} {t.text}</div>)}
    </div>
  )
}
