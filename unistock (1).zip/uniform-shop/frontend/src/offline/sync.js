// Keeps the counter's local database and the server in step.
//   push: send waiting bills (outbox) to the server
//   pull: fetch changed prices/stock/products since the last sync
// Runs every 20 seconds and whenever the browser says it's back online.
import { useEffect, useState } from 'react'
import { clearAuth, getToken } from '../auth.js'
import { db, deviceId, getMeta, setMeta } from './db.js'

const BASE = import.meta.env.VITE_API_URL || '/api'
const EVERY_MS = 20000

let state = { online: true, syncing: false, pending: 0, failed: 0, lastSync: null, error: '' }
const listeners = new Set()
function update(patch) {
  state = { ...state, ...patch }
  listeners.forEach((fn) => fn(state))
}

async function call(path, opts = {}) {
  const token = getToken()
  const res = await fetch(BASE + path, {
    ...opts,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Token ${token}` } : {}), ...(opts.headers || {}) },
  })
  if (res.status === 401) { clearAuth(); throw new Error('Please log in again') }
  if (!res.ok) throw new Error(`Server error ${res.status}`)
  return res.json()
}

async function refreshCounts() {
  const waiting = await db.outbox.toArray()
  update({ pending: waiting.length, failed: waiting.filter((b) => b.sync_error).length })
}

/** Send waiting bills. Bills the server accepted leave the outbox. */
async function push() {
  // oldest first, so a sale is on the server before a return that points to it
  const waiting = (await db.outbox.toArray()).sort((x, y) => x.number - y.number)
  if (!waiting.length) return
  const bills = waiting.map(({ sync_error: _syncError, ...b }) => ({
    ...b,
    lines: b.lines.map((l) => ({
      variant: l.variant, qty: l.qty, price: l.price, client_id: l.client_id,
      ...(l.returned_from ? { returned_from: l.returned_from } : {}),
    })),
  }))
  const res = await call('/billing/sync/', { method: 'POST', body: JSON.stringify({ bills }) })
  await db.transaction('rw', db.outbox, db.bills, db.meta, async () => {
    for (const r of res.results) {
      if (r.status === 'error') {
        const msg = typeof r.detail === 'string' ? r.detail : JSON.stringify(r.detail)
        await db.outbox.update(r.id, { sync_error: msg })
        continue
      }
      await db.outbox.delete(r.id)
      await db.bills.update(r.id, {
        synced: true,
        ...(r.status === 'renumbered' ? { number: r.number, renumbered: true } : {}),
        ...(r.credit_note_code ? { credit_note_code: r.credit_note_code } : {}),
      })
    }
    const localNext = await getMeta('nextBillNumber', 1)
    await setMeta('nextBillNumber', Math.max(localNext, res.next_bill_number))
  })
}

/** Download changes. First time (or forced) downloads everything. */
async function pull(full = false) {
  const since = full ? null : await getMeta('lastSync')
  const data = await call('/billing/snapshot/' + (since ? `?since=${encodeURIComponent(since)}` : ''))
  await db.transaction('rw', db.variants, db.meta, db.outbox, async () => {
    if (data.full) await db.variants.clear()
    const keep = data.variants.filter((v) => v.active)
    const gone = data.variants.filter((v) => !v.active).map((v) => v.id)
    // bills still waiting in the outbox are not in the server's stock yet
    const waiting = await db.outbox.toArray()
    const pendingQty = {}
    waiting.forEach((b) => b.lines.forEach((l) => { pendingQty[l.variant] = (pendingQty[l.variant] || 0) + l.qty }))
    await db.variants.bulkPut(keep.map((v) => ({ ...v, price: Number(v.price), stock: v.stock - (pendingQty[v.id] || 0) })))
    if (gone.length) await db.variants.bulkDelete(gone)
    await setMeta('settings', data.settings)
    await setMeta('lastSync', data.server_time)
    const localNext = await getMeta('nextBillNumber', 1)
    await setMeta('nextBillNumber', Math.max(localNext, data.next_bill_number))
  })
  return data
}

// crypto.randomUUID only works on https/localhost; the shop may use http://192.168.x.x
function newId() {
  if (globalThis.crypto?.randomUUID) return crypto.randomUUID()
  const b = crypto.getRandomValues(new Uint8Array(16))
  b[6] = (b[6] & 0x0f) | 0x40
  b[8] = (b[8] & 0x3f) | 0x80
  const h = [...b].map((x) => x.toString(16).padStart(2, '0')).join('')
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`
}

let running = null
export function syncNow({ full = false } = {}) {
  if (running) return running
  if (!getToken()) return Promise.resolve() // not logged in yet: bills stay safely in the outbox
  running = (async () => {
    update({ syncing: true })
    try {
      await push()
      await pull(full || !(await getMeta('lastSync')))
      update({ online: true, error: '', lastSync: new Date() })
    } catch (e) {
      update({ online: false, error: e.message })
    } finally {
      await refreshCounts()
      update({ syncing: false })
      running = null
    }
  })()
  return running
}

let timer = null
export function startSync() {
  if (timer) return
  refreshCounts()
  syncNow({ full: true })
  timer = setInterval(() => syncNow(), EVERY_MS)
  window.addEventListener('online', () => syncNow())
  window.addEventListener('offline', () => update({ online: false }))
}

/** React hook: live sync status for the top bar. */
export function useSync() {
  const [s, setS] = useState(state)
  useEffect(() => {
    listeners.add(setS)
    return () => listeners.delete(setS)
  }, [])
  return s
}

/**
 * Save a finished bill on this counter. Works with no internet.
 * Gives it the next bill number, changes local stock, and queues it for the server.
 * Lines with negative qty are returns (they carry `returned_from` = the sold line's id).
 */
export async function saveBillLocally({ lines, discount, cash, upi, customer_name, customer_phone,
  credit_used = 0, credit_note_code = '', credit_issued = 0, return_override = '' }) {
  const device = await deviceId()
  const bill = await db.transaction('rw', db.meta, db.outbox, db.bills, db.variants, async () => {
    const number = await getMeta('nextBillNumber', 1)
    await setMeta('nextBillNumber', number + 1)
    const subtotal = round2(lines.reduce((a, l) => a + l.price * l.qty, 0))
    const total = round2(subtotal - (discount || 0))
    const b = {
      id: newId(),
      number,
      created_at: new Date().toISOString(),
      device,
      customer_name: customer_name || '',
      customer_phone: customer_phone || '',
      discount: discount || 0,
      cash_amount: round2(cash),
      upi_amount: round2(upi),
      credit_used: round2(credit_used),
      credit_note_code,
      credit_issued: round2(credit_issued),
      return_override,
      lines: lines.map((l) => ({
        client_id: newId(), variant: l.id, qty: l.qty, price: l.price, description: l.description, size: l.size,
        ...(l.returned_from ? { returned_from: l.returned_from } : {}),
      })),
    }
    await db.outbox.put(b)
    // local copy uses the same field names as the server's bill:
    // credit_note_used_code = note spent on this bill, credit_note_code = note this bill created
    const local = { ...b, subtotal, total, status: 'done', synced: false,
      credit_note_used_code: credit_note_code || null,
      credit_note_code: b.credit_issued ? `CN${number}` : null }
    await db.bills.put(local)
    for (const l of lines) {
      const v = await db.variants.get(l.id)
      if (v) await db.variants.update(l.id, { stock: v.stock - l.qty }) // a return (qty < 0) adds back
    }
    return local
  })
  await refreshCounts()
  syncNow() // send right away if online; harmless if not
  return bill
}

export const round2 = (n) => Math.round((Number(n) || 0) * 100) / 100
