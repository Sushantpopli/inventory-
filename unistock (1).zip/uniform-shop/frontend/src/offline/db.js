// Local database on the counter computer (IndexedDB in the browser).
// Billing reads and writes ONLY here, so it keeps working when the internet is off.
import Dexie from 'dexie'

export const db = new Dexie('uniform-shop')

db.version(1).stores({
  variants: 'id, barcode, product', // every size the shop sells, with price + stock
  outbox: 'id, number',             // bills not yet sent to the server
  bills: 'id, number, created_at',  // bills made on this counter (for reprint)
  meta: 'key',                      // settings, last sync time, next bill number, device id
})

export async function getMeta(key, fallback = null) {
  const row = await db.meta.get(key)
  return row ? row.value : fallback
}

export function setMeta(key, value) {
  return db.meta.put({ key, value })
}

export async function deviceId() {
  let id = await getMeta('device')
  if (!id) {
    id = 'counter-' + Math.random().toString(36).slice(2, 7)
    await setMeta('device', id)
  }
  return id
}
