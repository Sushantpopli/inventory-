// Finding what a customer bought, so it can be returned or exchanged.
// Bills made on this counter are on this computer, so this works without internet.
// Older bills (or bills from another counter) are fetched from the server when online.
import { api } from '../api.js'
import { db } from './db.js'
import { round2 } from './sync.js'

export const daysOld = (bill) => Math.floor((Date.now() - new Date(bill.created_at)) / 86400000)

/** What one piece was really paid: price minus its share of the bill's discount. */
export function refundPrice(bill, line) {
  const sold = bill.lines.filter((l) => l.qty > 0).reduce((a, l) => a + l.price * l.qty, 0)
  if (!bill.discount || !sold) return Number(line.price)
  return round2(line.price * (1 - bill.discount / sold))
}

/** Pieces of a sold line already returned on this counter's bills (not cancelled). */
async function returnedLocally(lineId) {
  let n = 0
  await db.bills.each((b) => {
    if (b.status === 'cancelled') return
    b.lines.forEach((l) => { if (l.returned_from === lineId) n += -l.qty })
  })
  return n
}

function fromServer(b) {
  return {
    ...b, fromServer: true, synced: true,
    discount: Number(b.discount), total: Number(b.total), subtotal: Number(b.subtotal),
    cash_amount: Number(b.cash_amount), upi_amount: Number(b.upi_amount),
    credit_used: Number(b.credit_used), credit_issued: Number(b.credit_issued),
    lines: b.lines.map((l) => ({ ...l, price: Number(l.price) })),
  }
}

/** Add `returnable` (pieces that can still come back) and `refund` to each sold line. */
async function withReturnInfo(bill) {
  const lines = []
  for (const l of bill.lines) {
    if (l.qty <= 0 || !l.client_id) continue
    const done = Math.max(await returnedLocally(l.client_id), l.returned_qty || 0)
    lines.push({ ...l, returnable: l.qty - done, refund: refundPrice(bill, l) })
  }
  return { ...bill, sold: lines, age: daysOld(bill) }
}

/** Bill by number: this computer first, then the server. */
export async function loadBill(number, online) {
  const n = parseInt(number, 10)
  if (!n) return null
  let bill = await db.bills.where('number').equals(n).first()
  if (!bill && online) {
    const r = await api.findBill(String(n)).catch(() => null)
    const hit = r?.results.find((b) => b.number === n)
    if (hit) bill = fromServer(hit)
  }
  return bill ? withReturnInfo(bill) : null
}

/** Recent bills that sold this size (customer has no bill number, but has the item). */
export async function billsWithItem(variantId, days, online) {
  const since = Date.now() - (days + 1) * 86400000
  const found = new Map()
  await db.bills.each((b) => {
    if (b.status !== 'cancelled' && new Date(b.created_at) >= since && b.lines.some((l) => l.variant === variantId && l.qty > 0)) {
      found.set(b.id, b)
    }
  })
  if (online) {
    const r = await api.billsWithItem(variantId, days).catch(() => null)
    r?.results.forEach((b) => { if (!found.has(b.id)) found.set(b.id, fromServer(b)) })
  }
  const list = [...found.values()].sort((a, b) => b.number - a.number).slice(0, 10)
  return Promise.all(list.map(withReturnInfo))
}
