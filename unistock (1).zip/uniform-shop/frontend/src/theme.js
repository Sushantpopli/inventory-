// Dark (default) or light screen, remembered on this computer.
import { useEffect, useState } from 'react'

const read = () => { try { return localStorage.getItem('theme') || 'dark' } catch { return 'dark' } }
export const applyTheme = (t = read()) => { document.documentElement.dataset.theme = t }

export function useTheme() {
  const [theme, set] = useState(read)
  useEffect(() => { applyTheme(theme); try { localStorage.setItem('theme', theme) } catch { /* ignore */ } }, [theme])
  return [theme, () => set(theme === 'dark' ? 'light' : 'dark')]
}
