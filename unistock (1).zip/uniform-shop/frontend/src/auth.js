// Who is logged in on this computer/phone. The token is kept so the counter stays
// logged in (and keeps billing) even when the internet is off.
import { useEffect, useState } from 'react'

const KEY = 'auth'
let auth = load()
const listeners = new Set()

function load() {
  try { return JSON.parse(localStorage.getItem(KEY)) || null } catch { return null }
}

export function getAuth() { return auth }
export function getToken() { return auth?.token || null }
export const isOwner = () => auth?.user?.role === 'owner'

export function setAuth(next) {
  auth = next
  try {
    if (next) localStorage.setItem(KEY, JSON.stringify(next))
    else localStorage.removeItem(KEY)
  } catch { /* private mode: stays logged in until the tab closes */ }
  listeners.forEach((fn) => fn(auth))
}

export const clearAuth = () => setAuth(null)

export function useAuth() {
  const [a, setA] = useState(auth)
  useEffect(() => {
    listeners.add(setA)
    return () => listeners.delete(setA)
  }, [])
  return a
}
