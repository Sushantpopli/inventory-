// Small wrapper around fetch for the Django API.
const BASE = import.meta.env.VITE_API_URL || '/api'

import { clearAuth, getToken } from './auth.js'

function authHeaders() {
  const t = getToken()
  return t ? { Authorization: `Token ${t}` } : {}
}

async function request(path, { method = 'GET', body, form } = {}) {
  const opts = { method, headers: authHeaders() }
  if (form) {
    opts.body = form
  } else if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json'
    opts.body = JSON.stringify(body)
  }
  let res
  try {
    res = await fetch(BASE + path, opts)
  } catch {
    throw new Error('Cannot reach the server. Check that the backend is running.')
  }
  const data = res.status === 204 ? null : await res.json().catch(() => null)
  if (res.status === 401 && getToken()) clearAuth() // login ended (PIN changed / person removed)
  if (!res.ok) {
    const err = new Error(readError(data) || `Something went wrong (${res.status})`)
    err.data = data
    throw err
  }
  return data
}

// Turn DRF error shapes into one readable sentence
function readError(data) {
  if (!data) return ''
  if (typeof data === 'string') return data
  if (data.detail) return data.detail
  if (data.errors) return ''
  return Object.entries(data)
    .map(([k, v]) => `${k === 'non_field_errors' ? '' : k + ': '}${Array.isArray(v) ? v.join(' ') : v}`)
    .join(' · ')
}

const qs = (params) => {
  const p = new URLSearchParams(Object.entries(params).filter(([, v]) => v !== '' && v != null))
  const s = p.toString()
  return s ? '?' + s : ''
}

/** Files (Excel, label PDFs) need the login too, so fetch them instead of plain links. */
async function fetchFile(url) {
  const res = await fetch(url, { headers: authHeaders() })
  if (!res.ok) {
    const data = await res.json().catch(() => null)
    throw new Error(readError(data) || `Could not download (${res.status})`)
  }
  return res.blob()
}

export async function download(url, filename) {
  const blob = await fetchFile(url)
  const a = document.createElement('a')
  a.href = URL.createObjectURL(blob)
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  setTimeout(() => URL.revokeObjectURL(a.href), 10000)
}

/** Open a PDF in a new tab (the tab opens at once so the browser doesn't block it). */
export async function openPdf(url) {
  const win = window.open('', '_blank')
  try {
    const blob = await fetchFile(url)
    const link = URL.createObjectURL(blob)
    if (win) win.location = link
    else window.location = link
  } catch (e) {
    win?.close()
    throw e
  }
}

export const api = {
  schools: (params = {}) => request('/catalog/schools/' + qs({ limit: 1000, ...params })),
  addSchool: (body) => request('/catalog/schools/', { method: 'POST', body }),
  updateSchool: (id, body) => request(`/catalog/schools/${id}/`, { method: 'PATCH', body }),
  categories: () => request('/catalog/categories/'),
  products: (params = {}) => request('/catalog/products/' + qs({ limit: 500, ...params })),
  createProduct: (body) => request('/catalog/products/', { method: 'POST', body }),
  updateProduct: (id, body) => request(`/catalog/products/${id}/`, { method: 'PATCH', body }),
  addSizes: (id, body) => request(`/catalog/products/${id}/add_sizes/`, { method: 'POST', body }),
  updateVariant: (id, body) => request(`/catalog/variants/${id}/`, { method: 'PATCH', body }),
  importExcel: (file, dryRun, createSchools) => {
    const f = new FormData()
    f.append('file', file)
    f.append('dry_run', dryRun ? '1' : '0')
    f.append('create_missing_schools', createSchools ? '1' : '0')
    return request('/catalog/import/', { method: 'POST', form: f })
  },
  templateUrl: BASE + '/catalog/import/template/',
  lookupBarcode: (code) => request(`/catalog/variants/barcode/${encodeURIComponent(code)}/`),
  // labels (Module 2)
  labelLayouts: () => request('/labels/layouts/'),
  labelQueue: () => request('/labels/queue/'),
  queueLabel: (variant, copies = 1) => request('/labels/queue/', { method: 'POST', body: { variant, copies } }),
  queueProduct: (product, copies = 'stock') => request('/labels/queue/add_product/', { method: 'POST', body: { product, copies } }),
  setLabelCopies: (id, copies) => request(`/labels/queue/${id}/`, { method: 'PATCH', body: { copies } }),
  removeLabel: (id) => request(`/labels/queue/${id}/`, { method: 'DELETE' }),
  clearLabels: () => request('/labels/queue/clear/', { method: 'POST' }),
  labelsPdfUrl: (params) => BASE + '/labels/pdf/' + qs(params),
  // login & staff (Module 7)
  people: () => request('/auth/people/'),
  login: (user_id, pin) => request('/auth/login/', { method: 'POST', body: { user_id, pin } }),
  logout: () => request('/auth/logout/', { method: 'POST' }),
  me: () => request('/auth/me/'),
  staff: () => request('/auth/staff/'),
  addStaff: (body) => request('/auth/staff/', { method: 'POST', body }),
  updateStaff: (id, body) => request(`/auth/staff/${id}/`, { method: 'PATCH', body }),
  today: () => request('/reports/today/'),
  // billing (Module 3) — the counter itself uses offline/sync.js; these need internet
  shopSettings: () => request('/billing/settings/'),
  saveShopSettings: (body) => request('/billing/settings/', { method: 'PATCH', body }),
  findBill: (q) => request('/billing/bills/' + qs({ q })),
  billsWithItem: (variant, days) => request('/billing/bills/' + qs({ variant, days })),
  creditNote: (code) => request(`/billing/credit-notes/${encodeURIComponent(code.trim())}/`),
  cancelBill: (id, reason) => request(`/billing/bills/${id}/cancel/`, { method: 'POST', body: { reason } }),
  // stock (Module 4)
  searchVariants: (q) => request('/catalog/variants/' + qs({ q, limit: 30 })),
  stockEntries: () => request('/stock/entries/' + qs({ limit: 20 })),
  saveStockIn: (body) => request('/stock/entries/', { method: 'POST', body }),
  cancelStockIn: (id, reason) => request(`/stock/entries/${id}/cancel/`, { method: 'POST', body: { reason } }),
  correctStock: (variant, counted, reason) => request('/stock/correct/', { method: 'POST', body: { variant, counted, reason } }),
  stockHistory: (variant) => request('/stock/history/' + qs({ variant })),
  // reports (Module 6)
  reportSummary: (from, to) => request('/reports/summary/' + qs({ from, to })),
  reportTop: (from, to, by) => request('/reports/top/' + qs({ from, to, by, limit: 30 })),
  lowStock: (school) => request('/reports/low-stock/' + qs({ school })),
  salesXlsxUrl: (from, to) => BASE + '/reports/sales.xlsx' + qs({ from, to }),
  lowStockXlsxUrl: (school) => BASE + '/reports/low-stock.xlsx' + qs({ school }),
}
