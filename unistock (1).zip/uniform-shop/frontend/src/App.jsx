import { useEffect, useRef, useState } from 'react'
import { NavLink, Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { api } from './api.js'
import { clearAuth, useAuth } from './auth.js'
import Icon from './components/Icon.jsx'
import Toasts from './components/Toast.jsx'
import { useLang } from './i18n.jsx'
import { syncNow, useSync } from './offline/sync.js'
import { useTheme } from './theme.js'
import BillingPage from './pages/BillingPage.jsx'
import BillsPage from './pages/BillsPage.jsx'
import ImportPage from './pages/ImportPage.jsx'
import LabelsPage from './pages/LabelsPage.jsx'
import LoginPage from './pages/LoginPage.jsx'
import LowStockPage from './pages/LowStockPage.jsx'
import ProductsPage from './pages/ProductsPage.jsx'
import ReportsPage from './pages/ReportsPage.jsx'
import SchoolsPage from './pages/SchoolsPage.jsx'
import SettingsPage from './pages/SettingsPage.jsx'
import StaffPage from './pages/StaffPage.jsx'
import StockInPage from './pages/StockInPage.jsx'
import TodayPage from './pages/TodayPage.jsx'

const ReturnPage = () => <BillingPage kind="return" />

// Every screen: [path, title key, hint key, page, owner only]
const PAGES = [
  ['/today', 'todayTab', 'hToday', TodayPage, true],
  ['/bill', 'genBill', 'hBill', BillingPage, false],
  ['/return', 'returnBtn', 'hReturn', ReturnPage, false],
  ['/bills', 'billHistory', 'hBills', BillsPage, false],
  ['/stock-in', 'addStock', 'hStockIn', StockInPage, false],
  ['/labels', 'printBarcodes', 'hLabels', LabelsPage, false],
  ['/products', 'viewStock', 'hProducts', ProductsPage, false],
  ['/low-stock', 'lowStockTab', 'hLow', LowStockPage, false],
  ['/reports', 'reports', 'hReports', ReportsPage, true],
  ['/settings', 'settings', 'hSettings', SettingsPage, false],
  ['/staff', 'staff', 'hSettings', StaffPage, true],
  ['/schools', 'schools', 'hSettings', SchoolsPage, true],
  ['/import', 'import', 'hSettings', ImportPage, true],
]
const SETTINGS_GROUP = ['/settings', '/staff', '/schools', '/import']

// The sidebar: one item per job, under three small headings. `phone` = shown in the phone's bottom bar.
const NAV = [
  { head: 'gSell' },
  { to: '/bill', key: 'genBill', short: 'billing', icon: 'bill', phone: true },
  { to: '/return', key: 'returnBtn', icon: 'swap' },
  { to: '/bills', key: 'billHistory', short: 'bills', icon: 'bills', phone: true },
  { head: 'gStock' },
  { to: '/stock-in', key: 'addStock', icon: 'plus' },
  { to: '/labels', key: 'printBarcodes', icon: 'scan' },
  { to: '/products', key: 'viewStock', short: 'stock', icon: 'box', phone: true },
  { to: '/low-stock', key: 'lowStockTab', icon: 'warn' },
  { head: 'gOwner' },
  { to: '/today', key: 'todayTab', icon: 'today', owner: true, phone: true },
  { to: '/reports', key: 'reports', icon: 'reports', owner: true, phone: true },
  { to: '/settings', key: 'settings', icon: 'settings', group: SETTINGS_GROUP, phone: true },
]

function Clock() {
  const [now, setNow] = useState(new Date())
  useEffect(() => { const id = setInterval(() => setNow(new Date()), 20000); return () => clearInterval(id) }, [])
  const d = now.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })
  const tm = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })
  return <span className="hchip clock"><Icon name="clock" />{d} · {tm}</span>
}

function Status() {
  const { t } = useLang()
  const s = useSync()
  let k = '', text = t('online')
  if (!s.online) { k = 'low'; text = t('offline') }
  if (s.pending) text += ` · ${s.pending} ${t('waiting')}`
  if (s.failed) { k = 'out'; text = `${s.failed} ${t('syncProblem')}` }
  return <span className={`status syncchip ${k}`} role="status"><span className="dot" />{s.syncing && s.pending ? t('syncing') : text}</span>
}

/** Tap your name: language, light/dark screen, log out. Set once, so kept out of the way. */
function UserMenu({ id, name, role, initial, theme, toggleTheme, logout, compact }) {
  const { t, lang, setLang } = useLang()
  const [open, setOpen] = useState(false)
  const ref = useRef(null)
  useEffect(() => {
    if (!open) return undefined
    const close = (e) => { if (!ref.current?.contains(e.target)) setOpen(false) }
    document.addEventListener('mousedown', close)
    return () => document.removeEventListener('mousedown', close)
  }, [open])
  return (
    <div className="umenu" ref={ref}>
      {compact
        ? <button type="button" id={id} className="avatarbtn" aria-expanded={open} aria-label={name} onClick={() => setOpen(!open)}><span className="avatar">{initial}</span></button>
        : (
          <button type="button" id={id} className="userbtn" aria-expanded={open} onClick={() => setOpen(!open)}>
            <span className="avatar">{initial}</span>
            <span><b>{name}</b><span>{role}</span></span>
            <Icon name="chev" />
          </button>
        )}
      {open && (
        <div className={`umenu-pop ${compact ? 'down' : ''}`}>
          <div className="mrow"><span className="row" style={{ gap: 8 }}><Icon name="globe" />{t('language')}</span>
            <div className="langtoggle" role="group" aria-label="Language">
              <button type="button" aria-pressed={lang === 'en'} onClick={() => setLang('en')}>EN</button>
              <button type="button" aria-pressed={lang === 'hi'} onClick={() => setLang('hi')}>हिं</button>
            </div>
          </div>
          <button type="button" id="theme" className="mitem" onClick={toggleTheme}><Icon name={theme === 'dark' ? 'sun' : 'moon'} />{theme === 'dark' ? t('themeLight') : t('themeDark')}</button>
          <hr />
          <button type="button" className="mitem" onClick={logout}><Icon name="logout" />{t('logout')}</button>
        </div>
      )}
    </div>
  )
}

export default function App() {
  const { t } = useLang()
  const auth = useAuth()
  const [theme, toggleTheme] = useTheme()
  const { pathname } = useLocation()
  if (!auth) return <LoginPage />

  const owner = auth.user.role === 'owner'
  const pages = PAGES.filter((p) => owner || !p[4])
  const allowed = new Set(pages.map((p) => p[0]))
  // drop owner items for counter staff, and headings left with nothing under them
  const items = NAV.filter((n) => owner || !n.owner)
  const nav = items.filter((n, i) => !n.head || (items[i + 1] && !items[i + 1].head))
  const current = pages.find((p) => p[0] === pathname)
  const inSettings = SETTINGS_GROUP.includes(pathname)
  const tabs = inSettings ? SETTINGS_GROUP.filter((p) => allowed.has(p)) : []
  const home = owner && window.innerWidth < 760 ? '/today' : '/bill'
  const logout = async () => {
    await syncNow().catch(() => {}) // try to send waiting bills first; they stay safe either way
    api.logout().catch(() => {})
    clearAuth()
  }
  const initial = auth.user.name.trim().charAt(0).toUpperCase()

  return (
    <div className="shell">
      <aside className="appnav" aria-label="Main">
        <div className="brand">
          <span className="crest"><Icon name="bag" /></span>
          <div><b>UniStock</b><small>{t('appTag')}</small></div>
        </div>
        {nav.map((n) => n.head ? <div key={n.head} className="navhead">{t(n.head)}</div> : (
          <NavLink key={n.to} to={n.to} className={() => `navitem ${n.phone ? '' : 'desk'} ${(n.group ? n.group.includes(pathname) : pathname === n.to) ? 'active' : ''}`}>
            <Icon name={n.icon} /><span className="long">{t(n.key)}</span><span className="short">{t(n.short || n.key)}</span>
          </NavLink>
        ))}
        <div className="navfoot">
          <UserMenu id="user-menu" name={auth.user.name} role={owner ? t('owner') : t('counterRole')} initial={initial} theme={theme} toggleTheme={toggleTheme} logout={logout} />
        </div>
      </aside>

      <main className="page">
        <header className="pagehead">
          <div className="titles">
            <h1>{inSettings ? t('settings') : current ? t(current[1]) : ''}</h1>
            {current && <p>{t(current[2])}</p>}
          </div>
          <Status />
          <Clock />
          <span className="phone-only">
            <UserMenu id="user-menu-m" compact initial={initial} name={auth.user.name} role={owner ? t('owner') : t('counterRole')} theme={theme} toggleTheme={toggleTheme} logout={logout} />
          </span>
        </header>
        <div className="content">
          {tabs.length > 1 && (
            <nav className="subnav" aria-label={t('settings')}>
              {tabs.map((p) => <NavLink key={p} to={p}>{t(PAGES.find((x) => x[0] === p)[1])}</NavLink>)}
            </nav>
          )}
          <Routes>
            <Route path="/" element={<Navigate to={home} replace />} />
            {pages.map(([path, , , Page]) => <Route key={path} path={path} element={<Page key={path} />} />)}
            <Route path="*" element={<Navigate to={home} replace />} />
          </Routes>
        </div>
      </main>
      <Toasts />
    </div>
  )
}
