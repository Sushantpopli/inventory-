from decimal import Decimal
from io import BytesIO, StringIO

from django.core.files.uploadedfile import SimpleUploadedFile
from django.core.management import call_command
from django.test import TestCase
from openpyxl import Workbook
from config.testing import owner_client

from catalog import services
from catalog.importer import build_template, import_catalog
from catalog.models import Category, Product, School, StockMovement, Variant


class Base(TestCase):
    def setUp(self):
        call_command("seed_shop", stdout=StringIO())
        self.dps = School.objects.get(short_name="DPS")
        self.jms = School.objects.get(short_name="JMS")
        self.shirt = Category.objects.get(name="Shirt")
        self.pant = Category.objects.get(name="Pant")


class SizeRules(TestCase):
    def test_sort_order(self):
        sizes = ["Free", "40-34", "XL", "22", "40", "40-32", "S", "8"]
        self.assertEqual(sorted(sizes, key=services.size_sort_key),
                         ["8", "22", "40", "40-32", "40-34", "S", "XL", "Free"])

    def test_normalise(self):
        self.assertEqual(services.normalise_size(30.0), "30")
        self.assertEqual(services.normalise_size("40 - 32"), "40-32")
        self.assertEqual(services.normalise_size("free"), "Free")
        self.assertEqual(services.normalise_size("xl"), "XL")

    def test_ladder(self):
        self.assertEqual(services.ladder_prices(["28", "30", "32"], 200, 15),
                         [Decimal(200), Decimal(215), Decimal(230)])


class ProductRules(Base):
    def make_shirt(self, **kw):
        args = dict(category=self.shirt, schools=[self.dps], season="summer", gender="boy", name="Half sleeve",
                    sizes=["28", "30", "32"], start_price=200, step=20)
        args.update(kw)
        return services.create_product(**args)

    def test_create_with_ladder_and_barcodes(self):
        p = self.make_shirt(opening_stock=[5, 0, 2])
        vs = list(p.variants.order_by("sort_order"))
        self.assertEqual([v.size for v in vs], ["28", "30", "32"])
        self.assertEqual([v.price for v in vs], [Decimal(200), Decimal(220), Decimal(240)])
        self.assertEqual([v.stock for v in vs], [5, 0, 2])
        self.assertEqual(len({v.barcode for v in vs}), 3)
        self.assertEqual(StockMovement.objects.filter(kind="opening").count(), 2)  # zero stock = no movement

    def test_duplicate_product_blocked(self):
        self.make_shirt()
        with self.assertRaises(ValueError):
            self.make_shirt()

    def test_same_design_other_school_allowed(self):
        self.make_shirt()
        self.make_shirt(schools=[self.jms])
        self.assertEqual(Product.objects.count(), 2)

    def test_add_sizes_skips_existing(self):
        p = self.make_shirt()
        new = services.add_sizes(p, ["32", "34"], [240, 260])
        self.assertEqual([v.size for v in new], ["34"])

    def test_barcodes_never_repeat(self):
        a = services.next_barcodes(3)
        b = services.next_barcodes(3)
        self.assertFalse(set(a) & set(b))

    def test_stock_only_changes_by_movement(self):
        p = self.make_shirt()
        v = p.variants.first()
        services.record_movement(v, 10, "stock_in")
        services.record_movement(v, -3, "sale", reference="Bill 1")
        v.refresh_from_db()
        self.assertEqual(v.stock, 7)
        self.assertEqual(v.stock_status, "ok")


def make_xlsx(rows, headers=None):
    wb = Workbook()
    ws = wb.active
    ws.title = "Products"
    ws.append(["note row"])
    ws.append(headers or ["Schools", "Item", "Season", "Gender", "Detail", "Size", "Selling price",
                          "Cost price", "Opening stock", "Low stock alert"])
    for r in rows:
        ws.append(r)
    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf


class ExcelImport(Base):
    rows = [
        ["DPS", "Shirt", "Summer", "Boy", "Half sleeve", "28", 240, 160, 12, 3],
        ["DPS", "Shirt", "Summer", "Boy", "Half sleeve", 30, 250, 168, 8, 3],
        ["DPS, JMS", "Tie", "All", "Unisex", "", "Free", 80, 40, 30, 5],
        ["", "Pant", "Summer", "Boy", "Grey", "40-32", 420, None, 2, None],
        ["COMMON", "Socks", "", "", "White", "6", 60, None, None, None],
    ]

    def test_dry_run_saves_nothing(self):
        r = import_catalog(make_xlsx(self.rows), dry_run=True)
        self.assertTrue(r.ok, r.errors)
        self.assertEqual((r.products_new, r.sizes_new, r.units_opening), (4, 5, 52))
        self.assertEqual(Product.objects.count(), 0)
        self.assertEqual(Variant.objects.count(), 0)

    def test_real_import_and_rerun(self):
        r = import_catalog(make_xlsx(self.rows), dry_run=False)
        self.assertTrue(r.ok, r.errors)
        self.assertEqual(Variant.objects.count(), 5)
        tie = Product.objects.get(category__name="Tie")
        self.assertEqual({s.short_name for s in tie.schools.all()}, {"DPS", "JMS"})
        self.assertTrue(Product.objects.get(category__name="Pant").is_common)
        self.assertEqual(Variant.objects.get(size="28").stock, 12)
        # running it again adds nothing and does not double the stock
        r2 = import_catalog(make_xlsx(self.rows), dry_run=False)
        self.assertEqual((r2.products_new, r2.sizes_new, r2.sizes_skipped), (0, 0, 5))
        self.assertEqual(Variant.objects.get(size="28").stock, 12)

    def test_errors_reported_with_row_numbers(self):
        bad = [
            ["XYZ School", "Shirt", "Summer", "Boy", "", "28", 240, None, None, None],
            ["DPS", "Shirt", "Monsoon", "Boy", "", "30", "abc", None, None, None],
            ["DPS", "Shirt", "Summer", "Boy", "", "", 200, None, None, None],
        ]
        r = import_catalog(make_xlsx(bad), dry_run=False)
        self.assertFalse(r.ok)
        rows = {e["row"] for e in r.errors}
        self.assertEqual(rows, {3, 4, 5})
        self.assertEqual(Product.objects.count(), 0)

    def test_create_missing_schools(self):
        r = import_catalog(make_xlsx([["New Public School", "Shirt", "", "", "", "28", 200, None, 1, None]]),
                           dry_run=False, create_missing_schools=True)
        self.assertTrue(r.ok, r.errors)
        self.assertTrue(School.objects.filter(name="New Public School").exists())

    def test_old_visit_template_headers_work(self):
        headers = ["School", "Item", "Gender", "Type / variant", "Size", "Selling price (₹)", "Cost price (₹)",
                   "Current stock (qty)", "Low stock alert", "Supplier", "Notes"]
        r = import_catalog(make_xlsx([["DPS", "Shirt", "Boy", "Half sleeve", "28", 350, 240, 12, 3, "X", ""]],
                                     headers), dry_run=False)
        self.assertTrue(r.ok, r.errors)
        self.assertEqual(Variant.objects.get().stock, 12)

    def test_own_template_imports(self):
        r = import_catalog(BytesIO(build_template()), dry_run=True)
        self.assertTrue(r.ok, r.errors)
        self.assertEqual(r.sizes_new, 4)


class Api(Base):
    def setUp(self):
        super().setUp()
        self.c = owner_client()

    def test_create_product_and_search_and_scan(self):
        res = self.c.post("/api/catalog/products/", {
            "category": str(self.shirt.id), "school_ids": [str(self.dps.id)], "season": "summer",
            "gender": "boy", "name": "Half sleeve", "sizes": ["28", "30"], "start_price": "200", "step": "10",
            "opening_stock": [4, 6],
        }, format="json")
        self.assertEqual(res.status_code, 201, res.data)
        self.assertEqual(len(res.data["variants"]), 2)

        res = self.c.get("/api/catalog/variants/", {"q": "dps shirt 30"})
        self.assertEqual(res.data["count"], 1)
        hit = res.data["results"][0]
        self.assertEqual((hit["size"], hit["price"], hit["stock"]), ("30", "210.00", 6))

        res = self.c.get(f"/api/catalog/variants/barcode/{hit['barcode']}/")
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.data["product_name"], "DPS · Shirt · Half sleeve")
        self.assertEqual(self.c.get("/api/catalog/variants/barcode/000/").status_code, 404)

    def test_duplicate_gives_clear_message(self):
        body = {"category": str(self.shirt.id), "sizes": ["28"], "start_price": "200"}
        self.assertEqual(self.c.post("/api/catalog/products/", body, format="json").status_code, 201)
        res = self.c.post("/api/catalog/products/", body, format="json")
        self.assertEqual(res.status_code, 400)
        self.assertIn("already exists", res.data["detail"])

    def test_edit_price_but_not_stock(self):
        p = services.create_product(category=self.shirt, schools=[], season="all", gender="unisex",
                                    sizes=["28"], start_price=200, opening_stock=[5])
        v = p.variants.get()
        res = self.c.patch(f"/api/catalog/variants/{v.id}/", {"price": "225", "stock": 999}, format="json")
        self.assertEqual(res.status_code, 200)
        v.refresh_from_db()
        self.assertEqual((v.price, v.stock), (Decimal("225"), 5))

    def test_school_filter_with_common(self):
        services.create_product(category=self.shirt, schools=[self.dps], season="all", gender="boy",
                                sizes=["28"], start_price=200)
        services.create_product(category=self.pant, schools=[], season="all", gender="boy",
                                sizes=["28"], start_price=200)
        services.create_product(category=self.pant, schools=[self.jms], season="all", gender="boy",
                                sizes=["28"], start_price=200)
        only = self.c.get("/api/catalog/products/", {"school": str(self.dps.id)}).data["count"]
        withc = self.c.get("/api/catalog/products/", {"school": str(self.dps.id), "include_common": "1"}).data["count"]
        self.assertEqual((only, withc), (1, 2))

    def test_low_stock_list(self):
        services.create_product(category=self.shirt, schools=[], season="all", gender="unisex",
                                sizes=["28", "30", "32"], start_price=200, opening_stock=[0, 2, 20])
        res = self.c.get("/api/catalog/variants/", {"low": "1"})
        self.assertEqual([r["size"] for r in res.data["results"]], ["28", "30"])

    def test_import_endpoint(self):
        f = SimpleUploadedFile("c.xlsx", make_xlsx(ExcelImport.rows).getvalue())
        res = self.c.post("/api/catalog/import/", {"file": f, "dry_run": "1"}, format="multipart")
        self.assertEqual(res.status_code, 200, res.data)
        self.assertEqual(res.data["sizes_new"], 5)
        self.assertEqual(Variant.objects.count(), 0)
        self.assertEqual(self.c.get("/api/catalog/import/template/").status_code, 200)
