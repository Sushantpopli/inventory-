from django.urls import include, path
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register("schools", views.SchoolViewSet, basename="school")
router.register("categories", views.CategoryViewSet, basename="category")
router.register("products", views.ProductViewSet, basename="product")
router.register("variants", views.VariantViewSet, basename="variant")

urlpatterns = [
    path("size-presets/", views.size_presets),
    path("import/", views.import_excel),
    path("import/template/", views.import_template),
    path("", include(router.urls)),
]
