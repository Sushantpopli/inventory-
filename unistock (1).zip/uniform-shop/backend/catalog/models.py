"""
Catalog: schools, item categories, products (designs) and their sizes (variants).

Key ideas
- A Product is one design, e.g. "DPS Shirt, half sleeve, summer, boy".
- A Product can belong to many schools, or to none. No schools = COMMON item
  (white shirt, grey pant, socks…) that any customer can buy.
- A Variant is one size of a product. It has its own price, barcode and stock.
- Stock is never typed over. Every change is a StockMovement; Variant.stock is a
  running total kept in sync by catalog.services.record_movement().
"""
import uuid

from django.conf import settings
from django.db import models


class TimeStamped(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class School(TimeStamped):
    name = models.CharField(max_length=120, unique=True)
    short_name = models.CharField(max_length=20, unique=True, help_text="Shown on buttons and bills, e.g. DPS")
    active = models.BooleanField(default=True)
    notes = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class Category(TimeStamped):
    """Item type: Shirt, Pant, Skirt, Tie…"""

    name = models.CharField(max_length=60, unique=True)
    name_hi = models.CharField("Hindi name", max_length=60, blank=True)
    sort_order = models.PositiveIntegerField(default=100)
    default_sizes = models.CharField(
        max_length=500,
        blank=True,
        help_text="Comma-separated sizes suggested when adding a product, e.g. 22,24,26 or Free",
    )

    class Meta:
        ordering = ["sort_order", "name"]
        verbose_name_plural = "categories"

    def __str__(self):
        return self.name

    def default_size_list(self):
        return [s.strip() for s in self.default_sizes.split(",") if s.strip()]


class Product(TimeStamped):
    class Season(models.TextChoices):
        SUMMER = "summer", "Summer"
        WINTER = "winter", "Winter"
        ALL = "all", "All season"

    class Gender(models.TextChoices):
        BOY = "boy", "Boy"
        GIRL = "girl", "Girl"
        UNISEX = "unisex", "Unisex"

    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="products")
    schools = models.ManyToManyField(
        School, blank=True, related_name="products", help_text="Leave empty for a common item"
    )
    name = models.CharField(
        max_length=120, blank=True, help_text="Extra detail, e.g. 'Half sleeve' or 'Grey checks'"
    )
    season = models.CharField(max_length=10, choices=Season.choices, default=Season.ALL)
    gender = models.CharField(max_length=10, choices=Gender.choices, default=Gender.UNISEX)
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ["category__sort_order", "category__name", "name"]

    def __str__(self):
        return self.display_name()

    @property
    def is_common(self):
        return not self.schools.exists()

    def school_label(self):
        names = [s.short_name for s in self.schools.all()]
        if not names:
            return "Common"
        if len(names) > 3:
            return f"{', '.join(names[:3])} +{len(names) - 3}"
        return ", ".join(names)

    def display_name(self):
        parts = [self.school_label(), self.category.name]
        if self.name:
            parts.append(self.name)
        return " · ".join(parts)


class Variant(TimeStamped):
    """One size of a product. This is what gets a barcode and gets sold."""

    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="variants")
    size = models.CharField(max_length=20, help_text="e.g. 30, 40-32, Free")
    sort_order = models.IntegerField(default=0)
    price = models.DecimalField(max_digits=9, decimal_places=2)
    cost_price = models.DecimalField(max_digits=9, decimal_places=2, null=True, blank=True)
    barcode = models.CharField(max_length=32, unique=True)
    low_stock_level = models.PositiveIntegerField(default=settings.SHOP_DEFAULT_LOW_STOCK)
    stock = models.IntegerField(default=0, editable=False, help_text="Running total of stock movements")
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ["product", "sort_order", "size"]
        constraints = [
            models.UniqueConstraint(fields=["product", "size"], name="unique_size_per_product"),
        ]

    def __str__(self):
        return f"{self.product.display_name()} · {self.size}"

    @property
    def stock_status(self):
        if self.stock <= 0:
            return "out"
        if self.stock <= self.low_stock_level:
            return "low"
        return "ok"


class StockMovement(TimeStamped):
    class Kind(models.TextChoices):
        OPENING = "opening", "Opening stock"
        STOCK_IN = "stock_in", "Stock in"
        SALE = "sale", "Sale"
        RETURN = "return", "Return"
        EXCHANGE = "exchange", "Exchange"
        ADJUST = "adjust", "Adjustment"
        CANCEL = "cancel", "Bill cancelled"

    variant = models.ForeignKey(Variant, on_delete=models.PROTECT, related_name="movements")
    qty = models.IntegerField(help_text="+ adds stock, − removes stock")
    kind = models.CharField(max_length=12, choices=Kind.choices)
    reference = models.CharField(max_length=60, blank=True, help_text="Bill no., import file, etc.")
    note = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.get_kind_display()} {self.qty:+d} · {self.variant}"


class BarcodeCounter(models.Model):
    """Single row that hands out the next barcode number."""

    next_value = models.PositiveBigIntegerField(default=settings.BARCODE_START)

    def __str__(self):
        return f"Next barcode: {self.next_value}"
