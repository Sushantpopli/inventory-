"""
Excel import for the catalog.

One row = one size of one product. Rows with the same Schools + Item + Season +
Gender + Detail are grouped into one product.

Columns (header names are matched loosely, order doesn't matter):
  Schools        short or full names, comma-separated. Empty or COMMON = common item
  Item           Shirt, Pant, Tie…   (new item types are created automatically)
  Season         Summer / Winter / All          (optional, default All)
  Gender         Boy / Girl / Unisex            (optional, default Unisex)
  Detail         e.g. Half sleeve               (optional)
  Size           30, 40-32, Free
  Selling price
  Cost price                                    (optional)
  Opening stock                                 (optional)
  Low stock alert                               (optional, default 3)

Always run with dry_run=True first: nothing is saved, and you get a summary + errors.
"""
from collections import OrderedDict
from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from io import BytesIO

from django.db import transaction
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation

from .models import Category, Product, School
from .services import add_sizes, find_same_product, normalise_size

HEADERS = {
    "schools": ["schools", "school", "school name"],
    "item": ["item", "category", "item type"],
    "season": ["season"],
    "gender": ["gender"],
    "detail": ["detail", "type / variant", "type", "variant", "name", "product"],
    "size": ["size"],
    "price": ["selling price", "selling price (₹)", "price", "mrp", "rate"],
    "cost": ["cost price", "cost price (₹)", "cost"],
    "stock": ["opening stock", "current stock", "current stock (qty)", "stock", "qty"],
    "low": ["low stock alert", "low stock", "alert"],
}
SEASONS = {"summer": "summer", "winter": "winter", "all": "all", "": "all", "all season": "all"}
GENDERS = {"boy": "boy", "boys": "boy", "girl": "girl", "girls": "girl", "unisex": "unisex",
           "all": "unisex", "": "unisex", "both": "unisex"}


@dataclass
class ImportResult:
    dry_run: bool
    rows_read: int = 0
    products_new: int = 0
    products_existing: int = 0
    sizes_new: int = 0
    sizes_skipped: int = 0
    units_opening: int = 0
    categories_new: list = field(default_factory=list)
    errors: list = field(default_factory=list)  # {"row": n, "message": "..."}

    @property
    def ok(self):
        return not self.errors

    def as_dict(self):
        return {**self.__dict__, "ok": self.ok}


def _map_headers(header_row):
    found = {}
    for idx, cell in enumerate(header_row):
        h = str(cell or "").strip().lower()
        for key, aliases in HEADERS.items():
            if h in aliases and key not in found:
                found[key] = idx
    return found


def _num(val, row, label, errors, required=False, integer=False):
    if val is None or str(val).strip() == "":
        if required:
            errors.append({"row": row, "message": f"{label} is missing"})
        return None
    try:
        d = Decimal(str(val).replace("₹", "").replace(",", "").strip())
    except InvalidOperation:
        errors.append({"row": row, "message": f"{label} '{val}' is not a number"})
        return None
    if d < 0:
        errors.append({"row": row, "message": f"{label} cannot be negative"})
        return None
    return int(d) if integer else d


def _find_header_row(ws):
    """Header may be on row 1 or row 2 (our template has a note on row 1)."""
    for r in (1, 2, 3):
        cols = _map_headers([c.value for c in ws[r]])
        if "item" in cols and "size" in cols:
            return r, cols
    return None, {}


def import_catalog(file_obj, dry_run=True, create_missing_schools=False) -> ImportResult:
    result = ImportResult(dry_run=dry_run)
    try:
        wb = load_workbook(file_obj, data_only=True, read_only=True)
    except Exception:
        result.errors.append({"row": 0, "message": "This is not a valid Excel (.xlsx) file"})
        return result
    ws = wb["Products"] if "Products" in wb.sheetnames else wb.worksheets[0]
    header_row, cols = _find_header_row(ws)
    if not header_row:
        result.errors.append({"row": 0, "message": "Could not find the header row. It needs at least 'Item' and 'Size' columns."})
        return result
    for need in ("price",):
        if need not in cols:
            result.errors.append({"row": header_row, "message": "Missing column: Selling price"})
            return result

    schools_by_key = {}
    for s in School.objects.all():
        schools_by_key[s.short_name.lower()] = s
        schools_by_key[s.name.lower()] = s
    categories = {c.name.lower(): c for c in Category.objects.all()}

    groups = OrderedDict()  # key -> dict(meta, rows)
    errors = result.errors
    get = lambda row, key: row[cols[key]] if key in cols and cols[key] < len(row) else None

    for r_idx, row in enumerate(ws.iter_rows(min_row=header_row + 1, values_only=True), start=header_row + 1):
        if not any(v not in (None, "") for v in row):
            continue
        result.rows_read += 1
        n_err = len(errors)
        item = str(get(row, "item") or "").strip()
        if not item:
            errors.append({"row": r_idx, "message": "Item is missing"})
        size_raw = get(row, "size")
        size = normalise_size(size_raw) if size_raw not in (None, "") else ""
        if not size:
            errors.append({"row": r_idx, "message": "Size is missing"})
        season = SEASONS.get(str(get(row, "season") or "").strip().lower())
        if season is None:
            errors.append({"row": r_idx, "message": f"Season '{get(row, 'season')}' should be Summer, Winter or All"})
        gender = GENDERS.get(str(get(row, "gender") or "").strip().lower())
        if gender is None:
            errors.append({"row": r_idx, "message": f"Gender '{get(row, 'gender')}' should be Boy, Girl or Unisex"})
        price = _num(get(row, "price"), r_idx, "Selling price", errors, required=True)
        cost = _num(get(row, "cost"), r_idx, "Cost price", errors)
        stock = _num(get(row, "stock"), r_idx, "Opening stock", errors, integer=True) or 0
        low = _num(get(row, "low"), r_idx, "Low stock alert", errors, integer=True)

        school_objs, school_names = [], []
        raw_schools = str(get(row, "schools") or "").strip()
        if raw_schools and raw_schools.upper() != "COMMON":
            for part in [p.strip() for p in raw_schools.split(",") if p.strip()]:
                s = schools_by_key.get(part.lower())
                if s:
                    school_objs.append(s)
                elif create_missing_schools:
                    school_names.append(part)
                else:
                    errors.append({"row": r_idx, "message": f"School '{part}' not found. Add it first, or tick 'create missing schools'."})
        if len(errors) > n_err:
            continue

        detail = str(get(row, "detail") or "").strip()
        key = (item.lower(), season, gender, detail.lower(),
               frozenset([s.pk for s in school_objs]) | frozenset(n.lower() for n in school_names))
        g = groups.setdefault(key, {"item": item, "season": season, "gender": gender, "detail": detail,
                                    "schools": school_objs, "new_schools": school_names, "rows": []})
        if any(x["size"] == size for x in g["rows"]):
            errors.append({"row": r_idx, "message": f"Size {size} appears twice for the same product"})
            continue
        g["rows"].append({"row": r_idx, "size": size, "price": price, "cost": cost, "stock": stock, "low": low})

    if errors:
        return result

    try:
        with transaction.atomic():
            for g in groups.values():
                cat = categories.get(g["item"].lower())
                if not cat:
                    cat = Category.objects.create(name=g["item"].title())
                    categories[g["item"].lower()] = cat
                    result.categories_new.append(cat.name)
                schools = list(g["schools"])
                for nm in g["new_schools"]:
                    s = schools_by_key.get(nm.lower())
                    if not s:
                        short = nm[:20].upper() if len(nm) <= 20 else nm.split()[0][:20].upper()
                        s = School.objects.create(name=nm, short_name=short)
                        schools_by_key[nm.lower()] = s
                    schools.append(s)
                product = find_same_product(cat, schools, g["season"], g["gender"], g["detail"])
                if product:
                    result.products_existing += 1
                else:
                    product = Product.objects.create(category=cat, season=g["season"], gender=g["gender"], name=g["detail"])
                    product.schools.set(schools)
                    result.products_new += 1
                existing = set(product.variants.values_list("size", flat=True))
                new_rows = [x for x in g["rows"] if x["size"] not in existing]
                result.sizes_skipped += len(g["rows"]) - len(new_rows)
                # one low-stock level per call; group rows by their level
                for low in {x["low"] for x in new_rows}:
                    part = [x for x in new_rows if x["low"] == low]
                    add_sizes(product, [x["size"] for x in part], [x["price"] for x in part],
                              [x["cost"] for x in part], low, [x["stock"] for x in part], reference="Excel import")
                result.sizes_new += len(new_rows)
                result.units_opening += sum(x["stock"] for x in new_rows)
            if dry_run:
                transaction.set_rollback(True)
    except ValueError as e:
        result.errors.append({"row": 0, "message": str(e)})
    return result


def build_template() -> bytes:
    """Excel template that matches import_catalog exactly."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Products"
    ws["A1"] = "One row per size. Grey rows are examples — replace them. Schools: short names, comma-separated; empty = COMMON."
    ws["A1"].font = Font(italic=True, color="56627A")
    headers = ["Schools", "Item", "Season", "Gender", "Detail", "Size", "Selling price",
               "Cost price", "Opening stock", "Low stock alert"]
    widths = [22, 14, 10, 10, 18, 9, 13, 11, 13, 14]
    fill = PatternFill("solid", fgColor="1F3A68")
    for i, (h, w) in enumerate(zip(headers, widths), start=1):
        c = ws.cell(row=2, column=i, value=h)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = fill
        ws.column_dimensions[c.column_letter].width = w
    examples = [
        ["DPS", "Shirt", "Summer", "Boy", "Half sleeve", "28", 240, 160, 12, 3],
        ["DPS", "Shirt", "Summer", "Boy", "Half sleeve", "30", 250, 168, 8, 3],
        ["DPS, JMS", "Tie", "All", "Unisex", "", "Free", 80, 40, 30, 5],
        ["", "Pant", "Summer", "Boy", "Grey", "40-32", 420, 290, 2, 1],
    ]
    for r, row in enumerate(examples, start=3):
        for c, v in enumerate(row, start=1):
            ws.cell(row=r, column=c, value=v).font = Font(italic=True, color="8A8F99")
    for col in "F":
        for r in range(3, 3000):
            ws[f"{col}{r}"].number_format = "@"  # keep 40-32 as text, not a date
    for formula, col in [('"Summer,Winter,All"', "C"), ('"Boy,Girl,Unisex"', "D")]:
        dv = DataValidation(type="list", formula1=formula, allow_blank=True)
        ws.add_data_validation(dv)
        dv.add(f"{col}3:{col}3000")
    ws.freeze_panes = "A3"
    buf = BytesIO()
    wb.save(buf)
    return buf.getvalue()
