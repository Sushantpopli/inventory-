"""
Business rules for the catalog. Views and the Excel importer call these;
nothing else should create variants or change stock directly.
"""
import re
from decimal import Decimal

from django.db import transaction
from django.db.models import F
from django.utils import timezone

from .models import BarcodeCounter, Product, StockMovement, Variant

# ---------------------------------------------------------------- sizes

LETTER_SIZES = ["XXS", "XS", "S", "M", "L", "XL", "XXL", "XXXL"]

SIZE_PRESETS = {
    "shirt": [str(n) for n in range(22, 46, 2)],
    "pant": [str(n) for n in range(22, 42, 2)] + ["40-32", "40-34", "40-36", "40-38"],
    "skirt": [str(n) for n in range(20, 36, 2)],
    "sweater": [str(n) for n in range(22, 42, 2)],
    "socks": [str(n) for n in range(3, 10)],
    "letters": ["S", "M", "L", "XL", "XXL"],
    "free": ["Free"],
}


def size_sort_key(size: str) -> int:
    """
    Order sizes the way a shopkeeper expects:
    numbers first (22, 24 … 40), then size-waist (40-32, 40-34),
    then letter sizes (S, M, L), then anything else (Free).
    """
    s = size.strip().upper()
    m = re.fullmatch(r"(\d+)\s*-\s*(\d+)", s)
    if m:
        return int(m.group(1)) * 1000 + int(m.group(2))
    if s.isdigit():
        return int(s) * 1000
    if s in LETTER_SIZES:
        return 900_000 + LETTER_SIZES.index(s)
    return 999_000


def normalise_size(size) -> str:
    s = str(size).strip()
    if isinstance(size, float) and size.is_integer():  # Excel gives 30.0
        s = str(int(size))
    s = re.sub(r"\s*-\s*", "-", s)  # "40 - 32" -> "40-32"
    if s.lower() == "free":
        return "Free"
    return s.upper() if s.isalpha() else s


def size_range(start: int, end: int, step: int = 2) -> list[str]:
    return [str(n) for n in range(start, end + 1, step)]


def ladder_prices(sizes, start_price, step):
    """Price ladder: first size costs start_price, each next size adds step."""
    start_price, step = Decimal(str(start_price)), Decimal(str(step or 0))
    return [start_price + step * i for i in range(len(sizes))]


# ---------------------------------------------------------------- barcodes

def next_barcodes(count: int) -> list[str]:
    """Reserve `count` new barcode numbers in one go (safe if two people save at once)."""
    with transaction.atomic():
        counter, _ = BarcodeCounter.objects.select_for_update().get_or_create(pk=1)
        first = counter.next_value
        # Skip any number already used (e.g. typed in by hand in the admin)
        used = set(
            Variant.objects.filter(barcode__in=[str(n) for n in range(first, first + count * 2)])
            .values_list("barcode", flat=True)
        )
        codes, n = [], first
        while len(codes) < count:
            if str(n) not in used:
                codes.append(str(n))
            n += 1
        counter.next_value = n
        counter.save(update_fields=["next_value"])
    return codes


# ---------------------------------------------------------------- stock

def record_movement(variant: Variant, qty: int, kind: str, reference: str = "", note: str = "") -> StockMovement:
    """The ONLY way stock changes. Saves the movement and updates the running total."""
    if qty == 0:
        raise ValueError("Quantity cannot be zero")
    with transaction.atomic():
        mv = StockMovement.objects.create(variant=variant, qty=qty, kind=kind, reference=reference, note=note)
        # bump updated_at too, so offline counters pick up the new stock on their next sync
        Variant.objects.filter(pk=variant.pk).update(stock=F("stock") + qty, updated_at=timezone.now())
    variant.refresh_from_db(fields=["stock"])
    return mv


# ---------------------------------------------------------------- products

def find_same_product(category, schools, season, gender, name) -> Product | None:
    """Same item type, season, gender, detail and exactly the same schools."""
    wanted = {s.pk for s in schools}
    qs = Product.objects.filter(category=category, season=season, gender=gender, name__iexact=name.strip())
    for p in qs.prefetch_related("schools"):
        if {s.pk for s in p.schools.all()} == wanted:
            return p
    return None


@transaction.atomic
def add_sizes(product: Product, sizes, prices, cost_prices=None, low_stock_level=None,
              opening_stock=None, reference="") -> list[Variant]:
    """
    Add sizes to a product. `prices`, `cost_prices` and `opening_stock` are lists in the
    same order as `sizes`. Sizes the product already has are skipped.
    """
    sizes = [normalise_size(s) for s in sizes]
    if len(set(sizes)) != len(sizes):
        raise ValueError("The same size is listed twice")
    existing = set(product.variants.values_list("size", flat=True))
    todo = [i for i, s in enumerate(sizes) if s not in existing]
    codes = next_barcodes(len(todo)) if todo else []
    created = []
    for code, i in zip(codes, todo):
        kwargs = {}
        if low_stock_level is not None:
            kwargs["low_stock_level"] = low_stock_level
        v = Variant.objects.create(
            product=product,
            size=sizes[i],
            sort_order=size_sort_key(sizes[i]),
            price=prices[i],
            cost_price=(cost_prices[i] if cost_prices else None),
            barcode=code,
            **kwargs,
        )
        qty = int(opening_stock[i] or 0) if opening_stock else 0
        if qty:
            record_movement(v, qty, StockMovement.Kind.OPENING, reference=reference)
        created.append(v)
    return created


@transaction.atomic
def create_product(*, category, schools, season, gender, name="", sizes, start_price, step=0,
                   cost_start=None, cost_step=0, low_stock_level=None, opening_stock=None) -> Product:
    """Create a product and all its sizes using the price ladder."""
    if not sizes:
        raise ValueError("Add at least one size")
    if find_same_product(category, schools, season, gender, name):
        raise ValueError("This product already exists for the same schools. Add sizes to it instead.")
    product = Product.objects.create(category=category, season=season, gender=gender, name=name.strip())
    product.schools.set(schools)
    prices = ladder_prices(sizes, start_price, step)
    costs = ladder_prices(sizes, cost_start, cost_step) if cost_start not in (None, "") else None
    add_sizes(product, sizes, prices, costs, low_stock_level, opening_stock)
    return product
