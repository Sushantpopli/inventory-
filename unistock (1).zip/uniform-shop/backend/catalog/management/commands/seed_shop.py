"""
python manage.py seed_shop           -> the 9 starting schools + item types (safe to run again)
python manage.py seed_shop --demo    -> also adds a few sample products with made-up prices and stock
"""
from django.core.management.base import BaseCommand

from catalog import services
from catalog.models import Category, Product, School

SCHOOLS = [
    ("Shree Kalidevi School", "SKD"),
    ("Krishna Pranami School", "KPS"),
    ("Bhagat Singh School", "BSS"),
    ("DPS", "DPS"),
    ("Baba Banda Bahadur School", "BBB"),
    ("GD Goenka", "GDG"),
    ("JMS", "JMS"),
    ("Aryan Public School", "APS"),
    ("Siddhartha Public School", "SPS"),
]

P = services.SIZE_PRESETS
CATEGORIES = [  # name, Hindi, default sizes
    ("Shirt", "शर्ट", P["shirt"]),
    ("Pant", "पैंट", P["pant"]),
    ("Skirt", "स्कर्ट", P["skirt"]),
    ("Divider", "डिवाइडर", P["skirt"]),
    ("Slacks", "स्लैक्स", P["pant"]),
    ("Leggings", "लेगिंग्स", P["skirt"]),
    ("Tunic", "ट्यूनिक", P["skirt"]),
    ("House T-shirt", "हाउस टी-शर्ट", P["shirt"]),
    ("Track suit", "ट्रैक सूट", P["shirt"]),
    ("Sweater", "स्वेटर", P["sweater"]),
    ("Blazer", "ब्लेज़र", P["sweater"]),
    ("Tie", "टाई", P["free"]),
    ("Belt", "बेल्ट", P["free"]),
    ("Socks", "मोज़े", P["socks"]),
    ("Shoes", "जूते", ["8C", "9C", "10C", "11C", "12C", "13C", "1", "2", "3", "4", "5", "6", "7", "8", "9"]),
    ("Bag", "बैग", P["free"]),
]


class Command(BaseCommand):
    help = "Create the starting schools and item types"

    def add_arguments(self, parser):
        parser.add_argument("--demo", action="store_true", help="Also add sample products (made-up prices)")

    def handle(self, *args, **opts):
        for name, short in SCHOOLS:
            School.objects.get_or_create(short_name=short, defaults={"name": name})
        for i, (name, hi, sizes) in enumerate(CATEGORIES):
            Category.objects.update_or_create(
                name=name, defaults={"name_hi": hi, "sort_order": (i + 1) * 10, "default_sizes": ",".join(sizes)}
            )
        self.stdout.write(self.style.SUCCESS(f"{len(SCHOOLS)} schools and {len(CATEGORIES)} item types ready"))

        if opts["demo"]:
            self._demo()

    def _demo(self):
        cat = {c.name: c for c in Category.objects.all()}
        dps, jms = School.objects.get(short_name="DPS"), School.objects.get(short_name="JMS")
        demo = [
            dict(category=cat["Shirt"], schools=[dps], season="summer", gender="boy", name="Half sleeve",
                 sizes=P["shirt"], start_price=200, step=10, cost_start=140, cost_step=7),
            dict(category=cat["Pant"], schools=[dps], season="summer", gender="boy", name="Grey",
                 sizes=P["pant"], start_price=260, step=15),
            dict(category=cat["Tie"], schools=[dps, jms], season="all", gender="unisex", name="",
                 sizes=["Free"], start_price=80),
            dict(category=cat["Shirt"], schools=[], season="summer", gender="unisex", name="Plain white",
                 sizes=P["shirt"], start_price=170, step=10),
        ]
        made = 0
        for d in demo:
            if services.find_same_product(d["category"], d["schools"], d["season"], d["gender"], d["name"]):
                continue
            d["opening_stock"] = [((i * 7) % 15) for i in range(len(d["sizes"]))]
            services.create_product(**d)
            made += 1
        self.stdout.write(self.style.SUCCESS(f"{made} demo products added ({Product.objects.count()} total)"))
