from django.db.models import Count, Q
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework import status, viewsets
from rest_framework.decorators import action, api_view, parser_classes, permission_classes

from accounts.permissions import IsOwner, OwnerCanChange
from rest_framework.parsers import FormParser, MultiPartParser
from rest_framework.response import Response

from . import services
from .importer import build_template, import_catalog
from .models import Category, Product, School, Variant
from .serializers import (AddSizesSerializer, CategorySerializer, ProductCreateSerializer, ProductSerializer,
                          SchoolSerializer, VariantSerializer, VariantWithProductSerializer)


class SchoolViewSet(viewsets.ModelViewSet):
    serializer_class = SchoolSerializer
    permission_classes = [OwnerCanChange]

    def get_queryset(self):
        qs = School.objects.annotate(product_count=Count("products", distinct=True)).order_by("name")
        q = self.request.query_params.get("q")
        if q:
            qs = qs.filter(Q(name__icontains=q) | Q(short_name__icontains=q))
        return qs

    def destroy(self, request, *args, **kwargs):
        school = self.get_object()
        if school.products.exists():
            return Response({"detail": "This school has products. Mark it inactive instead of deleting."},
                            status=status.HTTP_400_BAD_REQUEST)
        return super().destroy(request, *args, **kwargs)


class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [OwnerCanChange]
    pagination_class = None


class ProductViewSet(viewsets.ModelViewSet):
    """
    GET  /products/?school=<id>&include_common=1&category=<id>&season=summer&q=shirt
    POST /products/            create with price ladder (see ProductCreateSerializer)
    POST /products/<id>/add_sizes/
    """

    serializer_class = ProductSerializer
    permission_classes = [OwnerCanChange]
    http_method_names = ["get", "post", "patch", "delete", "head", "options"]

    def get_queryset(self):
        qs = Product.objects.select_related("category").prefetch_related("schools", "variants")
        p = self.request.query_params
        if p.get("school") == "common":
            qs = qs.filter(schools__isnull=True)
        elif p.get("school"):
            cond = Q(schools__id=p["school"])
            if p.get("include_common") == "1":
                cond |= Q(schools__isnull=True)
            qs = qs.filter(cond)
        if p.get("category"):
            qs = qs.filter(category_id=p["category"])
        if p.get("season"):
            qs = qs.filter(season=p["season"])
        if p.get("active", "1") == "1":
            qs = qs.filter(active=True)
        if p.get("q"):
            qs = qs.filter(Q(name__icontains=p["q"]) | Q(category__name__icontains=p["q"]))
        return qs.distinct()

    def create(self, request, *args, **kwargs):
        s = ProductCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        d = s.validated_data
        try:
            product = services.create_product(
                category=d["category"], schools=d.get("school_ids", []), season=d["season"], gender=d["gender"],
                name=d.get("name", ""), sizes=d["sizes"], start_price=d["start_price"], step=d["step"],
                cost_start=d.get("cost_start"), cost_step=d["cost_step"],
                low_stock_level=d.get("low_stock_level"), opening_stock=d.get("opening_stock"),
            )
        except ValueError as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(ProductSerializer(product).data, status=status.HTTP_201_CREATED)

    def destroy(self, request, *args, **kwargs):
        product = self.get_object()
        if any(v.movements.exists() for v in product.variants.all()):
            return Response({"detail": "This product has stock history. Mark it inactive instead of deleting."},
                            status=status.HTTP_400_BAD_REQUEST)
        return super().destroy(request, *args, **kwargs)

    @action(detail=True, methods=["post"])
    def add_sizes(self, request, pk=None):
        product = self.get_object()
        s = AddSizesSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        d = s.validated_data
        try:
            created = services.add_sizes(product, d["sizes"], d["prices"], d.get("cost_prices"),
                                         opening_stock=d.get("opening_stock"))
        except ValueError as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        return Response({"created": VariantSerializer(created, many=True).data,
                         "product": ProductSerializer(product).data})


class VariantViewSet(viewsets.ModelViewSet):
    """
    GET   /variants/?q=dps shirt 30     search by words (school, item, detail, size, barcode)
    GET   /variants/?low=1              low or out of stock
    GET   /variants/barcode/<code>/     exact barcode lookup (what the scanner sends)
    PATCH /variants/<id>/               change price, cost, low-stock level, active
    """

    serializer_class = VariantWithProductSerializer
    permission_classes = [OwnerCanChange]  # counter can search & scan, only owner changes prices
    http_method_names = ["get", "patch", "head", "options"]

    def get_queryset(self):
        qs = Variant.objects.select_related("product__category").prefetch_related("product__schools")
        p = self.request.query_params
        for w in (p.get("q") or "").split():
            cond = (Q(size__iexact=w) | Q(barcode=w) | Q(product__category__name__icontains=w)
                    | Q(product__category__name_hi__icontains=w) | Q(product__name__icontains=w)
                    | Q(product__schools__short_name__iexact=w) | Q(product__schools__name__icontains=w))
            if w.lower() == "common":
                cond |= Q(product__schools__isnull=True)
            qs = qs.filter(cond)
        if p.get("low") == "1":
            from django.db.models import F
            qs = qs.filter(stock__lte=F("low_stock_level"))
        if p.get("active", "1") == "1":
            qs = qs.filter(active=True, product__active=True)
        return qs.distinct().order_by("stock" if p.get("low") == "1" else "product__category__sort_order",
                                      "product_id", "sort_order")

    @action(detail=False, methods=["get"], url_path=r"barcode/(?P<code>[^/]+)")
    def by_barcode(self, request, code=None):
        v = get_object_or_404(self.get_queryset(), barcode=code.strip())
        return Response(self.get_serializer(v).data)


@api_view(["GET"])
def size_presets(request):
    return Response(services.SIZE_PRESETS)


@api_view(["POST"])
@permission_classes([IsOwner])
@parser_classes([MultiPartParser, FormParser])
def import_excel(request):
    """POST file=<xlsx>, dry_run=1|0, create_missing_schools=1|0"""
    f = request.FILES.get("file")
    if not f:
        return Response({"detail": "Choose an Excel file"}, status=status.HTTP_400_BAD_REQUEST)
    dry = request.data.get("dry_run", "1") in ("1", "true", "True")
    create = request.data.get("create_missing_schools", "0") in ("1", "true", "True")
    result = import_catalog(f, dry_run=dry, create_missing_schools=create)
    return Response(result.as_dict(), status=200 if result.ok else 400)


@api_view(["GET"])
@permission_classes([IsOwner])
def import_template(request):
    resp = HttpResponse(build_template(),
                        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    resp["Content-Disposition"] = 'attachment; filename="catalog_import_template.xlsx"'
    return resp
