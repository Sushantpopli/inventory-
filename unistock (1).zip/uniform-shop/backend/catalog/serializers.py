from rest_framework import serializers

from .models import Category, Product, School, StockMovement, Variant


class SchoolSerializer(serializers.ModelSerializer):
    product_count = serializers.IntegerField(read_only=True, required=False)

    class Meta:
        model = School
        fields = ["id", "name", "short_name", "active", "notes", "product_count"]


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ["id", "name", "name_hi", "sort_order", "default_sizes"]


class VariantSerializer(serializers.ModelSerializer):
    stock_status = serializers.CharField(read_only=True)

    class Meta:
        model = Variant
        fields = ["id", "size", "sort_order", "price", "cost_price", "barcode",
                  "low_stock_level", "stock", "stock_status", "active"]
        read_only_fields = ["size", "sort_order", "barcode", "stock"]


class VariantWithProductSerializer(VariantSerializer):
    """Used by search and barcode lookup: one row has everything the counter needs."""

    product_id = serializers.UUIDField(source="product.id", read_only=True)
    product_name = serializers.CharField(source="product.display_name", read_only=True)
    category = serializers.CharField(source="product.category.name", read_only=True)
    category_hi = serializers.CharField(source="product.category.name_hi", read_only=True)
    schools = serializers.SerializerMethodField()

    class Meta(VariantSerializer.Meta):
        fields = VariantSerializer.Meta.fields + ["product_id", "product_name", "category", "category_hi", "schools"]

    def get_schools(self, obj):
        return [s.short_name for s in obj.product.schools.all()]


class ProductSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source="category.name", read_only=True)
    school_ids = serializers.PrimaryKeyRelatedField(
        source="schools", many=True, queryset=School.objects.all(), required=False
    )
    school_names = serializers.SerializerMethodField()
    display_name = serializers.CharField(read_only=True)
    variants = VariantSerializer(many=True, read_only=True)

    class Meta:
        model = Product
        fields = ["id", "category", "category_name", "name", "season", "gender", "active",
                  "school_ids", "school_names", "display_name", "variants"]

    def get_school_names(self, obj):
        return [s.short_name for s in obj.schools.all()]


class ProductCreateSerializer(serializers.Serializer):
    """Create a product with all its sizes in one go, using the price ladder."""

    category = serializers.PrimaryKeyRelatedField(queryset=Category.objects.all())
    school_ids = serializers.PrimaryKeyRelatedField(queryset=School.objects.all(), many=True, required=False)
    name = serializers.CharField(required=False, allow_blank=True, default="")
    season = serializers.ChoiceField(choices=Product.Season.choices, default=Product.Season.ALL)
    gender = serializers.ChoiceField(choices=Product.Gender.choices, default=Product.Gender.UNISEX)
    sizes = serializers.ListField(child=serializers.CharField(max_length=20), min_length=1)
    start_price = serializers.DecimalField(max_digits=9, decimal_places=2, min_value=0)
    step = serializers.DecimalField(max_digits=9, decimal_places=2, default=0)
    cost_start = serializers.DecimalField(max_digits=9, decimal_places=2, required=False, allow_null=True, min_value=0)
    cost_step = serializers.DecimalField(max_digits=9, decimal_places=2, default=0)
    low_stock_level = serializers.IntegerField(required=False, min_value=0)
    opening_stock = serializers.ListField(child=serializers.IntegerField(min_value=0), required=False)

    def validate(self, data):
        if data.get("opening_stock") and len(data["opening_stock"]) != len(data["sizes"]):
            raise serializers.ValidationError("Opening stock needs one number per size")
        return data


class AddSizesSerializer(serializers.Serializer):
    sizes = serializers.ListField(child=serializers.CharField(max_length=20), min_length=1)
    prices = serializers.ListField(child=serializers.DecimalField(max_digits=9, decimal_places=2, min_value=0))
    cost_prices = serializers.ListField(
        child=serializers.DecimalField(max_digits=9, decimal_places=2, min_value=0, allow_null=True), required=False
    )
    opening_stock = serializers.ListField(child=serializers.IntegerField(min_value=0), required=False)

    def validate(self, data):
        n = len(data["sizes"])
        for key in ("prices", "cost_prices", "opening_stock"):
            if data.get(key) is not None and len(data[key]) != n:
                raise serializers.ValidationError(f"{key} needs one value per size")
        return data


class StockMovementSerializer(serializers.ModelSerializer):
    class Meta:
        model = StockMovement
        fields = ["id", "variant", "qty", "kind", "reference", "note", "created_at"]
