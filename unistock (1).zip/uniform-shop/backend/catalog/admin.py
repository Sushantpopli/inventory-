from django.contrib import admin

from .models import BarcodeCounter, Category, Product, School, StockMovement, Variant


@admin.register(School)
class SchoolAdmin(admin.ModelAdmin):
    list_display = ["name", "short_name", "active"]
    list_filter = ["active"]
    search_fields = ["name", "short_name"]


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ["name", "name_hi", "sort_order", "default_sizes"]
    list_editable = ["sort_order"]


class VariantInline(admin.TabularInline):
    model = Variant
    extra = 0
    fields = ["size", "price", "cost_price", "barcode", "low_stock_level", "stock", "active"]
    readonly_fields = ["barcode", "stock"]


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ["__str__", "category", "season", "gender", "active"]
    list_filter = ["category", "season", "gender", "active", "schools"]
    search_fields = ["name", "category__name", "schools__name", "schools__short_name"]
    filter_horizontal = ["schools"]
    inlines = [VariantInline]


@admin.register(Variant)
class VariantAdmin(admin.ModelAdmin):
    list_display = ["__str__", "barcode", "price", "stock", "low_stock_level"]
    search_fields = ["barcode", "size", "product__category__name", "product__schools__short_name"]
    readonly_fields = ["stock"]


@admin.register(StockMovement)
class StockMovementAdmin(admin.ModelAdmin):
    list_display = ["created_at", "variant", "kind", "qty", "reference"]
    list_filter = ["kind"]
    search_fields = ["variant__barcode", "reference"]

    def has_change_permission(self, request, obj=None):
        return False  # movements are history; fix mistakes with an Adjustment

    def has_delete_permission(self, request, obj=None):
        return False


admin.site.register(BarcodeCounter)
