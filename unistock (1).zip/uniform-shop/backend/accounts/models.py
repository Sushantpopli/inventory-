"""
Staff and roles.

  owner    everything: prices, reports & profit, settings, staff, cancelling any bill
  counter  billing, returns, stock in, labels, low-stock list; can cancel only today's bills

People log in by tapping their name and typing a 4–6 digit PIN (stored hashed, like a password).
"""
from django.conf import settings
from django.db import models


class StaffProfile(models.Model):
    class Role(models.TextChoices):
        OWNER = "owner", "Owner"
        COUNTER = "counter", "Counter staff"

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="staff")
    display_name = models.CharField(max_length=40, help_text="Shown on the login screen")
    role = models.CharField(max_length=10, choices=Role.choices, default=Role.COUNTER)

    class Meta:
        ordering = ["display_name"]

    def __str__(self):
        return f"{self.display_name} ({self.get_role_display()})"

    @property
    def is_owner(self):
        return self.role == self.Role.OWNER


def role_of(user) -> str | None:
    if not user or not user.is_authenticated:
        return None
    if user.is_superuser:
        return StaffProfile.Role.OWNER
    profile = getattr(user, "staff", None)
    return profile.role if profile else None
