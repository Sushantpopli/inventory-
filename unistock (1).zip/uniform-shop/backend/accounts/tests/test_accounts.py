import uuid
from datetime import timedelta
from io import StringIO

from django.core.management import call_command
from unittest.mock import patch

from django.test import TestCase
from rest_framework.throttling import ScopedRateThrottle
from django.utils import timezone
from rest_framework.test import APIClient

from accounts.models import StaffProfile
from catalog import services as catalog
from catalog.models import Category
from config.testing import counter_client, owner_client


class Login(TestCase):
    def setUp(self):
        call_command("create_owner", name="Papa", pin="1234", stdout=StringIO())
        self.c = APIClient()

    def owner_id(self):
        return self.c.get("/api/auth/people/").data[0]["id"]

    def test_people_list_needs_no_login_and_shows_no_pins(self):
        res = self.c.get("/api/auth/people/")
        self.assertEqual(res.data, [{"id": res.data[0]["id"], "name": "Papa", "role": "owner"}])

    def test_login_with_pin_then_use_token(self):
        res = self.c.post("/api/auth/login/", {"user_id": self.owner_id(), "pin": "1234"}, format="json")
        self.assertEqual(res.status_code, 200)
        self.assertEqual(res.data["user"]["role"], "owner")
        self.assertEqual(self.c.get("/api/billing/snapshot/").status_code, 401)
        self.c.credentials(HTTP_AUTHORIZATION="Token " + res.data["token"])
        self.assertEqual(self.c.get("/api/auth/me/").data["name"], "Papa")
        self.assertEqual(self.c.get("/api/billing/snapshot/").status_code, 200)
        self.c.post("/api/auth/logout/")
        self.assertEqual(self.c.get("/api/auth/me/").status_code, 401)

    def test_wrong_pin(self):
        res = self.c.post("/api/auth/login/", {"user_id": self.owner_id(), "pin": "9999"}, format="json")
        self.assertEqual((res.status_code, res.data["detail"]), (400, "Wrong PIN. Try again."))

    @patch.object(ScopedRateThrottle, "THROTTLE_RATES", {"login": "3/min"})
    def test_too_many_tries_are_blocked(self):
        from django.core.cache import cache
        cache.clear()
        uid = self.owner_id()
        codes = [self.c.post("/api/auth/login/", {"user_id": uid, "pin": "0000"}, format="json").status_code for _ in range(4)]
        self.assertEqual(codes, [400, 400, 400, 429])
        cache.clear()

    def test_pin_rules(self):
        with self.assertRaises(Exception):
            call_command("create_owner", name="X", pin="12", stdout=StringIO())


class Staff(TestCase):
    def setUp(self):
        self.owner = owner_client()

    def test_owner_adds_counter_person_who_can_log_in(self):
        res = self.owner.post("/api/auth/staff/", {"display_name": "Ramesh", "role": "counter", "pin": "4321"}, format="json")
        self.assertEqual(res.status_code, 201, res.data)
        anon = APIClient()
        login = anon.post("/api/auth/login/", {"user_id": res.data["id"], "pin": "4321"}, format="json")
        self.assertEqual(login.data["user"], {"id": res.data["id"], "name": "Ramesh", "role": "counter"})

    def test_new_pin_and_disable_end_old_logins(self):
        uid = self.owner.post("/api/auth/staff/", {"display_name": "Ramesh", "role": "counter", "pin": "4321"}, format="json").data["id"]
        anon = APIClient()
        token = anon.post("/api/auth/login/", {"user_id": uid, "pin": "4321"}, format="json").data["token"]
        self.owner.patch(f"/api/auth/staff/{uid}/", {"pin": "5555"}, format="json")
        anon.credentials(HTTP_AUTHORIZATION="Token " + token)
        self.assertEqual(anon.get("/api/auth/me/").status_code, 401)
        self.owner.patch(f"/api/auth/staff/{uid}/", {"active": False}, format="json")
        self.assertEqual(APIClient().post("/api/auth/login/", {"user_id": uid, "pin": "5555"}, format="json").status_code, 400)
        self.assertNotIn(uid, [p["id"] for p in APIClient().get("/api/auth/people/").data])

    def test_bad_pin_rejected(self):
        res = self.owner.post("/api/auth/staff/", {"display_name": "A", "role": "counter", "pin": "12ab"}, format="json")
        self.assertEqual(res.status_code, 400)

    def test_last_owner_cannot_be_removed(self):
        uid = self.owner.user.pk
        res = self.owner.patch(f"/api/auth/staff/{uid}/", {"role": "counter"}, format="json")
        self.assertEqual(res.status_code, 400)
        self.assertEqual(StaffProfile.objects.get(user_id=uid).role, "owner")

    def test_counter_cannot_manage_staff(self):
        self.assertEqual(counter_client().get("/api/auth/staff/").status_code, 403)


class WhoCanDoWhat(TestCase):
    """The counter can sell, return, receive stock, print labels and see low stock — nothing more."""

    def setUp(self):
        call_command("seed_shop", stdout=StringIO())
        self.owner, self.counter = owner_client(), counter_client()
        self.p = catalog.create_product(category=Category.objects.get(name="Tie"), schools=[], season="all",
                                        gender="unisex", sizes=["Free"], start_price=80, opening_stock=[10])
        self.v = self.p.variants.get()

    def bill(self, days_ago=0):
        body = {"id": str(uuid.uuid4()), "number": 1 + days_ago,
                "created_at": (timezone.now() - timedelta(days=days_ago)).isoformat(),
                "cash_amount": 80, "lines": [{"variant": str(self.v.id), "qty": 1, "price": "80"}]}
        self.counter.post("/api/billing/sync/", {"bills": [body]}, format="json")
        return body["id"]

    def test_counter_allowed(self):
        c = self.counter
        self.assertEqual(c.get("/api/billing/snapshot/").status_code, 200)
        self.assertEqual(c.get(f"/api/catalog/variants/barcode/{self.v.barcode}/").status_code, 200)
        self.assertEqual(c.get("/api/catalog/products/").status_code, 200)
        self.assertEqual(c.post("/api/labels/queue/", {"variant": str(self.v.id)}, format="json").status_code, 201)
        self.assertEqual(c.post("/api/stock/entries/", {"lines": [{"variant": str(self.v.id), "qty": 2}]}, format="json").status_code, 201)
        self.assertEqual(c.get("/api/reports/low-stock/").status_code, 200)
        self.assertEqual(c.post(f"/api/billing/bills/{self.bill()}/cancel/", {"reason": "wrong"}, format="json").status_code, 200)

    def test_counter_blocked(self):
        c = self.counter
        blocked = [
            c.patch(f"/api/catalog/variants/{self.v.id}/", {"price": "1"}, format="json"),
            c.post("/api/catalog/schools/", {"name": "X", "short_name": "X"}, format="json"),
            c.patch("/api/billing/settings/", {"firm_name": "X"}, format="json"),
            c.get("/api/reports/summary/"),
            c.get("/api/reports/sales.xlsx"),
            c.post("/api/stock/correct/", {"variant": str(self.v.id), "counted": 0}, format="json"),
            c.post(f"/api/billing/bills/{self.bill(days_ago=2)}/cancel/", {"reason": "x"}, format="json"),
        ]
        self.assertEqual([r.status_code for r in blocked], [403] * len(blocked))

    def test_owner_can_cancel_old_bill(self):
        res = self.owner.post(f"/api/billing/bills/{self.bill(days_ago=2)}/cancel/", {"reason": "x"}, format="json")
        self.assertEqual(res.status_code, 200)

    def test_nobody_without_login(self):
        anon = APIClient()
        self.assertEqual(anon.get("/api/catalog/products/").status_code, 401)
        self.assertEqual(anon.post("/api/billing/sync/", {"bills": []}, format="json").status_code, 401)
