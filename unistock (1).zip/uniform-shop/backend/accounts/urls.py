from django.urls import include, path
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register("staff", views.StaffViewSet, basename="staff")

urlpatterns = [
    path("people/", views.people),
    path("login/", views.login),
    path("logout/", views.logout),
    path("me/", views.me),
    path("", include(router.urls)),
]
