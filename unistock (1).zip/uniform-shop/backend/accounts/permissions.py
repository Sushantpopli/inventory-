"""Who may do what. Every API view uses one of these (default: IsStaff)."""
from rest_framework.permissions import SAFE_METHODS, BasePermission

from .models import StaffProfile, role_of


class IsStaff(BasePermission):
    """Any logged-in shop person (owner or counter)."""

    message = "Please log in."

    def has_permission(self, request, view):
        return role_of(request.user) is not None


class IsOwner(BasePermission):
    message = "Only the owner can do this."

    def has_permission(self, request, view):
        return role_of(request.user) == StaffProfile.Role.OWNER


class OwnerCanChange(BasePermission):
    """Everyone can look; only the owner can add, change or delete."""

    message = "Only the owner can change this."

    def has_permission(self, request, view):
        role = role_of(request.user)
        if role is None:
            return False
        return request.method in SAFE_METHODS or role == StaffProfile.Role.OWNER


def is_owner(user) -> bool:
    return role_of(user) == StaffProfile.Role.OWNER
