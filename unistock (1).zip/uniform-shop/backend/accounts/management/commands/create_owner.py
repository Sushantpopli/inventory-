"""
First-time setup: python manage.py create_owner --name "Papa" --pin 1234
After this, the owner adds counter staff from the Staff screen.
"""
from django.core.management.base import BaseCommand, CommandError

from accounts.models import StaffProfile
from accounts.views import PIN, User, _free_username


class Command(BaseCommand):
    help = "Create an owner who can log in with a PIN"

    def add_arguments(self, parser):
        parser.add_argument("--name", required=True)
        parser.add_argument("--pin", required=True)

    def handle(self, *args, name, pin, **opts):
        if not PIN.match(pin):
            raise CommandError("PIN must be 4 to 6 digits")
        user = User.objects.create_user(username=_free_username(name), password=pin)
        StaffProfile.objects.create(user=user, display_name=name, role=StaffProfile.Role.OWNER)
        self.stdout.write(self.style.SUCCESS(f"Owner '{name}' created. Log in with the PIN."))
