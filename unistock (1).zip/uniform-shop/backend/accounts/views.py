"""
Login API

GET  /api/auth/people/        names on the login screen (no login needed)
POST /api/auth/login/         {user_id, pin} -> {token, user}   (limited to 10 tries a minute)
POST /api/auth/logout/
GET  /api/auth/me/
Owner only:
GET/POST   /api/auth/staff/          list / add a person {display_name, role, pin}
PATCH      /api/auth/staff/<id>/     {display_name?, role?, pin?, active?}
"""
import re

from django.contrib.auth import get_user_model
from django.db import transaction
from rest_framework import serializers, status, viewsets
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, permission_classes, throttle_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.throttling import ScopedRateThrottle

from .models import StaffProfile, role_of
from .permissions import IsOwner, IsStaff

User = get_user_model()
PIN = re.compile(r"^\d{4,6}$")


def user_info(user):
    p = getattr(user, "staff", None)
    return {"id": user.pk, "name": p.display_name if p else user.get_username(), "role": role_of(user)}


@api_view(["GET"])
@permission_classes([AllowAny])
def people(request):
    rows = StaffProfile.objects.filter(user__is_active=True).select_related("user")
    return Response([{"id": p.user_id, "name": p.display_name, "role": p.role} for p in rows])


class LoginThrottle(ScopedRateThrottle):
    scope_attr = "throttle_scope"


@api_view(["POST"])
@permission_classes([AllowAny])
@throttle_classes([LoginThrottle])
def login(request):
    user = User.objects.filter(pk=request.data.get("user_id"), is_active=True).first()
    pin = str(request.data.get("pin", ""))
    if not user or not hasattr(user, "staff") or not user.check_password(pin):
        return Response({"detail": "Wrong PIN. Try again."}, status=status.HTTP_400_BAD_REQUEST)
    token, _ = Token.objects.get_or_create(user=user)
    return Response({"token": token.key, "user": user_info(user)})


login.cls.throttle_scope = "login"


@api_view(["POST"])
@permission_classes([IsStaff])
def logout(request):
    Token.objects.filter(user=request.user).delete()
    return Response({"ok": True})


@api_view(["GET"])
@permission_classes([IsStaff])
def me(request):
    return Response(user_info(request.user))


class StaffSerializer(serializers.Serializer):
    id = serializers.IntegerField(source="user_id", read_only=True)
    display_name = serializers.CharField(max_length=40)
    role = serializers.ChoiceField(choices=StaffProfile.Role.choices)
    active = serializers.BooleanField(source="user.is_active", required=False)
    pin = serializers.CharField(write_only=True, required=False)

    def validate_pin(self, v):
        if not PIN.match(v):
            raise serializers.ValidationError("PIN must be 4 to 6 digits")
        return v


class StaffViewSet(viewsets.ViewSet):
    permission_classes = [IsOwner]

    def list(self, request):
        rows = StaffProfile.objects.select_related("user").order_by("-user__is_active", "display_name")
        return Response(StaffSerializer(rows, many=True).data)

    @transaction.atomic
    def create(self, request):
        s = StaffSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        if "pin" not in s.validated_data:
            return Response({"pin": ["Set a PIN"]}, status=400)
        user = User.objects.create_user(username=_free_username(s.validated_data["display_name"]),
                                        password=s.validated_data["pin"])
        p = StaffProfile.objects.create(user=user, display_name=s.validated_data["display_name"],
                                        role=s.validated_data["role"])
        return Response(StaffSerializer(p).data, status=201)

    @transaction.atomic
    def partial_update(self, request, pk=None):
        p = StaffProfile.objects.select_related("user").filter(user_id=pk).first()
        if not p:
            return Response({"detail": "Not found"}, status=404)
        s = StaffSerializer(p, data=request.data, partial=True)
        s.is_valid(raise_exception=True)
        d = s.validated_data
        becomes_non_owner = d.get("role", p.role) != StaffProfile.Role.OWNER or d.get("user", {}).get("is_active") is False
        if p.is_owner and becomes_non_owner and not StaffProfile.objects.filter(
                role=StaffProfile.Role.OWNER, user__is_active=True).exclude(pk=p.pk).exists():
            return Response({"detail": "Keep at least one active owner."}, status=400)
        for k in ("display_name", "role"):
            if k in d:
                setattr(p, k, d[k])
        p.save()
        if "pin" in d:
            p.user.set_password(d["pin"])
            Token.objects.filter(user=p.user).delete()  # old logins stop working
        if "user" in d and "is_active" in d["user"]:
            p.user.is_active = d["user"]["is_active"]
            if not p.user.is_active:
                Token.objects.filter(user=p.user).delete()
        p.user.save()
        return Response(StaffSerializer(p).data)


def _free_username(name):
    base = re.sub(r"[^a-z0-9]+", "", name.lower())[:20] or "staff"
    n, candidate = 1, base
    while User.objects.filter(username=candidate).exists():
        n += 1
        candidate = f"{base}{n}"
    return candidate
