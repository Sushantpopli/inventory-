"""
Reports: everything is calculated from bills (Bill / BillLine) and stock, never stored twice.

Words used on screen:
  Sales    = new items sold, after discount
  Returns  = value of items given back
  Net      = Sales - Returns  (= money that actually stayed with the shop)
  Profit   = Net - cost of those pieces (uses each size's current cost price;
             pieces with no cost price are left out and counted separately)
Cancelled bills are ignored everywhere.
"""
from datetime import date, datetime, time, timedelta
from decimal import Decimal

from django.db.models import Count, F, Q, Sum
from django.db.models.functions import TruncDate
from django.utils import timezone

from billing.models import Bill, BillLine
from catalog.models import Variant

ZERO = Decimal(0)


def day_range(start: date, end: date):
    tz = timezone.get_current_timezone()
    return (timezone.make_aware(datetime.combine(start, time.min), tz),
            timezone.make_aware(datetime.combine(end + timedelta(days=1), time.min), tz))


def bills_between(start: date, end: date):
    a, b = day_range(start, end)
    return Bill.objects.filter(status=Bill.Status.DONE, created_at__gte=a, created_at__lt=b)


def lines_between(start: date, end: date):
    a, b = day_range(start, end)
    return BillLine.objects.filter(bill__status=Bill.Status.DONE, bill__created_at__gte=a, bill__created_at__lt=b)


def summary(start: date, end: date) -> dict:
    bills = bills_between(start, end)
    lines = lines_between(start, end)
    agg = bills.aggregate(
        net=Sum("total"), discount=Sum("discount"), cash=Sum("cash_amount"), upi=Sum("upi_amount"),
        credit_used=Sum("credit_used"), credit_issued=Sum("credit_issued"))
    la = lines.aggregate(
        sold_amt=Sum("amount", filter=Q(qty__gt=0)), ret_amt=Sum("amount", filter=Q(qty__lt=0)),
        sold_qty=Sum("qty", filter=Q(qty__gt=0)), ret_qty=Sum("qty", filter=Q(qty__lt=0)),
        sale_bills=Count("bill", filter=Q(qty__gt=0), distinct=True),
        return_bills=Count("bill", filter=Q(qty__lt=0), distinct=True),
        cost=Sum(F("qty") * F("variant__cost_price"), filter=Q(variant__cost_price__isnull=False)),
        costed_amt=Sum("amount", filter=Q(variant__cost_price__isnull=False)),
        costed_sold=Sum("amount", filter=Q(variant__cost_price__isnull=False, qty__gt=0)),
        no_cost_qty=Sum("qty", filter=Q(variant__cost_price__isnull=True)),
    )
    v = lambda x: x or ZERO
    sales = v(la["sold_amt"]) - v(agg["discount"])
    returns = -v(la["ret_amt"])
    net = v(agg["net"])
    cost = v(la["cost"])
    # Profit only over pieces that have a cost price; they carry their share of the discount.
    profit = None
    if la["cost"] is not None:
        share = (v(la["costed_sold"]) / v(la["sold_amt"])) if la["sold_amt"] else ZERO
        profit = (v(la["costed_amt"]) - v(agg["discount"]) * share - cost).quantize(Decimal("0.01"))
    return {
        "from": start.isoformat(), "to": end.isoformat(),
        "sales": sales, "returns": returns, "net": net, "discount": v(agg["discount"]),
        "bills": la["sale_bills"] or 0, "return_bills": la["return_bills"] or 0,
        "pieces_sold": la["sold_qty"] or 0, "pieces_returned": -(la["ret_qty"] or 0),
        "cash": v(agg["cash"]), "upi": v(agg["upi"]),
        "credit_used": v(agg["credit_used"]), "credit_issued": v(agg["credit_issued"]),
        "cost": cost, "profit": profit,
        "pieces_without_cost": la["no_cost_qty"] or 0,
    }


def by_day(start: date, end: date) -> list[dict]:
    tz = timezone.get_current_timezone()
    rows = (bills_between(start, end).annotate(day=TruncDate("created_at", tzinfo=tz)).values("day")
            .annotate(net=Sum("total"), cash=Sum("cash_amount"), upi=Sum("upi_amount")).order_by("day"))
    found = {r["day"]: r for r in rows}
    # "bills" = sale bills (same meaning as the summary); counted separately so sums aren't doubled
    counts = dict(lines_between(start, end).filter(qty__gt=0)
                  .annotate(day=TruncDate("bill__created_at", tzinfo=tz)).values("day")
                  .annotate(n=Count("bill", distinct=True)).values_list("day", "n"))
    for d, n in counts.items():
        found.setdefault(d, {})["bills"] = n
    out, d = [], start
    while d <= end:  # every day appears, even with no sales, so the chart has no gaps
        r = found.get(d, {})
        out.append({"day": d.isoformat(), "net": r.get("net") or ZERO, "bills": r.get("bills") or 0,
                    "cash": r.get("cash") or ZERO, "upi": r.get("upi") or ZERO})
        d += timedelta(days=1)
    return out


def last_year(d: date) -> date:
    try:
        return d.replace(year=d.year - 1)
    except ValueError:  # 29 Feb
        return d.replace(year=d.year - 1, day=28)


GROUPS = {
    "size": ["variant__product_id", "variant__product__category__name", "variant__product__name", "variant__size", "variant_id"],
    "product": ["variant__product_id", "variant__product__category__name", "variant__product__name"],
    "category": ["variant__product__category__name"],
}


def top_items(start: date, end: date, by: str = "size", limit: int = 20) -> list[dict]:
    """Net pieces and money per size / product / item type / school (returns subtract)."""
    if by == "school":
        return _top_by_school(start, end, limit)
    rows = list(lines_between(start, end).values(*GROUPS[by])
                .annotate(qty=Sum("qty"), amount=Sum("amount")).order_by("-qty", "-amount")[:limit])
    labels = _product_labels({r.get("variant__product_id") for r in rows})
    out = []
    for r in rows:
        parts = [labels.get(r.get("variant__product_id"), ""), r["variant__product__category__name"],
                 r.get("variant__product__name") or ""]
        out.append({"name": " ".join(x for x in parts if x), "size": r.get("variant__size"),
                    "qty": r["qty"], "amount": r["amount"]})
    return out


def _product_labels(ids):
    from catalog.models import Product
    return {p.pk: p.school_label() for p in Product.objects.filter(pk__in=[i for i in ids if i])
            .prefetch_related("schools")}


def _top_by_school(start, end, limit):
    """A product made for several schools is shown under that group of schools (e.g. "DPS, JMS")."""
    rows = lines_between(start, end).values("variant__product_id").annotate(qty=Sum("qty"), amount=Sum("amount"))
    labels = _product_labels({r["variant__product_id"] for r in rows})
    groups = {}
    for r in rows:
        g = groups.setdefault(labels.get(r["variant__product_id"], "?"), {"qty": 0, "amount": ZERO})
        g["qty"] += r["qty"]
        g["amount"] += r["amount"]
    out = [{"name": k, "size": None, **g} for k, g in groups.items()]
    return sorted(out, key=lambda x: (-x["qty"], -x["amount"]))[:limit]


def low_stock(school_id=None, days=30) -> list[dict]:
    """
    Sizes at or below their warning level, grouped by product, with a suggested order:
    enough to cover the last `days` days of sales, and at least twice the warning level.
    """
    qs = (Variant.objects.filter(active=True, product__active=True, stock__lte=F("low_stock_level"))
          .select_related("product__category").prefetch_related("product__schools")
          .order_by("product__category__sort_order", "product_id", "sort_order"))
    if school_id == "common":
        qs = qs.filter(product__schools__isnull=True)
    elif school_id:
        qs = qs.filter(product__schools__id=school_id)
    since = timezone.now() - timedelta(days=days)
    sold = dict(BillLine.objects.filter(variant__in=qs, bill__status=Bill.Status.DONE, bill__created_at__gte=since)
                .values("variant_id").annotate(n=Sum("qty")).values_list("variant_id", "n"))
    groups = {}
    for v in qs:
        p = v.product
        g = groups.setdefault(p.pk, {"product": p.display_name(), "schools": p.school_label(),
                                     "category": p.category.name, "detail": p.name, "season": p.season,
                                     "gender": p.gender, "sizes": []})
        recent = max(sold.get(v.pk, 0), 0)
        g["sizes"].append({"variant": str(v.pk), "size": v.size, "stock": v.stock, "alert_at": v.low_stock_level,
                           "sold_recently": recent,
                           "suggest": max(max(recent, 2 * v.low_stock_level) - v.stock, 1)})
    return list(groups.values())
