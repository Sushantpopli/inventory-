import uuid
from datetime import timedelta
from io import BytesIO

from django.utils import timezone
from openpyxl import load_workbook

from billing.tests.test_billing import Base


class Reports(Base):
    """Shirt 28/30 @240/250 (cost unknown), Tie @80. Stock: 28→5, 30→2, tie→10."""

    def setUp(self):
        super().setUp()
        self.today = timezone.localdate()
        self.s28.cost_price = 160
        self.s28.save()

    def sell(self, number, lines, days_ago=0, **pay):
        total = sum(float(l["price"]) * l["qty"] for l in lines) - float(pay.get("discount", 0))
        body = {"id": str(uuid.uuid4()), "number": number,
                "created_at": (timezone.now() - timedelta(days=days_ago)).isoformat(),
                "cash_amount": total, "upi_amount": 0, "lines": lines}
        body.update(pay)
        r = self.sync(body).data["results"][0]
        assert r["status"] == "created", r
        return body

    def line(self, v, qty, price, **kw):
        return {"variant": str(v.id), "qty": qty, "price": str(price), "client_id": str(uuid.uuid4()), **kw}

    def test_summary_today(self):
        sale = self.sell(1, [self.line(self.s28, 2, 240), self.line(self.tie_v, 1, 80)], discount="20")
        self.sell(2, [self.line(self.s30, 1, 250)], cash_amount=0, upi_amount=250)
        self.sell(3, [self.line(self.s28, -1, 230, returned_from=sale["lines"][0]["client_id"])], cash_amount=-230, upi_amount=0)
        cancelled = self.sell(4, [self.line(self.tie_v, 1, 80)])
        self.c.post(f"/api/billing/bills/{cancelled['id']}/cancel/", {"reason": "x"}, format="json")

        s = self.c.get("/api/reports/summary/").data
        self.assertEqual(float(s["sales"]), 480 + 80 - 20 + 250)
        self.assertEqual(float(s["returns"]), 230)
        self.assertEqual(float(s["net"]), 790 - 230)
        self.assertEqual((s["bills"], s["return_bills"], s["pieces_sold"], s["pieces_returned"]), (2, 1, 4, 1))
        self.assertEqual((float(s["cash"]), float(s["upi"])), (540 - 230, 250))
        # cost known only for size 28: (2 - 1) × 160
        self.assertEqual(float(s["cost"]), 160)
        # profit only on size 28: sold 2×240, returned 1×230 → 250 money kept, minus its discount
        # share (480 of 810 sold × 20 = 11.85), minus cost 160
        self.assertEqual(float(s["profit"]), round(250 - 20 * 480 / 810 - 160, 2))
        self.assertEqual(s["pieces_without_cost"], 2)  # tie + size 30
        self.assertEqual(len(s["days"]), 1)
        self.assertEqual(float(s["days"][0]["net"]), 560)

    def test_range_has_every_day_and_last_year(self):
        self.sell(1, [self.line(self.tie_v, 1, 80)], days_ago=2)
        start = (self.today - timedelta(days=3)).isoformat()
        s = self.c.get("/api/reports/summary/", {"from": start, "to": self.today.isoformat()}).data
        self.assertEqual(len(s["days"]), 4)
        self.assertEqual([float(d["net"]) for d in s["days"]].count(80), 1)
        self.assertEqual(float(s["last_year"]["net"]), 0)

    def test_top_items_net_of_returns(self):
        sale = self.sell(1, [self.line(self.s28, 3, 240), self.line(self.tie_v, 1, 80)])
        self.sell(2, [self.line(self.s28, -2, 240, returned_from=sale["lines"][0]["client_id"])], cash_amount=-480)
        rows = self.c.get("/api/reports/top/", {"by": "size"}).data["rows"]
        self.assertEqual([(r["name"], r["size"], r["qty"]) for r in rows],
                         [("DPS Shirt Half sleeve", "28", 1), ("Common Tie", "Free", 1)])
        by_school = self.c.get("/api/reports/top/", {"by": "school"}).data["rows"]
        self.assertEqual({r["name"]: r["qty"] for r in by_school}, {"DPS": 1, "Common": 1})
        self.assertEqual(self.c.get("/api/reports/top/", {"by": "x"}).status_code, 400)

    def test_low_stock_with_suggestion(self):
        # size 30 has 2 (alert at 3); sell 1 → 1 left; last 30 days sold 1
        self.sell(1, [self.line(self.s30, 1, 250)])
        groups = self.c.get("/api/reports/low-stock/").data["groups"]
        self.assertEqual(len(groups), 1)
        size = groups[0]["sizes"][0]
        self.assertEqual((size["size"], size["stock"], size["sold_recently"], size["suggest"]), ("30", 1, 1, 5))
        self.assertEqual(self.c.get("/api/reports/low-stock/", {"school": "common"}).data["groups"], [])

    def test_excel_downloads(self):
        self.sell(1, [self.line(self.s28, 1, 240)])
        wb = load_workbook(BytesIO(self.c.get("/api/reports/sales.xlsx").content))
        self.assertEqual(wb.sheetnames, ["Summary", "Day-wise", "Sizes sold"])
        self.assertEqual(wb["Sizes sold"]["C2"].value, 1)
        wb = load_workbook(BytesIO(self.c.get("/api/reports/low-stock.xlsx").content))
        self.assertEqual(wb["To order"]["D4"].value, "30")

    def test_owner_today_view(self):
        self.sell(1, [self.line(self.s30, 1, 250)])
        self.sell(2, [self.line(self.tie_v, 2, 80)], days_ago=1)
        t = self.c.get("/api/reports/today/").data
        self.assertEqual((float(t["today"]["net"]), float(t["yesterday_net"]), t["low_count"]), (250, 160, 1))
        self.assertEqual([b["number"] for b in t["recent"]], [1, 2])
        self.assertEqual(t["recent"][0]["lines"][0]["size"], "30")
        from config.testing import counter_client
        self.assertEqual(counter_client().get("/api/reports/today/").status_code, 403)
