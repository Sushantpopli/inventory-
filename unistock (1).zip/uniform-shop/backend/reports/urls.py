from django.urls import path

from . import views

urlpatterns = [
    path("summary/", views.summary),
    path("today/", views.today),
    path("top/", views.top),
    path("low-stock/", views.low_stock),
    path("sales.xlsx", views.sales_xlsx),
    path("low-stock.xlsx", views.low_stock_xlsx),
]
