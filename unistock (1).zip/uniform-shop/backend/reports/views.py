"""
Reports API (dates are shop-local, YYYY-MM-DD, both days included; default = today)

GET /api/reports/summary/?from=&to=          totals + the same days last year + day-wise list
GET /api/reports/top/?from=&to=&by=size|product|category|school&limit=20
GET /api/reports/low-stock/?school=<id>|common
GET /api/reports/sales.xlsx?from=&to=        Excel: summary, day-wise, sizes sold
GET /api/reports/low-stock.xlsx?school=      Excel order sheet
"""
from datetime import date, timedelta
from io import BytesIO

from django.http import HttpResponse
from django.utils import timezone
from django.utils.dateparse import parse_date
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from rest_framework.decorators import api_view, permission_classes

from accounts.permissions import IsOwner
from rest_framework.response import Response

from billing.models import Bill, ShopSettings

from . import services

MAX_DAYS = 400


def _range(request):
    today = timezone.localdate()
    start = parse_date(request.query_params.get("from") or "") or today
    end = parse_date(request.query_params.get("to") or "") or start
    if end < start:
        start, end = end, start
    if (end - start).days > MAX_DAYS:
        start = end - timedelta(days=MAX_DAYS)
    return start, end


@api_view(["GET"])
@permission_classes([IsOwner])
def summary(request):
    start, end = _range(request)
    return Response({
        **services.summary(start, end),
        "last_year": services.summary(services.last_year(start), services.last_year(end)),
        "days": services.by_day(start, end),
    })


@api_view(["GET"])
@permission_classes([IsOwner])
def top(request):
    start, end = _range(request)
    by = request.query_params.get("by", "size")
    if by not in ("size", "product", "category", "school"):
        return Response({"detail": "by must be size, product, category or school"}, status=400)
    limit = min(int(request.query_params.get("limit") or 20), 500)
    return Response({"from": start, "to": end, "by": by, "rows": services.top_items(start, end, by, limit)})


@api_view(["GET"])
def low_stock(request):
    return Response({"groups": services.low_stock(request.query_params.get("school"))})


@api_view(["GET"])
@permission_classes([IsOwner])
def today(request):
    """Everything the owner's phone shows, in one call."""
    d = timezone.localdate()
    s = services.summary(d, d)
    low = services.low_stock()
    low_sizes = [{"product": g["product"], "size": x["size"], "stock": x["stock"]} for g in low for x in g["sizes"]]
    low_sizes.sort(key=lambda x: x["stock"])
    recent = (Bill.objects.filter(created_at__date__gte=d - timedelta(days=1)).prefetch_related("lines")
              .order_by("-created_at")[:15])
    return Response({
        "date": d,
        "today": {k: s[k] for k in ("net", "sales", "returns", "bills", "return_bills", "pieces_sold", "cash", "upi")},
        "yesterday_net": services.summary(d - timedelta(days=1), d - timedelta(days=1))["net"],
        "last_week_net": services.summary(d - timedelta(days=7), d - timedelta(days=7))["net"],
        "low_count": len(low_sizes),
        "low_top": low_sizes[:5],
        "recent": [{"id": str(b.id), "number": b.number, "at": b.created_at, "total": b.total, "status": b.status,
                    "items": sum(abs(l.qty) for l in b.lines.all()), "has_return": any(l.qty < 0 for l in b.lines.all()),
                    "mode": b.payment_mode,
                    "lines": [{"description": l.description, "size": l.size, "qty": l.qty, "amount": l.amount}
                              for l in b.lines.all()]} for b in recent],
    })


# ---------------------------------------------------------------- Excel

HEAD = PatternFill("solid", fgColor="1F3A68")


def _sheet(ws, headers, rows, widths):
    ws.append(headers)
    for c in ws[ws.max_row]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = HEAD
    for r in rows:
        ws.append(r)
    for i, w in enumerate(widths):
        ws.column_dimensions[chr(65 + i)].width = w
    ws.freeze_panes = ws.cell(row=ws.max_row - len(rows) + 1, column=1) if rows else None


def _xlsx(wb, filename):
    buf = BytesIO()
    wb.save(buf)
    resp = HttpResponse(buf.getvalue(), content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    resp["Content-Disposition"] = f'attachment; filename="{filename}"'
    return resp


@api_view(["GET"])
@permission_classes([IsOwner])
def sales_xlsx(request):
    start, end = _range(request)
    s = services.summary(start, end)
    shop = ShopSettings.get().firm_name
    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws.append([f"{shop} — sales {start:%d %b %Y} to {end:%d %b %Y}"])
    ws["A1"].font = Font(bold=True, size=13)
    ws.append([])
    rows = [("Sales (after discount)", s["sales"]), ("Returns", s["returns"]), ("Net", s["net"]),
            ("Discount given", s["discount"]), ("Cash (net)", s["cash"]), ("UPI (net)", s["upi"]),
            ("Paid by credit note", s["credit_used"]), ("Credit notes given", s["credit_issued"]),
            ("Bills", s["bills"]), ("Return bills", s["return_bills"]), ("Pieces sold", s["pieces_sold"]),
            ("Pieces returned", s["pieces_returned"]), ("Cost of pieces (current cost price)", s["cost"]),
            ("Profit", s["profit"] if s["profit"] is not None else "—"),
            ("Pieces without cost price", s["pieces_without_cost"])]
    _sheet(ws, ["", "Amount / count"], [(a, float(b) if hasattr(b, "quantize") else b) for a, b in rows], [38, 18])

    _sheet(wb.create_sheet("Day-wise"), ["Date", "Net ₹", "Bills", "Cash ₹", "UPI ₹"],
           [(d["day"], float(d["net"]), d["bills"], float(d["cash"]), float(d["upi"])) for d in services.by_day(start, end)],
           [12, 12, 8, 12, 12])
    _sheet(wb.create_sheet("Sizes sold"), ["Item", "Size", "Pieces (net)", "Amount ₹"],
           [(r["name"], r["size"], r["qty"], float(r["amount"])) for r in services.top_items(start, end, "size", 5000)],
           [40, 8, 13, 12])
    return _xlsx(wb, f"sales_{start}_{end}.xlsx")


@api_view(["GET"])
def low_stock_xlsx(request):
    groups = services.low_stock(request.query_params.get("school"))
    wb = Workbook()
    ws = wb.active
    ws.title = "To order"
    ws.append([f"Low stock — {timezone.localdate():%d %b %Y}"])
    ws["A1"].font = Font(bold=True, size=13)
    ws.append([])
    rows = [(g["schools"], g["category"], g["detail"], s["size"], s["stock"], s["sold_recently"], s["suggest"], None)
            for g in groups for s in g["sizes"]]
    _sheet(ws, ["School", "Item", "Detail", "Size", "In stock", "Sold last 30 days", "Suggested order", "Order qty"],
           rows, [18, 14, 16, 8, 9, 16, 15, 10])
    return _xlsx(wb, f"low_stock_{timezone.localdate()}.xlsx")
