from decimal import Decimal

from django.db import transaction
from django.db.models import Max, Sum
from django.utils import timezone

from catalog.models import StockMovement, Variant
from catalog.services import record_movement

from .models import Bill, BillLine, CreditNote, ShopSettings


class BillError(ValueError):
    pass


def next_bill_number() -> int:
    top = Bill.objects.aggregate(m=Max("number"))["m"] or 0
    return max(top + 1, ShopSettings.get().first_bill_number)


def line_description(variant: Variant) -> str:
    p = variant.product
    schools = [s.short_name for s in p.schools.all()]
    who = ", ".join(schools[:3]) + (f" +{len(schools) - 3}" if len(schools) > 3 else "") if schools else ""
    parts = [x for x in (who, p.category.name, p.name) if x]
    return " ".join(parts)


TWO = Decimal("0.01")


def returned_so_far(line: BillLine) -> int:
    """Pieces of this sold line already returned on bills that are not cancelled."""
    n = line.returns.filter(bill__status=Bill.Status.DONE).aggregate(s=Sum("qty"))["s"] or 0
    return -n


def refund_price(line: BillLine) -> Decimal:
    """What one piece was really paid: its price minus its share of any bill discount."""
    bill = line.bill
    sold = sum((l.amount for l in bill.lines.all() if l.qty > 0), Decimal(0))
    if not bill.discount or not sold:
        return line.price
    return (line.price * (1 - bill.discount / sold)).quantize(TWO)


@transaction.atomic
def save_bill(data: dict) -> tuple[Bill, str]:
    """
    Save one bill sent by the counter. Returns (bill, status):
      "created"     new bill saved, stock changed
      "exists"      this bill was already received earlier (nothing changed)
      "renumbered"  saved, but its number was taken so it got the next free number

    Lines with qty < 0 are returns of a line on an earlier bill. Rules:
      - only within the return days (unless return_override has a reason)
      - never more pieces than were sold on that line
      - never refund more per piece than was paid
    Payment: cash + upi + credit_used - credit_issued == total
    (cash/upi are negative when money is given back).
    """
    existing = Bill.objects.filter(pk=data["id"]).first()
    if existing:
        return existing, "exists"

    lines = data["lines"]
    if not lines:
        raise BillError("A bill needs at least one item")
    settings = ShopSettings.get()
    created_at = data.get("created_at") or timezone.now()
    variants = {v.pk: v for v in Variant.objects.select_related("product__category")
                .prefetch_related("product__schools").filter(pk__in=[l["variant"] for l in lines])}

    prepared, returning = [], {}
    for l in lines:
        v = variants.get(l["variant"])
        if not v:
            raise BillError("An item on this bill no longer exists")
        price, qty = Decimal(l["price"]), int(l["qty"])
        if qty == 0:
            raise BillError("Quantity cannot be 0")
        orig = None
        if qty < 0:
            ref = l.get("returned_from")
            orig = BillLine.objects.select_related("bill").filter(client_id=ref).first() if ref else None
            if not orig or orig.qty <= 0 or orig.bill.status != Bill.Status.DONE:
                raise BillError("A returned item must come from an earlier bill that is not cancelled")
            if orig.variant_id != v.pk:
                raise BillError("Returned item does not match the item on the old bill")
            days = (created_at - orig.bill.created_at).days
            if days > settings.return_days and not (data.get("return_override") or "").strip():
                raise BillError(f"Bill #{orig.bill.number} is {days} days old. Returns are allowed within "
                                f"{settings.return_days} days.")
            returning[orig.pk] = returning.get(orig.pk, 0) - qty
            if returned_so_far(orig) + returning[orig.pk] > orig.qty:
                raise BillError(f"Only {orig.qty - returned_so_far(orig)} piece(s) of {orig.description} "
                                f"{orig.size} from bill #{orig.bill.number} can still be returned")
            if price > orig.price:
                raise BillError("Cannot refund more than the customer paid")
        prepared.append((v, price, qty, price * qty, orig, l.get("client_id")))

    sold = sum((a for _, _, q, a, _, _ in prepared if q > 0), Decimal(0))
    subtotal = sum((p[3] for p in prepared), Decimal(0))
    discount = Decimal(data.get("discount") or 0)
    if discount < 0 or discount > sold:
        raise BillError("Discount must be between 0 and the amount of new items")
    total = subtotal - discount

    cash, upi = Decimal(data.get("cash_amount") or 0), Decimal(data.get("upi_amount") or 0)
    credit_used = Decimal(data.get("credit_used") or 0)
    credit_issued = Decimal(data.get("credit_issued") or 0)
    if credit_used < 0 or credit_issued < 0:
        raise BillError("Credit amounts cannot be negative")
    if total >= 0 and (cash < 0 or upi < 0):
        raise BillError("Money can only be given back when the return is worth more than the new items")
    if total < 0 and (cash > 0 or upi > 0):
        raise BillError("Nothing to collect: the return is worth more than the new items")
    if cash + upi + credit_used - credit_issued != total:
        raise BillError(f"Payment ({cash + upi + credit_used - credit_issued}) must equal the bill total ({total})")

    note = None
    if credit_used:
        note = CreditNote.objects.select_for_update().filter(code__iexact=(data.get("credit_note_code") or "").strip()).first()
        if not note or note.cancelled:
            raise BillError("Credit note not found")
        if note.balance < credit_used:
            raise BillError(f"Credit note {note.code} has only {note.balance} left")

    status = "created"
    number = data["number"]
    if Bill.objects.filter(number=number).exists():
        number, status = next_bill_number(), "renumbered"

    bill = Bill.objects.create(
        id=data["id"], number=number, created_at=created_at,
        device=data.get("device", ""), customer_name=data.get("customer_name", ""),
        customer_phone=data.get("customer_phone", ""), subtotal=subtotal, discount=discount,
        total=total, cash_amount=cash, upi_amount=upi, credit_used=credit_used, credit_note_used=note,
        credit_issued=credit_issued, return_override=(data.get("return_override") or "").strip()[:200],
    )
    for v, price, qty, amount, orig, client_id in prepared:
        extra = {"client_id": client_id} if client_id else {}
        BillLine.objects.create(bill=bill, variant=v, description=line_description(v), size=v.size,
                                price=price, qty=qty, amount=amount, returned_from=orig, **extra)
        if qty > 0:
            record_movement(v, -qty, StockMovement.Kind.SALE, reference=f"Bill #{number}")
        else:
            record_movement(v, -qty, StockMovement.Kind.RETURN, reference=f"Bill #{number} (return from #{orig.bill.number})")
    if note:
        note.balance -= credit_used
        note.save(update_fields=["balance"])
    if credit_issued:
        CreditNote.objects.create(code=f"CN{number}", issued_on=bill, amount=credit_issued, balance=credit_issued)
    return bill, status


@transaction.atomic
def cancel_bill(bill: Bill, reason: str) -> Bill:
    """Cancel a bill: it stays in the records (marked cancelled) and stock goes back."""
    bill = Bill.objects.select_for_update().get(pk=bill.pk)
    if bill.status == Bill.Status.CANCELLED:
        raise BillError("This bill is already cancelled")
    if not reason.strip():
        raise BillError("Write a reason for cancelling")
    later = BillLine.objects.filter(returned_from__bill=bill, bill__status=Bill.Status.DONE).select_related("bill").first()
    if later:
        raise BillError(f"Items from this bill were returned on bill #{later.bill.number}. Cancel that bill first.")
    issued = CreditNote.objects.select_for_update().filter(issued_on=bill).first()
    if issued and issued.balance < issued.amount:
        raise BillError(f"Credit note {issued.code} from this bill has already been used")
    for line in bill.lines.select_related("variant"):
        record_movement(line.variant, line.qty, StockMovement.Kind.CANCEL, reference=f"Bill #{bill.number} cancelled")
    if issued:
        issued.cancelled, issued.balance = True, 0
        issued.save(update_fields=["cancelled", "balance"])
    if bill.credit_note_used_id and bill.credit_used:
        note = CreditNote.objects.select_for_update().get(pk=bill.credit_note_used_id)
        note.balance += bill.credit_used
        note.save(update_fields=["balance"])
    bill.status = Bill.Status.CANCELLED
    bill.cancel_reason = reason.strip()
    bill.cancelled_at = timezone.now()
    bill.save(update_fields=["status", "cancel_reason", "cancelled_at"])
    return bill
