"""
Billing API

GET   /api/billing/settings/                 shop name, phone… (printed on bills)
PATCH /api/billing/settings/
GET   /api/billing/snapshot/?since=<time>    everything the counter needs to bill offline
POST  /api/billing/sync/                     {bills: [...]} send bills made on the counter
GET   /api/billing/bills/?date=2026-10-07&q=1043
GET   /api/billing/bills/<id>/
POST  /api/billing/bills/<id>/cancel/        {reason}
"""
from datetime import datetime

from django.db.models import Q
from django.utils import timezone
from django.utils.dateparse import parse_date, parse_datetime
from rest_framework import status, viewsets
from rest_framework.decorators import action, api_view

from accounts.permissions import is_owner
from rest_framework.response import Response

from catalog.models import Variant

from . import services
from .models import Bill, CreditNote, ShopSettings
from .serializers import (BillInSerializer, BillSerializer, CounterVariantSerializer, CreditNoteSerializer,
                          ShopSettingsSerializer)


@api_view(["GET", "PATCH"])
def shop_settings(request):
    obj = ShopSettings.get()
    if request.method == "PATCH" and not is_owner(request.user):
        return Response({"detail": "Only the owner can change shop settings."}, status=status.HTTP_403_FORBIDDEN)
    if request.method == "PATCH":
        s = ShopSettingsSerializer(obj, data=request.data, partial=True)
        s.is_valid(raise_exception=True)
        s.save()
    return Response(ShopSettingsSerializer(obj).data)


@api_view(["GET"])
def snapshot(request):
    """
    Full list on first load; with ?since= only rows changed after that time.
    The counter stores `server_time` and sends it back as `since` next time.
    """
    now = timezone.now()
    qs = Variant.objects.select_related("product__category").prefetch_related("product__schools")
    since = parse_datetime(request.query_params.get("since") or "")
    if since:
        qs = qs.filter(Q(updated_at__gt=since) | Q(product__updated_at__gt=since)
                       | Q(product__category__updated_at__gt=since))
    else:
        qs = qs.filter(active=True, product__active=True)
    st = ShopSettings.get()
    return Response({
        "server_time": now.isoformat(),
        "full": since is None,
        "settings": {**ShopSettingsSerializer(st).data, "footer_text": st.footer_text()},
        "next_bill_number": services.next_bill_number(),
        "variants": CounterVariantSerializer(qs, many=True).data,
    })


@api_view(["POST"])
def sync_bills(request):
    """Save bills from the counter. Each bill gets its own result; one bad bill doesn't block the rest."""
    results = []
    for raw in request.data.get("bills", []):
        s = BillInSerializer(data=raw)
        if not s.is_valid():
            results.append({"id": raw.get("id"), "status": "error", "detail": s.errors})
            continue
        try:
            bill, st = services.save_bill(s.validated_data)
            note = getattr(bill, "credit_note_issued", None)
            results.append({"id": str(bill.id), "status": st, "number": bill.number,
                            "credit_note_code": note.code if note else None})
        except services.BillError as e:
            results.append({"id": str(s.validated_data["id"]), "status": "error", "detail": str(e)})
    return Response({"results": results, "next_bill_number": services.next_bill_number()})


class BillViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = BillSerializer

    def get_queryset(self):
        qs = Bill.objects.prefetch_related("lines")
        p = self.request.query_params
        d = parse_date(p.get("date") or "")
        if d:
            tz = timezone.get_current_timezone()
            start = timezone.make_aware(datetime.combine(d, datetime.min.time()), tz)
            qs = qs.filter(created_at__gte=start, created_at__lt=start + timezone.timedelta(days=1))
        if p.get("variant"):  # "scan the item to find its bill": recent bills that sold this size
            days = int(p.get("days") or ShopSettings.get().return_days)
            qs = qs.filter(lines__variant_id=p["variant"], lines__qty__gt=0, status=Bill.Status.DONE,
                           created_at__gte=timezone.now() - timezone.timedelta(days=days + 1)).distinct()
        if p.get("q"):
            q = p["q"].strip()
            cond = Q(customer_name__icontains=q) | Q(customer_phone__icontains=q)
            if q.isdigit():
                cond |= Q(number=int(q))
            qs = qs.filter(cond)
        return qs

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        bill = self.get_object()
        # counter staff can fix today's mistakes; older bills need the owner
        if not is_owner(request.user) and timezone.localtime(bill.created_at).date() != timezone.localdate():
            return Response({"detail": "Only the owner can cancel a bill from an earlier day."},
                            status=status.HTTP_403_FORBIDDEN)
        try:
            bill = services.cancel_bill(bill, request.data.get("reason", ""))
        except services.BillError as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(BillSerializer(bill).data)


@api_view(["GET"])
def credit_note(request, code):
    note = CreditNote.objects.select_related("issued_on").filter(code__iexact=code.strip()).first()
    if not note:
        return Response({"detail": "Credit note not found"}, status=status.HTTP_404_NOT_FOUND)
    return Response(CreditNoteSerializer(note).data)
