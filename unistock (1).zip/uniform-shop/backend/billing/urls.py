from django.urls import include, path
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register("bills", views.BillViewSet, basename="bill")

urlpatterns = [
    path("settings/", views.shop_settings),
    path("snapshot/", views.snapshot),
    path("sync/", views.sync_bills),
    path("credit-notes/<str:code>/", views.credit_note),
    path("", include(router.urls)),
]
