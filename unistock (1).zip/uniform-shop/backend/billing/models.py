"""
Billing.

Bills are created on the counter computer, even with no internet, and sent to the
server later. So:
- the bill id (UUID) is made on the counter, which lets the server ignore a bill it
  has already received (safe to send twice);
- each line keeps a copy of the name, size and price at the time of sale, so old
  bills never change when prices change later.
"""
import uuid

from django.db import models

from catalog.models import Variant


class ShopSettings(models.Model):
    """One row. Printed on every bill and used by the counter."""

    firm_name = models.CharField(max_length=120, default="Your Shop Name")
    phone = models.CharField(max_length=40, blank=True)
    address = models.CharField(max_length=200, blank=True)
    bill_footer = models.CharField(max_length=200, default="Thank you! Exchange/return within {days} days with bill.")
    return_days = models.PositiveIntegerField(default=7)
    allow_discount = models.BooleanField(default=True)
    first_bill_number = models.PositiveIntegerField(default=1)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name_plural = "shop settings"

    def __str__(self):
        return self.firm_name

    @classmethod
    def get(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

    def footer_text(self):
        return self.bill_footer.replace("{days}", str(self.return_days))


class Bill(models.Model):
    class Status(models.TextChoices):
        DONE = "done", "Done"
        CANCELLED = "cancelled", "Cancelled"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    number = models.PositiveIntegerField(unique=True)
    created_at = models.DateTimeField(help_text="Time on the counter when the bill was made")
    synced_at = models.DateTimeField(auto_now_add=True)
    device = models.CharField(max_length=40, blank=True)
    customer_name = models.CharField(max_length=80, blank=True)
    customer_phone = models.CharField(max_length=20, blank=True)
    subtotal = models.DecimalField(max_digits=10, decimal_places=2)
    discount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=10, decimal_places=2)
    cash_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    upi_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.DONE)
    cancel_reason = models.CharField(max_length=200, blank=True)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    # Returns / exchange (Module 5)
    credit_used = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                      help_text="Paid with an old credit note")
    credit_note_used = models.ForeignKey("CreditNote", null=True, blank=True, on_delete=models.PROTECT,
                                         related_name="used_on_bills")
    credit_issued = models.DecimalField(max_digits=10, decimal_places=2, default=0,
                                        help_text="Return value kept as a new credit note")
    return_override = models.CharField(max_length=200, blank=True,
                                       help_text="Why a return after the allowed days was accepted")

    class Meta:
        ordering = ["-number"]

    def __str__(self):
        return f"Bill #{self.number}"

    @property
    def has_return(self):
        return any(l.qty < 0 for l in self.lines.all())

    @property
    def payment_mode(self):
        if self.cash_amount and self.upi_amount:
            return "split"
        return "upi" if self.upi_amount else "cash"


class BillLine(models.Model):
    """
    qty > 0: sold.  qty < 0: returned (points to the line it was sold on, `returned_from`).
    A bill with both is an exchange; its total is the difference.
    """

    client_id = models.UUIDField(unique=True, default=uuid.uuid4, help_text="Made on the counter")
    bill = models.ForeignKey(Bill, on_delete=models.CASCADE, related_name="lines")
    variant = models.ForeignKey(Variant, on_delete=models.PROTECT, related_name="bill_lines")
    description = models.CharField(max_length=160)
    size = models.CharField(max_length=20)
    price = models.DecimalField(max_digits=9, decimal_places=2)
    qty = models.IntegerField()
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    returned_from = models.ForeignKey("self", null=True, blank=True, on_delete=models.PROTECT,
                                      related_name="returns")

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return f"{self.qty} × {self.description} {self.size}"


class CreditNote(models.Model):
    """
    Money the shop owes a customer after a return, to spend on anything later.
    Code is CN + the bill number it came from, so it can be made on the counter offline.
    """

    code = models.CharField(max_length=20, unique=True)
    issued_on = models.OneToOneField(Bill, on_delete=models.PROTECT, related_name="credit_note_issued")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    balance = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    cancelled = models.BooleanField(default=False)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.code} (balance {self.balance})"
