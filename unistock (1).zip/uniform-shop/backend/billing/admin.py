from django.contrib import admin

from .models import Bill, BillLine, ShopSettings


@admin.register(ShopSettings)
class ShopSettingsAdmin(admin.ModelAdmin):
    list_display = ["firm_name", "phone", "return_days"]


class BillLineInline(admin.TabularInline):
    model = BillLine
    extra = 0
    readonly_fields = ["variant", "description", "size", "price", "qty", "amount"]
    can_delete = False


@admin.register(Bill)
class BillAdmin(admin.ModelAdmin):
    list_display = ["number", "created_at", "total", "payment_mode", "status", "customer_name"]
    list_filter = ["status"]
    search_fields = ["number", "customer_name", "customer_phone"]
    inlines = [BillLineInline]
    readonly_fields = [f.name for f in Bill._meta.fields]

    def has_delete_permission(self, request, obj=None):
        return False  # cancel bills from the app instead; records stay
