"""Returns, exchanges and credit notes (Module 5)."""
import uuid
from datetime import timedelta

from django.utils import timezone

from billing.models import Bill, CreditNote
from catalog.models import StockMovement

from .test_billing import Base


class ReturnBase(Base):
    def sale(self, number=1, qty=2, discount=0, days_ago=1):
        """Sell `qty` DPS shirts size 28 @240. Returns (bill body, line client_id)."""
        line_id = str(uuid.uuid4())
        total = 240 * qty - discount
        body = {"id": str(uuid.uuid4()), "number": number,
                "created_at": (timezone.now() - timedelta(days=days_ago)).isoformat(),
                "discount": discount, "cash_amount": total, "upi_amount": 0,
                "lines": [{"variant": str(self.s28.id), "qty": qty, "price": "240", "client_id": line_id}]}
        res = self.sync(body)
        assert res.data["results"][0]["status"] == "created", res.data
        return body, line_id

    def ret_line(self, line_id, qty=1, price="240", variant=None):
        return {"variant": str((variant or self.s28).id), "qty": -qty, "price": price, "returned_from": line_id}

    def bill_with(self, number, lines, **pay):
        body = {"id": str(uuid.uuid4()), "number": number, "created_at": timezone.now().isoformat(), "lines": lines}
        body.update(pay)
        return body

    def result(self, body):
        return self.sync(body).data["results"][0]


class Returns(ReturnBase):
    def test_return_with_cash_back(self):
        _, line = self.sale(qty=2)
        r = self.result(self.bill_with(2, [self.ret_line(line)], cash_amount="-240"))
        self.assertEqual(r["status"], "created", r)
        b = Bill.objects.get(number=2)
        self.assertEqual((b.total, b.has_return), (-240, True))
        self.assertEqual(self.stock(self.s28), 4)  # 5 - 2 sold + 1 back
        self.assertTrue(StockMovement.objects.filter(kind="return", qty=1).exists())

    def test_cannot_return_more_than_sold(self):
        _, line = self.sale(qty=2)
        self.assertEqual(self.result(self.bill_with(2, [self.ret_line(line)], cash_amount="-240"))["status"], "created")
        r = self.result(self.bill_with(3, [self.ret_line(line, qty=2)], cash_amount="-480"))
        self.assertEqual(r["status"], "error")
        self.assertIn("Only 1 piece", r["detail"])

    def test_seven_day_rule_and_override(self):
        _, line = self.sale(days_ago=9)
        r = self.result(self.bill_with(2, [self.ret_line(line)], cash_amount="-240"))
        self.assertEqual(r["status"], "error")
        self.assertIn("9 days old", r["detail"])
        r = self.result(self.bill_with(3, [self.ret_line(line)], cash_amount="-240", return_override="Owner allowed"))
        self.assertEqual(r["status"], "created", r)

    def test_wrong_item_or_unknown_line_rejected(self):
        _, line = self.sale()
        r = self.result(self.bill_with(2, [self.ret_line(line, variant=self.s30)], cash_amount="-240"))
        self.assertIn("does not match", r["detail"])
        r = self.result(self.bill_with(3, [self.ret_line(str(uuid.uuid4()))], cash_amount="-240"))
        self.assertIn("earlier bill", r["detail"])

    def test_refund_never_more_than_paid(self):
        _, line = self.sale()
        r = self.result(self.bill_with(2, [self.ret_line(line, price="300")], cash_amount="-300"))
        self.assertIn("more than the customer paid", r["detail"])

    def test_refund_price_includes_discount_share(self):
        self.sale(qty=2, discount=48)  # 480 - 48 → each piece really cost 216
        res = self.c.get("/api/billing/bills/", {"q": "1"}).data["results"][0]
        self.assertEqual(res["lines"][0]["refund_price"], "216.00")


class Exchange(ReturnBase):
    def test_exchange_customer_pays_difference(self):
        _, line = self.sale()
        lines = [self.ret_line(line), {"variant": str(self.s30.id), "qty": 1, "price": "250"}]
        r = self.result(self.bill_with(2, lines, upi_amount="10"))
        self.assertEqual(r["status"], "created", r)
        self.assertEqual(Bill.objects.get(number=2).total, 10)
        self.assertEqual((self.stock(self.s28), self.stock(self.s30)), (4, 1))

    def test_exchange_even_swap_needs_no_payment(self):
        _, line = self.sale()
        s28_again = {"variant": str(self.s28.id), "qty": 1, "price": "240"}
        self.assertEqual(self.result(self.bill_with(2, [self.ret_line(line), s28_again]))["status"], "created")

    def test_money_direction_checked(self):
        _, line = self.sale()
        # return worth 240, nothing new: shop cannot "collect" money
        r = self.result(self.bill_with(2, [self.ret_line(line)], cash_amount="240"))
        self.assertEqual(r["status"], "error")


class CreditNotes(ReturnBase):
    def test_issue_and_spend_credit_note(self):
        _, line = self.sale()
        r = self.result(self.bill_with(2, [self.ret_line(line)], credit_issued="240"))
        self.assertEqual((r["status"], r["credit_note_code"]), ("created", "CN2"))
        note = self.c.get("/api/billing/credit-notes/cn2/").data
        self.assertEqual((note["balance"], note["bill_number"]), ("240.00", 2))

        # spend 80 on a tie, rest stays on the note
        tie = {"variant": str(self.tie_v.id), "qty": 1, "price": "80"}
        r = self.result(self.bill_with(3, [tie], credit_used="80", credit_note_code="CN2"))
        self.assertEqual(r["status"], "created", r)
        self.assertEqual(CreditNote.objects.get(code="CN2").balance, 160)

        # can't spend more than is left
        two_ties = {"variant": str(self.tie_v.id), "qty": 2, "price": "80"}
        r = self.result(self.bill_with(4, [{**two_ties, "qty": 3}], credit_used="240", credit_note_code="CN2"))
        self.assertIn("only 160", r["detail"])

        # part credit + part cash
        r = self.result(self.bill_with(5, [{**two_ties, "qty": 3}], credit_used="160", credit_note_code="CN2", cash_amount="80"))
        self.assertEqual(r["status"], "created", r)
        self.assertEqual(CreditNote.objects.get(code="CN2").balance, 0)

    def test_unknown_credit_note(self):
        tie = {"variant": str(self.tie_v.id), "qty": 1, "price": "80"}
        r = self.result(self.bill_with(1, [tie], credit_used="80", credit_note_code="CN999"))
        self.assertIn("not found", r["detail"])
        self.assertEqual(self.c.get("/api/billing/credit-notes/CN999/").status_code, 404)


class CancelRules(ReturnBase):
    def cancel(self, bill_id):
        return self.c.post(f"/api/billing/bills/{bill_id}/cancel/", {"reason": "mistake"}, format="json")

    def test_cannot_cancel_sale_after_its_return(self):
        sale, line = self.sale()
        ret = self.bill_with(2, [self.ret_line(line)], cash_amount="-240")
        self.sync(ret)
        res = self.cancel(sale["id"])
        self.assertEqual(res.status_code, 400)
        self.assertIn("bill #2", res.data["detail"])
        # cancel the return first, then the sale
        self.assertEqual(self.cancel(ret["id"]).status_code, 200)
        self.assertEqual(self.stock(self.s28), 3)
        self.assertEqual(self.cancel(sale["id"]).status_code, 200)
        self.assertEqual(self.stock(self.s28), 5)

    def test_cancel_return_with_unused_credit_note(self):
        _, line = self.sale()
        ret = self.bill_with(2, [self.ret_line(line)], credit_issued="240")
        self.sync(ret)
        self.assertEqual(self.cancel(ret["id"]).status_code, 200)
        note = CreditNote.objects.get(code="CN2")
        self.assertEqual((note.cancelled, note.balance), (True, 0))

    def test_cannot_cancel_when_credit_note_spent(self):
        _, line = self.sale()
        ret = self.bill_with(2, [self.ret_line(line)], credit_issued="240")
        self.sync(ret)
        tie = {"variant": str(self.tie_v.id), "qty": 1, "price": "80"}
        spend = self.bill_with(3, [tie], credit_used="80", credit_note_code="CN2")
        self.sync(spend)
        self.assertIn("already been used", self.cancel(ret["id"]).data["detail"])
        # cancelling the bill that spent it gives the credit back
        self.assertEqual(self.cancel(spend["id"]).status_code, 200)
        self.assertEqual(CreditNote.objects.get(code="CN2").balance, 240)


class FindBillByItem(ReturnBase):
    def test_scan_item_finds_recent_bills(self):
        self.sale(number=1, days_ago=2)
        self.sale(number=2, days_ago=20)
        res = self.c.get("/api/billing/bills/", {"variant": str(self.s28.id)}).data
        self.assertEqual([b["number"] for b in res["results"]], [1])
