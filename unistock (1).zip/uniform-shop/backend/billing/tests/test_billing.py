import uuid
from io import StringIO

from django.core.management import call_command
from django.test import TestCase
from config.testing import owner_client

from billing.models import Bill, ShopSettings
from catalog import services as catalog
from catalog.models import Category, School, StockMovement


class Base(TestCase):
    def setUp(self):
        call_command("seed_shop", stdout=StringIO())
        self.c = owner_client()
        self.shirt = catalog.create_product(
            category=Category.objects.get(name="Shirt"), schools=[School.objects.get(short_name="DPS")],
            season="summer", gender="boy", name="Half sleeve", sizes=["28", "30"], start_price=240, step=10,
            opening_stock=[5, 2])
        self.tie = catalog.create_product(
            category=Category.objects.get(name="Tie"), schools=[], season="all", gender="unisex",
            sizes=["Free"], start_price=80, opening_stock=[10])
        self.s28, self.s30 = self.shirt.variants.order_by("sort_order")
        self.tie_v = self.tie.variants.get()

    def bill(self, number=1, lines=None, **kw):
        lines = lines or [{"variant": str(self.s28.id), "qty": 2, "price": "240"},
                          {"variant": str(self.tie_v.id), "qty": 1, "price": "80"}]
        total = sum(float(l["price"]) * l["qty"] for l in lines) - float(kw.get("discount", 0))
        body = {"id": str(uuid.uuid4()), "number": number, "created_at": "2026-10-07T11:30:00+05:30",
                "device": "counter-1", "cash_amount": total, "upi_amount": 0, "lines": lines}
        body.update(kw)
        return body

    def sync(self, *bills):
        return self.c.post("/api/billing/sync/", {"bills": list(bills)}, format="json")

    def stock(self, v):
        v.refresh_from_db()
        return v.stock


class Sync(Base):
    def test_bill_saved_and_stock_reduced(self):
        res = self.sync(self.bill())
        self.assertEqual(res.data["results"][0]["status"], "created")
        self.assertEqual(res.data["next_bill_number"], 2)
        b = Bill.objects.get()
        self.assertEqual((b.subtotal, b.total, b.payment_mode), (560, 560, "cash"))
        self.assertEqual([l.description for l in b.lines.all()], ["DPS Shirt Half sleeve", "Tie"])
        self.assertEqual((self.stock(self.s28), self.stock(self.tie_v)), (3, 9))
        self.assertEqual(StockMovement.objects.filter(kind="sale").count(), 2)

    def test_sending_twice_is_safe(self):
        b = self.bill()
        self.sync(b)
        res = self.sync(b)
        self.assertEqual(res.data["results"][0]["status"], "exists")
        self.assertEqual(Bill.objects.count(), 1)
        self.assertEqual(self.stock(self.s28), 3)

    def test_number_clash_gets_next_number(self):
        self.sync(self.bill(number=5))
        res = self.sync(self.bill(number=5))
        self.assertEqual(res.data["results"][0], {**res.data["results"][0], "status": "renumbered", "number": 6})

    def test_split_payment_and_discount(self):
        res = self.sync(self.bill(discount="60", cash_amount="300", upi_amount="200"))
        self.assertEqual(res.data["results"][0]["status"], "created", res.data)
        b = Bill.objects.get()
        self.assertEqual((b.total, b.payment_mode), (500, "split"))

    def test_wrong_payment_rejected_but_others_saved(self):
        bad = self.bill(number=1, cash_amount="100")
        good = self.bill(number=2)
        res = self.sync(bad, good)
        self.assertEqual([r["status"] for r in res.data["results"]], ["error", "created"])
        self.assertIn("must equal", res.data["results"][0]["detail"])
        self.assertEqual(self.stock(self.s28), 3)  # only the good bill reduced stock

    def test_selling_more_than_stock_is_allowed(self):
        """Shelf is the truth: if the item is in hand, the bill must go through. Stock shows negative to fix later."""
        self.sync(self.bill(lines=[{"variant": str(self.s30.id), "qty": 3, "price": "250"}]))
        self.assertEqual(self.stock(self.s30), -1)

    def test_price_on_bill_is_kept_when_price_changes(self):
        self.sync(self.bill())
        self.s28.price = 999
        self.s28.save()
        self.assertEqual(Bill.objects.get().lines.first().price, 240)


class Cancel(Base):
    def test_cancel_restores_stock_once(self):
        b = self.bill()
        self.sync(b)
        url = f"/api/billing/bills/{b['id']}/cancel/"
        self.assertEqual(self.c.post(url, {"reason": ""}, format="json").status_code, 400)
        res = self.c.post(url, {"reason": "Customer changed mind"}, format="json")
        self.assertEqual(res.data["status"], "cancelled")
        self.assertEqual((self.stock(self.s28), self.stock(self.tie_v)), (5, 10))
        self.assertEqual(self.c.post(url, {"reason": "again"}, format="json").status_code, 400)
        self.assertEqual(self.stock(self.s28), 5)


class Snapshot(Base):
    def test_full_then_changes_only(self):
        first = self.c.get("/api/billing/snapshot/").data
        self.assertTrue(first["full"])
        self.assertEqual(len(first["variants"]), 3)
        row = next(v for v in first["variants"] if v["size"] == "28")
        self.assertEqual((row["schools"], row["category"], row["stock"]), (["DPS"], "Shirt", 5))
        self.assertEqual(first["settings"]["footer_text"], "Thank you! Exchange/return within 7 days with bill.")

        since = first["server_time"]
        self.assertEqual(len(self.c.get("/api/billing/snapshot/", {"since": since}).data["variants"]), 0)
        self.sync(self.bill(lines=[{"variant": str(self.s28.id), "qty": 1, "price": "240"}], cash_amount=240))
        changed = self.c.get("/api/billing/snapshot/", {"since": since}).data["variants"]
        self.assertEqual([(v["size"], v["stock"]) for v in changed], [("28", 4)])

    def test_hidden_product_reaches_counter_as_inactive(self):
        since = self.c.get("/api/billing/snapshot/").data["server_time"]
        self.c.patch(f"/api/catalog/products/{self.tie.id}/", {"active": False}, format="json")
        changed = self.c.get("/api/billing/snapshot/", {"since": since}).data["variants"]
        self.assertEqual([(v["category"], v["active"]) for v in changed], [("Tie", False)])

    def test_next_number_respects_first_number_setting(self):
        self.c.patch("/api/billing/settings/", {"first_bill_number": 1001}, format="json")
        self.assertEqual(self.c.get("/api/billing/snapshot/").data["next_bill_number"], 1001)


class BillList(Base):
    def test_search_by_number_and_date(self):
        self.sync(self.bill(number=41, customer_name="Mrs Sharma"))
        self.sync(self.bill(number=42, created_at="2026-10-06T18:00:00+05:30"))
        self.assertEqual(self.c.get("/api/billing/bills/", {"q": "41"}).data["count"], 1)
        self.assertEqual(self.c.get("/api/billing/bills/", {"q": "sharma"}).data["count"], 1)
        self.assertEqual(self.c.get("/api/billing/bills/", {"date": "2026-10-07"}).data["count"], 1)
