from rest_framework import serializers

from catalog.models import Variant

from .models import Bill, BillLine, CreditNote, ShopSettings


class ShopSettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShopSettings
        fields = ["firm_name", "phone", "address", "bill_footer", "return_days", "allow_discount",
                  "first_bill_number", "updated_at"]
        read_only_fields = ["updated_at"]


class CounterVariantSerializer(serializers.ModelSerializer):
    """Flat row the counter keeps offline. Short keys keep the download small."""

    product = serializers.UUIDField(source="product_id")
    category = serializers.CharField(source="product.category.name")
    category_hi = serializers.CharField(source="product.category.name_hi")
    detail = serializers.CharField(source="product.name")
    season = serializers.CharField(source="product.season")
    gender = serializers.CharField(source="product.gender")
    schools = serializers.SerializerMethodField()
    active = serializers.SerializerMethodField()

    class Meta:
        model = Variant
        fields = ["id", "barcode", "size", "sort_order", "price", "stock", "low_stock_level", "product",
                  "category", "category_hi", "detail", "season", "gender", "schools", "active"]

    def get_schools(self, v):
        return [s.short_name for s in v.product.schools.all()]

    def get_active(self, v):
        return v.active and v.product.active


class BillLineInSerializer(serializers.Serializer):
    variant = serializers.UUIDField()
    qty = serializers.IntegerField(min_value=-999, max_value=999)  # negative = returned
    price = serializers.DecimalField(max_digits=9, decimal_places=2, min_value=0)
    client_id = serializers.UUIDField(required=False)
    returned_from = serializers.UUIDField(required=False, allow_null=True)


class BillInSerializer(serializers.Serializer):
    id = serializers.UUIDField()
    number = serializers.IntegerField(min_value=1)
    created_at = serializers.DateTimeField(required=False)
    device = serializers.CharField(max_length=40, required=False, allow_blank=True, default="")
    customer_name = serializers.CharField(max_length=80, required=False, allow_blank=True, default="")
    customer_phone = serializers.CharField(max_length=20, required=False, allow_blank=True, default="")
    discount = serializers.DecimalField(max_digits=10, decimal_places=2, required=False, default=0)
    cash_amount = serializers.DecimalField(max_digits=10, decimal_places=2, required=False, default=0)
    upi_amount = serializers.DecimalField(max_digits=10, decimal_places=2, required=False, default=0)
    credit_used = serializers.DecimalField(max_digits=10, decimal_places=2, required=False, default=0)
    credit_note_code = serializers.CharField(max_length=20, required=False, allow_blank=True, default="")
    credit_issued = serializers.DecimalField(max_digits=10, decimal_places=2, required=False, default=0)
    return_override = serializers.CharField(max_length=200, required=False, allow_blank=True, default="")
    lines = BillLineInSerializer(many=True)


class BillLineSerializer(serializers.ModelSerializer):
    returned_from = serializers.UUIDField(source="returned_from.client_id", read_only=True, default=None)
    returned_qty = serializers.SerializerMethodField()
    refund_price = serializers.SerializerMethodField()

    class Meta:
        model = BillLine
        fields = ["client_id", "variant", "description", "size", "price", "qty", "amount", "returned_from",
                  "returned_qty", "refund_price"]

    def get_returned_qty(self, line):
        from .services import returned_so_far
        return returned_so_far(line) if line.qty > 0 else 0

    def get_refund_price(self, line):
        from .services import refund_price
        return f"{refund_price(line):.2f}" if line.qty > 0 else None


class BillSerializer(serializers.ModelSerializer):
    lines = BillLineSerializer(many=True, read_only=True)
    payment_mode = serializers.CharField(read_only=True)
    credit_note_code = serializers.SerializerMethodField()
    credit_note_used_code = serializers.CharField(source="credit_note_used.code", read_only=True, default=None)

    def get_credit_note_code(self, bill):
        note = getattr(bill, "credit_note_issued", None)
        return note.code if note else None

    class Meta:
        model = Bill
        fields = ["id", "number", "created_at", "synced_at", "device", "customer_name", "customer_phone",
                  "subtotal", "discount", "total", "cash_amount", "upi_amount", "payment_mode", "status",
                  "cancel_reason", "cancelled_at", "credit_used", "credit_note_used_code", "credit_issued",
                  "credit_note_code", "return_override", "lines"]


class CreditNoteSerializer(serializers.ModelSerializer):
    bill_number = serializers.IntegerField(source="issued_on.number", read_only=True)

    class Meta:
        model = CreditNote
        fields = ["code", "amount", "balance", "created_at", "cancelled", "bill_number"]
