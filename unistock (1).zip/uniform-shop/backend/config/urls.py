from django.contrib import admin
from django.urls import include, path

admin.site.site_header = "Uniform Shop — Back Office"

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/auth/", include("accounts.urls")),
    path("api/catalog/", include("catalog.urls")),
    path("api/labels/", include("labels.urls")),
    path("api/billing/", include("billing.urls")),
    path("api/stock/", include("stock.urls")),
    path("api/reports/", include("reports.urls")),
]
