"""Helpers for tests: API clients already logged in as owner or counter staff."""
from django.contrib.auth import get_user_model
from rest_framework.test import APIClient

from accounts.models import StaffProfile


def staff_client(role=StaffProfile.Role.OWNER, name=None):
    User = get_user_model()
    name = name or role.title()
    user = User.objects.create_user(username=f"{role}-{User.objects.count()}", password="1234")
    StaffProfile.objects.create(user=user, display_name=name, role=role)
    c = APIClient()
    c.force_authenticate(user)
    c.user = user
    return c


def owner_client():
    return staff_client(StaffProfile.Role.OWNER)


def counter_client():
    return staff_client(StaffProfile.Role.COUNTER)
