from .models import LabelQueueItem


def add_to_queue(variant, copies: int) -> LabelQueueItem:
    """Put labels on the print list. Adding a size that is already there adds to its copies."""
    item, created = LabelQueueItem.objects.get_or_create(variant=variant, defaults={"copies": copies})
    if not created:
        item.copies += copies
        item.save(update_fields=["copies"])
    return item
