import uuid

from django.db import models

from catalog.models import Variant


class LabelQueueItem(models.Model):
    """
    Labels waiting to be printed. Add during the day (e.g. when new stock arrives),
    print them together, then clear the queue.
    """

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    variant = models.OneToOneField(Variant, on_delete=models.CASCADE, related_name="label_queue")
    copies = models.PositiveIntegerField(default=1)
    added_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["added_at"]

    def __str__(self):
        return f"{self.copies} × {self.variant}"
