"""
Label API

GET    /api/labels/layouts/                         label sizes the shop can print
GET    /api/labels/queue/                           labels waiting to print
POST   /api/labels/queue/                           {variant, copies}  (adds to existing copies)
POST   /api/labels/queue/add_product/               {product, copies: "stock" | number}
PATCH  /api/labels/queue/<id>/                      {copies}
DELETE /api/labels/queue/<id>/
POST   /api/labels/queue/clear/
GET    /api/labels/pdf/?layout=roll_50x25&skip=0    PDF of the whole queue
GET    /api/labels/pdf/?variant=<id>&copies=2       PDF for one size, without the queue
"""
from django.db import transaction
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework import serializers, status, viewsets
from rest_framework.decorators import action, api_view
from rest_framework.response import Response

from catalog.models import Product, Variant

from .models import LabelQueueItem
from .services import add_to_queue as _add
from .pdf import LAYOUTS, MAX_LABELS, build_pdf, label_data_for


class QueueItemSerializer(serializers.ModelSerializer):
    variant = serializers.PrimaryKeyRelatedField(queryset=Variant.objects.all())
    copies = serializers.IntegerField(min_value=1, max_value=MAX_LABELS, default=1)
    product_name = serializers.CharField(source="variant.product.display_name", read_only=True)
    size = serializers.CharField(source="variant.size", read_only=True)
    price = serializers.DecimalField(source="variant.price", max_digits=9, decimal_places=2, read_only=True)
    barcode = serializers.CharField(source="variant.barcode", read_only=True)
    stock = serializers.IntegerField(source="variant.stock", read_only=True)

    class Meta:
        model = LabelQueueItem
        fields = ["id", "variant", "copies", "product_name", "size", "price", "barcode", "stock", "added_at"]
        validators = []  # adding the same size twice adds copies instead of failing


class QueueViewSet(viewsets.ModelViewSet):
    serializer_class = QueueItemSerializer
    pagination_class = None
    http_method_names = ["get", "post", "patch", "delete", "head", "options"]

    def get_queryset(self):
        return LabelQueueItem.objects.select_related("variant__product__category").prefetch_related(
            "variant__product__schools").order_by("added_at", "variant__product_id", "variant__sort_order")

    def create(self, request, *args, **kwargs):
        s = self.get_serializer(data=request.data)
        s.is_valid(raise_exception=True)
        item = _add(s.validated_data["variant"], s.validated_data["copies"])
        return Response(self.get_serializer(item).data, status=status.HTTP_201_CREATED)

    def partial_update(self, request, *args, **kwargs):
        item = self.get_object()
        s = self.get_serializer(item, data={"copies": request.data.get("copies")}, partial=True)
        s.is_valid(raise_exception=True)
        s.save()
        return Response(s.data)

    @action(detail=False, methods=["post"])
    def add_product(self, request):
        """Queue every size of a product. copies="stock" = one label per piece in stock."""
        product = get_object_or_404(Product, pk=request.data.get("product"))
        mode = request.data.get("copies", "stock")
        added = 0
        with transaction.atomic():
            for v in product.variants.filter(active=True):
                if mode == "stock":
                    n = max(v.stock, 0)
                else:
                    try:
                        n = int(mode)
                    except (TypeError, ValueError):
                        return Response({"detail": "copies must be 'stock' or a number"}, status=400)
                if n > 0:
                    _add(v, n)
                    added += n
        if not added:
            return Response({"detail": "No labels added — every size has 0 in stock. Choose a number of copies instead."},
                            status=status.HTTP_400_BAD_REQUEST)
        return Response({"added": added})

    @action(detail=False, methods=["post"])
    def clear(self, request):
        n, _ = LabelQueueItem.objects.all().delete()
        return Response({"cleared": n})


@api_view(["GET"])
def layouts(request):
    return Response([{"key": l.key, "name": l.name, "sheet": l.sheet} for l in LAYOUTS.values()])


@api_view(["GET"])
def labels_pdf(request):
    p = request.query_params
    layout = p.get("layout", "roll_50x25")
    if layout not in LAYOUTS:
        return Response({"detail": f"Unknown label size '{layout}'"}, status=400)
    try:
        skip = max(int(p.get("skip", 0)), 0)
    except ValueError:
        skip = 0

    if p.get("variant"):
        v = get_object_or_404(Variant.objects.select_related("product__category"), pk=p["variant"])
        try:
            copies = min(max(int(p.get("copies", 1)), 1), MAX_LABELS)
        except ValueError:
            copies = 1
        labels = [label_data_for(v)] * copies
    else:
        labels = []
        for item in QueueViewSet().get_queryset():
            labels += [label_data_for(item.variant)] * item.copies

    try:
        pdf = build_pdf(labels, layout, skip)
    except ValueError as e:
        return Response({"detail": str(e)}, status=400)
    resp = HttpResponse(pdf, content_type="application/pdf")
    # inline = opens in the browser's PDF viewer, ready to print
    resp["Content-Disposition"] = f'inline; filename="labels_{layout}.pdf"'
    return resp
