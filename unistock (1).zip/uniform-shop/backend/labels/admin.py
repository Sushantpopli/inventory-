from django.contrib import admin

from .models import LabelQueueItem


@admin.register(LabelQueueItem)
class LabelQueueItemAdmin(admin.ModelAdmin):
    list_display = ["variant", "copies", "added_at"]
