from io import BytesIO, StringIO
from unittest import skipUnless

from django.core.management import call_command
from django.test import TestCase
from pypdf import PdfReader
from config.testing import owner_client

from catalog import services
from catalog.models import Category, School
from labels.models import LabelQueueItem
from labels.pdf import LAYOUTS, build_pdf, label_data_for

try:  # optional: only used to prove the printed barcodes really scan
    import pypdfium2
    import zxingcpp
    HAS_DECODER = True
except ImportError:
    HAS_DECODER = False


class Base(TestCase):
    def setUp(self):
        call_command("seed_shop", stdout=StringIO())
        self.c = owner_client()
        self.product = services.create_product(
            category=Category.objects.get(name="Shirt"), schools=[School.objects.get(short_name="DPS")],
            season="summer", gender="boy", name="Half sleeve", sizes=["28", "30", "32"],
            start_price=240, step=10, opening_stock=[2, 0, 3])
        self.v28, self.v30, self.v32 = self.product.variants.order_by("sort_order")


class Queue(Base):
    def test_adding_same_size_adds_copies(self):
        self.c.post("/api/labels/queue/", {"variant": str(self.v28.id), "copies": 2}, format="json")
        res = self.c.post("/api/labels/queue/", {"variant": str(self.v28.id), "copies": 3}, format="json")
        self.assertEqual(res.status_code, 201, res.data)
        self.assertEqual(LabelQueueItem.objects.get().copies, 5)

    def test_add_product_uses_stock(self):
        res = self.c.post("/api/labels/queue/add_product/", {"product": str(self.product.id)}, format="json")
        self.assertEqual(res.data["added"], 5)  # 2 + 0 + 3
        self.assertEqual(LabelQueueItem.objects.count(), 2)  # size 30 has no stock

    def test_add_product_fixed_copies(self):
        res = self.c.post("/api/labels/queue/add_product/", {"product": str(self.product.id), "copies": 1}, format="json")
        self.assertEqual(res.data["added"], 3)

    def test_edit_and_clear(self):
        item = self.c.post("/api/labels/queue/", {"variant": str(self.v30.id)}, format="json").data
        res = self.c.patch(f"/api/labels/queue/{item['id']}/", {"copies": 7}, format="json")
        self.assertEqual(res.data["copies"], 7)
        self.assertEqual(self.c.patch(f"/api/labels/queue/{item['id']}/", {"copies": 0}, format="json").status_code, 400)
        self.c.post("/api/labels/queue/clear/")
        self.assertEqual(LabelQueueItem.objects.count(), 0)


class Pdf(Base):
    def pages(self, content):
        return len(PdfReader(BytesIO(content)).pages)

    def test_label_text(self):
        d = label_data_for(self.v30)
        self.assertEqual((d.top, d.item, d.size, d.price, d.barcode),
                         ("DPS", "Shirt Half sleeve", "30", "Rs 250", self.v30.barcode))

    def test_roll_one_page_per_label_and_right_size(self):
        self.c.post("/api/labels/queue/add_product/", {"product": str(self.product.id)}, format="json")
        res = self.c.get("/api/labels/pdf/", {"layout": "roll_50x25"})
        self.assertEqual(res["Content-Type"], "application/pdf")
        reader = PdfReader(BytesIO(res.content))
        self.assertEqual(len(reader.pages), 5)
        box = reader.pages[0].mediabox
        self.assertAlmostEqual(float(box.width) / 72 * 25.4, 50, places=1)
        self.assertAlmostEqual(float(box.height) / 72 * 25.4, 25, places=1)
        text = reader.pages[0].extract_text()
        self.assertIn("SIZE 28", text)
        self.assertIn("Rs 240", text)

    def test_long_text_never_overlaps(self):
        from labels.pdf import LabelData
        d = LabelData("A, B, C +4", "Track suit with very long description", "40-38", "Rs 12450", "10001")
        for key in LAYOUTS:
            text = PdfReader(BytesIO(build_pdf([d], key))).pages[0].extract_text()
            self.assertIn("Rs 12450", text)

    def test_many_schools_shortened(self):
        self.product.schools.set(School.objects.all()[:6])
        self.assertTrue(label_data_for(self.v30).top.endswith("+3"))

    def test_a4_sheet_with_skip(self):
        labels = [label_data_for(self.v28)] * 70
        self.assertEqual(self.pages(build_pdf(labels, "a4_65")), 2)          # 65 + 5
        self.assertEqual(self.pages(build_pdf(labels[:60], "a4_65", skip=10)), 2)  # 10 empty + 60
        self.assertEqual(self.pages(build_pdf(labels[:55], "a4_65", skip=10)), 1)  # exactly fills one sheet

    def test_single_variant_without_queue(self):
        res = self.c.get("/api/labels/pdf/", {"variant": str(self.v32.id), "copies": 3, "layout": "roll_38x25"})
        self.assertEqual(self.pages(res.content), 3)

    def test_empty_queue_message(self):
        res = self.c.get("/api/labels/pdf/")
        self.assertEqual(res.status_code, 400)
        self.assertIn("Nothing to print", res.data["detail"])

    @skipUnless(HAS_DECODER, "pip install zxing-cpp pypdfium2 to run the scan test")
    def test_barcodes_scan_on_every_layout(self):
        """Render each layout at 203 dpi (thermal printer resolution) and decode the barcode."""
        for key in LAYOUTS:
            pdf = pypdfium2.PdfDocument(build_pdf([label_data_for(self.v30)], key))
            img = pdf[0].render(scale=203 / 72).to_pil()
            found = [r.text for r in zxingcpp.read_barcodes(img)]
            self.assertIn(self.v30.barcode, found, f"barcode not readable on {key}")
