from django.urls import include, path
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register("queue", views.QueueViewSet, basename="label-queue")

urlpatterns = [
    path("layouts/", views.layouts),
    path("pdf/", views.labels_pdf),
    path("", include(router.urls)),
]
