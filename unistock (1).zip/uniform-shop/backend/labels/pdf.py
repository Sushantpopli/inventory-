"""
Barcode label PDFs.

Works with any printer that can print a PDF:
- Roll layouts: one label per page, page size = label size. Set the label printer's
  paper size to the same size in its Windows driver and print at 100% ("Actual size").
- A4 layout: standard 65-up sticker sheet (38.1 × 21.2 mm) for an ordinary printer.
  `skip` leaves the first N labels empty so a half-used sheet can be reused.

Barcodes are Code 128. Bar width is a whole number of printer dots at 203 dpi
(the common thermal label printer resolution) so scanners read them reliably.
"""
from dataclasses import dataclass
from io import BytesIO

from reportlab.graphics.barcode.code128 import Code128
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfgen import canvas

MAX_LABELS = 3000


@dataclass(frozen=True)
class Layout:
    key: str
    name: str
    label_w: float  # points
    label_h: float
    sheet: bool = False
    cols: int = 1
    rows: int = 1
    margin_left: float = 0
    margin_top: float = 0
    pitch_x: float = 0
    pitch_y: float = 0


LAYOUTS = {
    "roll_50x25": Layout("roll_50x25", "Label roll 50 × 25 mm", 50 * mm, 25 * mm),
    "roll_38x25": Layout("roll_38x25", "Label roll 38 × 25 mm", 38 * mm, 25 * mm),
    "a4_65": Layout("a4_65", "A4 sheet, 65 labels (38.1 × 21.2 mm)", 38.1 * mm, 21.2 * mm, sheet=True,
                    cols=5, rows=13, margin_left=4.65 * mm, margin_top=10.7 * mm,
                    pitch_x=40.64 * mm, pitch_y=21.2 * mm),
}

DOT = 25.4 / 203 * mm  # one printer dot at 203 dpi, in points


@dataclass
class LabelData:
    top: str       # e.g. "DPS" or "COMMON"
    item: str      # e.g. "Shirt Half sleeve"
    size: str
    price: str     # e.g. "Rs 250"
    barcode: str


def label_data_for(variant) -> LabelData:
    p = variant.product
    schools = [s.short_name for s in p.schools.all()]
    if not schools:
        top = "COMMON"
    elif len(schools) > 3:
        top = ", ".join(schools[:3]) + f" +{len(schools) - 3}"
    else:
        top = ", ".join(schools)
    item = p.category.name + (f" {p.name}" if p.name else "")
    price = variant.price
    price_txt = f"Rs {int(price)}" if price == int(price) else f"Rs {price:.2f}"
    return LabelData(top=top, item=item, size=variant.size, price=price_txt, barcode=variant.barcode)


def _fit(text, font, size, max_w):
    """Shorten text with '…' until it fits."""
    if stringWidth(text, font, size) <= max_w:
        return text
    while text and stringWidth(text + "…", font, size) > max_w:
        text = text[:-1]
    return text + "…"


def _barcode(value, max_w, bar_h):
    """Pick the widest bar (3, then 2 dots) that fits; shrink only if nothing fits."""
    for dots in (3, 2):
        bc = Code128(value, barWidth=dots * DOT, barHeight=bar_h, quiet=1, lquiet=6 * dots * DOT, rquiet=6 * dots * DOT)
        if bc.width <= max_w:
            return bc
    probe = Code128(value, barWidth=1, barHeight=bar_h, quiet=1, lquiet=6, rquiet=6)
    w = max_w / probe.width
    return Code128(value, barWidth=w, barHeight=bar_h, quiet=1, lquiet=6 * w, rquiet=6 * w)


def draw_label(c: canvas.Canvas, x, y, w, h, d: LabelData):
    """Draw one label with its bottom-left corner at (x, y)."""
    pad = 1.5 * mm
    inner_w = w - 2 * pad
    small = h < 23 * mm
    f_top, f_size, f_code = (6, 9.5, 5.5) if small else (7, 11, 6)

    # line 1: school(s) + item
    ty = y + h - pad - f_top
    c.setFont("Helvetica-Bold", f_top)
    line1 = _fit(f"{d.top} · {d.item}".upper(), "Helvetica-Bold", f_top, inner_w)
    c.drawString(x + pad, ty, line1)

    # line 2: SIZE (left)  PRICE (right)
    size_txt = f"SIZE {d.size}"
    while f_size > 6 and (stringWidth(size_txt, "Helvetica-Bold", f_size)
                          + stringWidth(d.price, "Helvetica-Bold", f_size) + 2 * mm) > inner_w:
        f_size -= 0.5  # long size + big price on a small label: shrink so they never overlap
    sy = ty - f_size - 0.6 * mm
    c.setFont("Helvetica-Bold", f_size)
    c.drawString(x + pad, sy, size_txt)
    c.drawRightString(x + w - pad, sy, d.price)

    # barcode + number
    code_y = y + pad
    bar_y = code_y + f_code + 0.4 * mm
    bar_h = max(sy - bar_y - 1.0 * mm, 5 * mm)
    bc = _barcode(d.barcode, inner_w, bar_h)
    bc.drawOn(c, x + (w - bc.width) / 2, bar_y)
    c.setFont("Helvetica", f_code)
    c.drawCentredString(x + w / 2, code_y, d.barcode)


def build_pdf(labels: list[LabelData], layout_key: str = "roll_50x25", skip: int = 0, title="Labels") -> bytes:
    layout = LAYOUTS[layout_key]
    if not labels:
        raise ValueError("Nothing to print. Add labels first.")
    if len(labels) > MAX_LABELS:
        raise ValueError(f"Too many labels in one go (max {MAX_LABELS}). Print in parts.")
    buf = BytesIO()
    if not layout.sheet:
        c = canvas.Canvas(buf, pagesize=(layout.label_w, layout.label_h))
        c.setTitle(title)
        for d in labels:
            draw_label(c, 0, 0, layout.label_w, layout.label_h, d)
            c.showPage()
    else:
        c = canvas.Canvas(buf, pagesize=A4)
        c.setTitle(title)
        per_page = layout.cols * layout.rows
        page_h = A4[1]
        slots = [None] * (skip % per_page) + list(labels)
        for i, d in enumerate(slots):
            pos = i % per_page
            if i and pos == 0:
                c.showPage()
            if d is None:
                continue
            col, row = pos % layout.cols, pos // layout.cols
            x = layout.margin_left + col * layout.pitch_x
            y = page_h - layout.margin_top - (row + 1) * layout.pitch_y
            draw_label(c, x, y, layout.label_w, layout.label_h, d)
        c.showPage()
    c.save()
    return buf.getvalue()
