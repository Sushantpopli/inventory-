from decimal import Decimal
from io import StringIO

from django.core.management import call_command
from django.test import TestCase
from config.testing import owner_client

from catalog import services as catalog
from catalog.models import Category, School, StockMovement
from labels.models import LabelQueueItem
from stock.models import StockIn


class Base(TestCase):
    def setUp(self):
        call_command("seed_shop", stdout=StringIO())
        self.c = owner_client()
        self.p = catalog.create_product(
            category=Category.objects.get(name="Shirt"), schools=[School.objects.get(short_name="DPS")],
            season="summer", gender="boy", name="Half sleeve", sizes=["28", "30"], start_price=240, step=10,
            cost_start=150, cost_step=5, opening_stock=[2, 0])
        self.s28, self.s30 = self.p.variants.order_by("sort_order")

    def stock_in(self, lines, **kw):
        body = {"note": "Own factory", "lines": lines, **kw}
        return self.c.post("/api/stock/entries/", body, format="json")

    def fresh(self, v):
        v.refresh_from_db()
        return v


class StockInTests(Base):
    def test_adds_stock_and_labels(self):
        res = self.stock_in([{"variant": str(self.s28.id), "qty": 10}, {"variant": str(self.s30.id), "qty": 5}])
        self.assertEqual(res.status_code, 201, res.data)
        self.assertEqual((res.data["number"], res.data["total_qty"]), (1, 15))
        self.assertEqual((self.fresh(self.s28).stock, self.fresh(self.s30).stock), (12, 5))
        self.assertEqual(sorted(LabelQueueItem.objects.values_list("copies", flat=True)), [5, 10])
        mv = StockMovement.objects.filter(kind="stock_in", variant=self.s28).get()
        self.assertEqual((mv.qty, mv.reference, mv.note), (10, "Stock in #1", "Own factory"))

    def test_without_labels(self):
        self.stock_in([{"variant": str(self.s28.id), "qty": 3}], add_labels=False)
        self.assertEqual(LabelQueueItem.objects.count(), 0)

    def test_new_cost_and_selling_price_saved(self):
        res = self.stock_in([{"variant": str(self.s28.id), "qty": 4, "cost_price": "160", "price": "260"}])
        line = res.data["lines"][0]
        self.assertEqual((line["old_price"], line["price"], line["price_changed"]), ("240.00", "260.00", True))
        v = self.fresh(self.s28)
        self.assertEqual((v.cost_price, v.price), (Decimal("160"), Decimal("260")))
        self.assertEqual(res.data["total_cost"], "640.00")

    def test_blank_prices_keep_old_ones(self):
        self.stock_in([{"variant": str(self.s28.id), "qty": 1, "cost_price": None, "price": None}])
        v = self.fresh(self.s28)
        self.assertEqual((v.cost_price, v.price), (Decimal("150"), Decimal("240")))

    def test_zero_lines_ignored_and_empty_rejected(self):
        res = self.stock_in([{"variant": str(self.s28.id), "qty": 0}])
        self.assertEqual(res.status_code, 400)
        self.assertIn("at least one", res.data["detail"])
        res = self.stock_in([{"variant": str(self.s28.id), "qty": 0}, {"variant": str(self.s30.id), "qty": 2}])
        self.assertEqual(len(res.data["lines"]), 1)

    def test_same_size_twice_rejected(self):
        res = self.stock_in([{"variant": str(self.s28.id), "qty": 1}, {"variant": str(self.s28.id), "qty": 2}])
        self.assertEqual(res.status_code, 400)
        self.assertEqual(self.fresh(self.s28).stock, 2)

    def test_cancel_takes_stock_back_once(self):
        e = self.stock_in([{"variant": str(self.s28.id), "qty": 10}]).data
        url = f"/api/stock/entries/{e['id']}/cancel/"
        self.assertEqual(self.c.post(url, {"reason": ""}, format="json").status_code, 400)
        self.assertEqual(self.c.post(url, {"reason": "Entered twice"}, format="json").data["status"], "cancelled")
        self.assertEqual(self.fresh(self.s28).stock, 2)
        self.assertEqual(self.c.post(url, {"reason": "x"}, format="json").status_code, 400)
        self.assertEqual(self.fresh(self.s28).stock, 2)

    def test_numbers_go_up(self):
        self.stock_in([{"variant": str(self.s28.id), "qty": 1}])
        res = self.stock_in([{"variant": str(self.s28.id), "qty": 1}])
        self.assertEqual(res.data["number"], 2)
        self.assertEqual(StockIn.objects.count(), 2)

    def test_counter_sees_new_stock_and_price(self):
        since = self.c.get("/api/billing/snapshot/").data["server_time"]
        self.stock_in([{"variant": str(self.s30.id), "qty": 6, "price": "275"}])
        rows = self.c.get("/api/billing/snapshot/", {"since": since}).data["variants"]
        self.assertEqual([(r["size"], r["stock"], r["price"]) for r in rows], [("30", 6, "275.00")])


class CorrectAndHistory(Base):
    def test_correct_stock_after_count(self):
        res = self.c.post("/api/stock/correct/", {"variant": str(self.s28.id), "counted": 7, "reason": "Shelf count"}, format="json")
        self.assertEqual(res.data, {"stock": 7, "changed_by": 5})
        res = self.c.post("/api/stock/correct/", {"variant": str(self.s28.id), "counted": 7}, format="json")
        self.assertEqual(res.data["changed_by"], 0)
        self.assertEqual(self.c.post("/api/stock/correct/", {"variant": str(self.s28.id), "counted": -1}, format="json").status_code, 400)

    def test_history_shows_every_change(self):
        self.stock_in([{"variant": str(self.s28.id), "qty": 10}])
        self.c.post("/api/stock/correct/", {"variant": str(self.s28.id), "counted": 11}, format="json")
        h = self.c.get("/api/stock/history/", {"variant": str(self.s28.id)}).data
        self.assertEqual(h["stock"], 11)
        self.assertEqual([m["kind"] for m in h["movements"]], ["adjust", "stock_in", "opening"])
        self.assertEqual(sum(m["qty"] for m in h["movements"]), 11)


class CounterStockIn(Base):
    def test_counter_adds_pieces_but_cannot_change_prices(self):
        from config.testing import counter_client
        c = counter_client()
        res = c.post("/api/stock/entries/", {"lines": [{"variant": str(self.s28.id), "qty": 3, "price": "999", "cost_price": "1"}]}, format="json")
        self.assertEqual(res.status_code, 201)
        v = self.fresh(self.s28)
        self.assertEqual((v.stock, v.price, v.cost_price), (5, Decimal("240"), Decimal("150")))
