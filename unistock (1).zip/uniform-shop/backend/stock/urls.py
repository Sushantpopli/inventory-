from django.urls import include, path
from rest_framework.routers import DefaultRouter

from . import views

router = DefaultRouter()
router.register("entries", views.StockInViewSet, basename="stock-in")

urlpatterns = [
    path("correct/", views.correct),
    path("history/", views.history),
    path("", include(router.urls)),
]
