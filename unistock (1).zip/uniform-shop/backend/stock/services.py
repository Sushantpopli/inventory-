from django.db import transaction
from django.db.models import Max
from django.utils import timezone

from catalog.models import StockMovement, Variant
from catalog.services import record_movement
from labels.services import add_to_queue as queue_labels

from .models import StockIn, StockInLine


class StockError(ValueError):
    pass


@transaction.atomic
def save_stock_in(lines: list[dict], note: str = "", add_labels: bool = True) -> StockIn:
    """
    lines: [{variant: Variant, qty: int, cost_price: Decimal|None, price: Decimal|None}]
    - adds the quantity to stock
    - saves the cost price (if given) and the selling price (if changed) on the size
    - optionally puts one label per piece on the print list
    """
    lines = [l for l in lines if l["qty"] > 0]
    if not lines:
        raise StockError("Enter a quantity for at least one size")
    seen = set()
    for l in lines:
        if l["variant"].pk in seen:
            raise StockError(f"{l['variant']} is listed twice. Put the total in one line.")
        seen.add(l["variant"].pk)

    number = (StockIn.objects.aggregate(m=Max("number"))["m"] or 0) + 1
    entry = StockIn.objects.create(number=number, note=note.strip())
    for l in lines:
        v = Variant.objects.select_for_update().get(pk=l["variant"].pk)
        new_price = l.get("price") if l.get("price") is not None else v.price
        StockInLine.objects.create(entry=entry, variant=v, qty=l["qty"], cost_price=l.get("cost_price"),
                                   price=new_price, old_price=v.price)
        changed = []
        if l.get("cost_price") is not None and l["cost_price"] != v.cost_price:
            v.cost_price = l["cost_price"]
            changed.append("cost_price")
        if new_price != v.price:
            v.price = new_price
            changed.append("price")
        if changed:
            v.save(update_fields=changed + ["updated_at"])
        record_movement(v, l["qty"], StockMovement.Kind.STOCK_IN, reference=f"Stock in #{number}", note=note[:255])
        if add_labels:
            queue_labels(v, l["qty"])
    return entry


@transaction.atomic
def cancel_stock_in(entry: StockIn, reason: str) -> StockIn:
    """Takes the quantities back out. Prices stay as they are (change them on the product if needed)."""
    entry = StockIn.objects.select_for_update().get(pk=entry.pk)
    if entry.status == StockIn.Status.CANCELLED:
        raise StockError("This entry is already cancelled")
    if not reason.strip():
        raise StockError("Write a reason for cancelling")
    for line in entry.lines.select_related("variant"):
        record_movement(line.variant, -line.qty, StockMovement.Kind.ADJUST,
                        reference=f"Stock in #{entry.number} cancelled", note=reason.strip()[:255])
    entry.status = StockIn.Status.CANCELLED
    entry.cancel_reason = reason.strip()
    entry.cancelled_at = timezone.now()
    entry.save(update_fields=["status", "cancel_reason", "cancelled_at"])
    return entry


@transaction.atomic
def correct_stock(variant: Variant, counted: int, reason: str = "") -> StockMovement | None:
    """
    After counting the shelf: make the software match what is really there.
    Records the difference as an Adjustment (history is kept). Returns None if nothing changed.
    """
    if counted < 0:
        raise StockError("Counted quantity cannot be negative")
    variant = Variant.objects.select_for_update().get(pk=variant.pk)
    diff = counted - variant.stock
    if diff == 0:
        return None
    return record_movement(variant, diff, StockMovement.Kind.ADJUST, reference="Stock count",
                           note=(reason.strip() or f"Counted {counted}, was {variant.stock}")[:255])
