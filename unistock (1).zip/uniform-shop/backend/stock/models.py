"""
Stock in: new pieces arriving (from the own factory or a manufacturer).

Kept simple on purpose: quantity + cost price + selling price. Where the stock came
from is just a free-text note for now.
"""
import uuid

from django.db import models

from catalog.models import Variant


class StockIn(models.Model):
    class Status(models.TextChoices):
        DONE = "done", "Done"
        CANCELLED = "cancelled", "Cancelled"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    number = models.PositiveIntegerField(unique=True)
    created_at = models.DateTimeField(auto_now_add=True)
    note = models.CharField(max_length=200, blank=True, help_text="e.g. Own factory, Sharma Garments")
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.DONE)
    cancel_reason = models.CharField(max_length=200, blank=True)
    cancelled_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-number"]
        verbose_name = "stock in"
        verbose_name_plural = "stock in"

    def __str__(self):
        return f"Stock in #{self.number}"


class StockInLine(models.Model):
    entry = models.ForeignKey(StockIn, on_delete=models.CASCADE, related_name="lines")
    variant = models.ForeignKey(Variant, on_delete=models.PROTECT, related_name="stock_in_lines")
    qty = models.PositiveIntegerField()
    cost_price = models.DecimalField(max_digits=9, decimal_places=2, null=True, blank=True)
    price = models.DecimalField("selling price", max_digits=9, decimal_places=2)
    old_price = models.DecimalField(max_digits=9, decimal_places=2, help_text="Selling price before this entry")

    class Meta:
        ordering = ["id"]

    @property
    def price_changed(self):
        return self.price != self.old_price
