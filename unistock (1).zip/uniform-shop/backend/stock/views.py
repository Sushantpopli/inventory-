"""
Stock API

POST /api/stock/entries/                {note, add_labels, lines: [{variant, qty, cost_price?, price?}]}
GET  /api/stock/entries/                newest first
GET  /api/stock/entries/<id>/
POST /api/stock/entries/<id>/cancel/    {reason}
POST /api/stock/correct/                {variant, counted, reason?}
GET  /api/stock/history/?variant=<id>   every stock change for one size, newest first
"""
from django.shortcuts import get_object_or_404
from rest_framework import serializers, status, viewsets
from rest_framework.decorators import action, api_view, permission_classes

from accounts.permissions import IsOwner, is_owner
from rest_framework.response import Response

from catalog.models import StockMovement, Variant

from . import services
from .models import StockIn, StockInLine


class LineInSerializer(serializers.Serializer):
    variant = serializers.PrimaryKeyRelatedField(queryset=Variant.objects.all())
    qty = serializers.IntegerField(min_value=0, max_value=100000)
    cost_price = serializers.DecimalField(max_digits=9, decimal_places=2, min_value=0, required=False, allow_null=True)
    price = serializers.DecimalField(max_digits=9, decimal_places=2, min_value=0, required=False, allow_null=True)


class StockInCreateSerializer(serializers.Serializer):
    note = serializers.CharField(max_length=200, required=False, allow_blank=True, default="")
    add_labels = serializers.BooleanField(default=True)
    lines = LineInSerializer(many=True)


class LineOutSerializer(serializers.ModelSerializer):
    item = serializers.CharField(source="variant.product.display_name", read_only=True)
    size = serializers.CharField(source="variant.size", read_only=True)
    barcode = serializers.CharField(source="variant.barcode", read_only=True)
    price_changed = serializers.BooleanField(read_only=True)

    class Meta:
        model = StockInLine
        fields = ["variant", "item", "size", "barcode", "qty", "cost_price", "price", "old_price", "price_changed"]


class StockInSerializer(serializers.ModelSerializer):
    lines = LineOutSerializer(many=True, read_only=True)
    total_qty = serializers.SerializerMethodField()
    total_cost = serializers.SerializerMethodField()

    class Meta:
        model = StockIn
        fields = ["id", "number", "created_at", "note", "status", "cancel_reason", "cancelled_at",
                  "total_qty", "total_cost", "lines"]

    def get_total_qty(self, obj):
        return sum(l.qty for l in obj.lines.all())

    def get_total_cost(self, obj):
        known = [l for l in obj.lines.all() if l.cost_price is not None]
        return f"{sum(l.qty * l.cost_price for l in known):.2f}" if known else None


class StockInViewSet(viewsets.ReadOnlyModelViewSet):
    serializer_class = StockInSerializer

    def get_queryset(self):
        return StockIn.objects.prefetch_related(
            "lines__variant__product__category", "lines__variant__product__schools")

    def create(self, request):
        s = StockInCreateSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        if not is_owner(request.user):  # counter staff add pieces; prices stay as the owner set them
            for line in s.validated_data["lines"]:
                line["price"] = line["cost_price"] = None
        try:
            entry = services.save_stock_in(s.validated_data["lines"], s.validated_data["note"],
                                           s.validated_data["add_labels"])
        except services.StockError as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(StockInSerializer(self.get_queryset().get(pk=entry.pk)).data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=["post"])
    def cancel(self, request, pk=None):
        if not is_owner(request.user):
            return Response({"detail": "Only the owner can cancel a stock entry."}, status=status.HTTP_403_FORBIDDEN)
        try:
            entry = services.cancel_stock_in(self.get_object(), request.data.get("reason", ""))
        except services.StockError as e:
            return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        return Response(StockInSerializer(self.get_queryset().get(pk=entry.pk)).data)


@api_view(["POST"])
@permission_classes([IsOwner])
def correct(request):
    v = get_object_or_404(Variant, pk=request.data.get("variant"))
    try:
        counted = int(request.data.get("counted"))
    except (TypeError, ValueError):
        return Response({"detail": "Enter the counted quantity"}, status=400)
    try:
        mv = services.correct_stock(v, counted, request.data.get("reason", ""))
    except services.StockError as e:
        return Response({"detail": str(e)}, status=400)
    v.refresh_from_db()
    return Response({"stock": v.stock, "changed_by": mv.qty if mv else 0})


@api_view(["GET"])
def history(request):
    v = get_object_or_404(Variant, pk=request.query_params.get("variant"))
    rows = StockMovement.objects.filter(variant=v).order_by("-created_at")[:200]
    return Response({
        "stock": v.stock,
        "movements": [{"at": m.created_at, "kind": m.kind, "kind_label": m.get_kind_display(), "qty": m.qty,
                       "reference": m.reference, "note": m.note} for m in rows],
    })
