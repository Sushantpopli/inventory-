from django.contrib import admin

from .models import StockIn, StockInLine


class LineInline(admin.TabularInline):
    model = StockInLine
    extra = 0
    readonly_fields = ["variant", "qty", "cost_price", "price", "old_price"]
    can_delete = False


@admin.register(StockIn)
class StockInAdmin(admin.ModelAdmin):
    list_display = ["number", "created_at", "note", "status"]
    list_filter = ["status"]
    inlines = [LineInline]
    readonly_fields = ["number", "note", "status", "cancel_reason", "cancelled_at"]

    def has_delete_permission(self, request, obj=None):
        return False
