# Project Notes

Share this file with Claude at the start of every session so work continues from here.

## The shop (facts)
- Family school-uniform shop. One person bills at the counter. Open ~9 am – 9 pm.
- 150–200 schools. Starting with 9: Shree Kalidevi, Krishna Pranami, Bhagat Singh, DPS,
  Baba Banda Bahadur, GD Goenka, JMS, Aryan Public, Siddhartha Public (+ Common items).
- Summer and winter uniforms, different prices. Price rises with size (e.g. 28 = ₹200, 30 = ₹220).
- Sizes: 22–44, plus size-waist like 40-32, 40-34. Same size chart for all schools.
- Payments: cash + UPI. No discounts today (keep the option). No GST bills.
- Bill shows: firm name + phone at top; item, price, qty, amount; total.
- Returns/exchange: 7 days (setting). Refund or credit note.
- Power cuts switch off Wi-Fi → billing must work offline.
- Old NGX cash register was too hard to use. Rule: everything visible in words, nothing to memorise.

## Decisions
- Counter: laptop + USB barcode scanner + 80 mm receipt printer + label printer.
- Every size of every product gets its own barcode (sequential numbers from 10001).
- A product can belong to many schools, or none (= Common).
- Stock only changes through StockMovement (opening, stock_in, sale, return, exchange, adjust).
- Stock in = quantity + cost price + selling price. No suppliers / godown for now.
- UUID primary keys (needed for offline billing later).
- Single shop for now (no multi-shop).

## Modules
| # | Module | Status |
|---|--------|--------|
| 0 | Layout & look (mock-up) | Done |
| 1 | Catalog: schools, products, sizes, price ladder, Excel import | Done (not yet run on Sushant's PC) |
| 2 | Barcode labels (generate + print) | Done (not yet run on Sushant's PC) |
| 3 | Billing (offline) + receipt printing | Done (not yet run on Sushant's PC) |
| 4 | Stock in + stock count + history | Done (not yet run on Sushant's PC) |
| 5 | Returns & exchange (7 days, credit note) | Done (not yet run on Sushant's PC) |
| 6 | Reports & low-stock list | Done (not yet run on Sushant's PC) |
| 7 | Login & roles + owner's phone view | Done (not yet run on Sushant's PC) |

## Module 1 — what exists
- API under `/api/catalog/`: schools, categories, products (create with price ladder,
  `add_sizes`), variants (search `?q=dps shirt 30`, `?low=1`, `barcode/<code>/`), Excel import
  (`import/` with dry run, `import/template/`), `size-presets/`.
- Screens: Products (by school, add with price ladder, edit price/cost/alert inline, add sizes),
  Schools (add, hide), Excel Import (check → import).
- `python manage.py seed_shop [--demo]`.

## Module 2 — what exists
- `labels` app. Print list (queue): add one size, or a whole product (1 label per piece in
  stock, or N per size). Edit copies, remove, clear.
- PDF labels, Code 128 barcodes: roll 50×25 mm, roll 38×25 mm (one label per page), A4 65-up
  sheet with "skip used labels". Label = schools · item, SIZE, Rs price, barcode, number.
- Bar widths are whole printer dots at 203 dpi; a test renders every layout and decodes the
  barcode. Backend: 33 tests, all passing.
- Screens: Labels page (print list, label size, open PDF, scan test); label buttons on each product.
- Label printer setup: set the printer's paper size to the label size, print the PDF at 100%.

## Module 3 — what exists
- Backend `billing` app: ShopSettings (firm name, phone, address, bill footer, return days,
  allow discount, first bill number), Bill + BillLine (name/size/price copied at sale time),
  `snapshot/` (all items, or only changes `?since=`), `sync/` (send bills; safe to send twice;
  number clash → next free number), bills list/search, cancel (keeps the bill, returns stock).
- Selling more than the stock count is allowed (shelf is the truth); stock goes negative to fix.
- Frontend offline layer (`src/offline/`): Dexie (IndexedDB) copy of all items + outbox of
  bills; syncs every 20 s and on reconnect. Service worker (`public/sw.js`) lets the app open
  with no internet (built version only).
- Screens: Bill (scan / type / tap school→item→size, qty ±, discount, Cash / UPI / Cash+UPI,
  change to give back, optional customer, F8 save, Enter new bill), Bills (this counter's
  bills with sent/waiting/problem, reprint, cancel, find old bill), Settings (shop details,
  auto print, 80/58 mm paper, sync info). Status chip shows online/offline + bills waiting.
- Receipt prints alone on 80 mm or 58 mm paper. For printing with no dialog, start Chrome
  with `--kiosk-printing` and set the receipt printer as default.
- Bill numbers come from the counter (one counter assumed). With two counters later,
  numbers can clash; the server then renumbers the later bill.
- Tested: 45 backend tests; browser test of online billing, offline billing, offline reload,
  sync on reconnect, split payment, cancel, Hindi, fast double scan.

## Module 4 — what exists
- Backend `stock` app: StockIn entries (numbered, note like "Own factory") with lines
  (qty, cost price, selling price, old price). Saving adds stock (movement "stock_in"),
  updates cost/selling price on the size, and (optional, default on) adds 1 label per piece
  to the print list. Cancel entry takes the pieces back out (adjustment), prices unchanged.
- `correct/`: after counting the shelf, enter the real number; difference saved as an
  Adjustment. `history/?variant=`: every stock change for a size.
- Label queue helper moved to `labels/services.py` (add_to_queue).
- Screens: Stock In page (note chips, scan = +1 piece, or pick school → product to list
  all sizes and type quantities; cost & selling price per size; warning when price changes;
  recent entries with cancel). Products → each size now has "Count" and "History".
- Stock in needs internet (billing doesn't). The counter picks up new stock/prices on its
  next sync (within 20 s).
- If the selling price changes, pieces already on the shelf also bill at the new price
  (barcode = size, not piece) — reprint their labels.
- Tested: 56 backend tests; browser test of the full stock-in flow, counter update,
  count, history, cancel, offline guard, Hindi.

## Module 5 — what exists
- A return is a bill line with negative qty pointing to the sold line (`returned_from`, by the
  line's `client_id` UUID made on the counter). An exchange is one bill with return lines and
  new lines; its total is the difference. Works offline (bills of this counter are local).
- Rules (server): within return days (else needs `return_override` reason), never more pieces
  than sold minus already returned, never refund more per piece than paid. Refund price =
  price minus the line's share of the bill discount.
- Payment rule: cash + upi + credit_used − credit_issued = total. Cash/UPI negative = money
  given back. Credit note issued on a return bill gets code `CN<bill number>`; spending a
  credit note needs internet (balance check). Partly-used notes keep their balance.
- Cancel rules: a sale whose items were returned can't be cancelled until the return bill is
  cancelled; a return whose credit note was spent can't be cancelled; cancelling a bill that
  spent credit gives the credit back.
- Outbox now sends bills oldest first (a sale reaches the server before its return).
- Migration 0002 gives existing bill lines their own ids before making the column unique.
- Screens: Bill → "Return / Exchange": find by bill number or scan the item (recent bills
  with it), choose pieces, late bills need "Allow anyway" + reason. Total shows "Give back"
  with Cash / UPI / Credit note. "Use credit note" box when the customer pays. Receipt shows
  RETURN lines, GIVEN BACK, credit used, and a boxed CREDIT NOTE with its code.
- Not yet: marking a returned piece as damaged (it always goes back into stock).
- Tested: 71 backend tests; browser test of cash refund, exchange, fully-returned limit,
  return by scanning item, credit note issue + use + part credit, offline sale+return then
  sync, 7-day block + override, cancel block, Hindi; earlier billing & stock-in tests re-run.

## Module 6 — what exists
- Backend `reports` app (no tables of its own; all from bills and stock). Cancelled bills
  ignored. Words: Sales = new items after discount, Returns = value given back, Net = Sales −
  Returns. Profit only over pieces that have a cost price (current cost price), with their
  share of the discount; pieces without cost are counted and shown separately.
- `summary/?from&to` (+ same dates last year + every day in range), `top/?by=size|product|
  school|category` (net of returns), `low-stock/?school=` (grouped by product; suggested order
  = max(sold last 30 days, 2 × warning level) − stock, at least 1), `sales.xlsx`,
  `low-stock.xlsx`.
- Screens: Reports (Today / Yesterday / Last 7 days / This month / Last month / custom dates,
  tiles, last-year line, day-wise bar chart with hover, most sold by size/product/school/item
  type, cash/UPI box, Excel download). Low stock (school filter, sizes with stock / sold 30
  days / suggested, copy order list for WhatsApp, Excel order sheet).
- Reports need internet.
- Tested: 76 backend tests; browser test of tiles, chart hover, top lists, Excel, low-stock
  copy, school filter, Hindi.

## Module 7 — what exists
- `accounts` app: StaffProfile (display name, role owner/counter) on Django users. PIN = the
  user's password (hashed). DRF token login: `people/` (names for login screen, no login
  needed), `login/` (10 tries/min), `logout/`, `me/`, `staff/` (owner: add, change role/PIN,
  remove access; PIN change or removal ends old logins; last active owner can't be removed).
  `python manage.py create_owner --name X --pin 1234` for first setup.
- Every endpoint needs login. Owner only: reports summary/top/Excel/today, settings change,
  schools/products/prices changes, Excel import, stock count, stock-in cancel, cancel bills
  from earlier days, staff. Counter: billing, returns, credit notes, labels, stock in (its
  price/cost changes are ignored), low stock, cancel today's bills.
- Frontend: login screen (tap name → big PIN pad), token in localStorage (counter stays
  logged in offline), tabs by role, owner-only routes redirect, counter sees products read-
  only. Excel / label PDF now fetched with the login (no plain links). Logout tries to send
  waiting bills first; bills never leave the outbox until the server accepts them.
- Owner phone: `/today` (default for owner on a small screen): today's net, cash/UPI, bills,
  vs yesterday and same day last week, low-stock count + top 5, latest bills with lines,
  refresh every minute. App icon + manifest so "Add to Home screen" works.
- Tested: 92 backend tests (incl. who-can-do-what); browser tests of login, wrong PIN,
  staff add, role tabs, redirects, read-only products, counter billing + sync, offline reload
  while logged in, phone Today view, Hindi; Modules 3–5 browser tests re-run with login.

## Design — UniStock look (based on Sushant's own UniStock mock-ups)
- Name: **UniStock** (bag logo). Dark navy + amber by default; sun/moon button in the header
  switches to a light screen (remembered per computer). Text kept large and bright for 50+ users.
- Fonts Manrope + Hind are bundled (work offline).
- Sidebar = one item per job, under small headings:
  SELL: Generate Bill, Return / Exchange, Bill History · STOCK: Add Stock, Print Barcodes,
  View Stock, Low stock · SHOP: Today (owner), Reports (owner), Settings (tabs: Settings / Staff /
  Schools / Excel Import). Phone bottom bar: Billing, Bills, Stock, Today, Reports, Settings.
- Every page header: title + one-line hint, online status, clock, EN/हिं, light/dark.
- Billing and Add Stock have a **Scanner | Manual** switch (remembered). Scanner = big scan box.
  Manual = school → item → size buttons (kept instead of dropdowns: 3 taps). Scanning still
  works in Manual mode.
- Return / Exchange page = billing screen with step 1 (find bill / scan item) and step 2 (new
  size for an exchange). Same rules as Module 5.
- Kept from our design: name + PIN login, Cash / UPI / Cash+UPI buttons, green grand total,
  discount / credit note / customer behind "+ More options".
- Colours live as tokens at the top of `frontend/src/index.css`.
- Clean-up pass (less on screen):
  - Rule: dropdowns for long or rarely-changed lists (schools, label size, report period, "from",
    paper width, return days); big buttons for things tapped on every bill (sizes, Cash/UPI, Save).
  - Search dropdown (`components/SearchSelect.jsx`) for schools — type a few letters, Enter picks.
    Billing shows it plus the last 6 schools used as quick chips.
  - Header = title, hint, online status, clock. Language, light/dark and log out live in the user
    menu (tap your name, bottom of sidebar; avatar top-right on phone).
  - "Add a return" link inside the bill (sidebar has the full Return / Exchange page).
  - Small pop-up messages (`components/Toast.jsx`) instead of boxes that push the page down.
  - View Stock: school dropdown + search (no 200-row school list). Add Stock: "From" dropdown,
    recent panel only when there are entries. Print Barcodes: ✕ per row, size dropdown, scan test
    behind a link. Low stock: one line per product with size chips (size · stock → order).
  - Reports: period dropdown, 3 tiles (Net sale with cash/UPI, Bills, Profit), chart, most sold.
  - Settings: sections (Shop details · Bills & returns · This computer). Bill History: day
    dropdown + search (bill no., name, phone), bill opens on the right.
- Tested: browser tests for Modules 3–7 re-run on the new layout; 92 backend tests pass.

## Going live (next)
- Run Sushant's PC test of everything with real data (9 schools).
- Server: small cloud VPS (or the counter laptop + cloud backup) with PostgreSQL, HTTPS,
  `DJANGO_DEBUG=0`, a real `DJANGO_SECRET_KEY`, allowed hosts, daily database backup.
- Serve the built frontend (`npm run build`) from the same domain as `/api`.
- Hardware: USB barcode scanner, 80 mm receipt printer, 50×25 mm label printer.

## Open items / ideas for later
- Returned item damaged → don't put back in stock (option on return).
- Godown stock, suppliers, custom fitting orders, udhaar, school bulk orders.
- Hindi voice search, WhatsApp bills, reorder suggestions.
